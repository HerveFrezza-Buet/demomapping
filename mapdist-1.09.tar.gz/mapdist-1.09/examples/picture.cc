#include <MAPdist.h>
#include <gtk/gtk.h>
#include <iostream>
#include <string>

MAPdist::Distrib* GetDistribution(int no);

/* Gtk destroying callbacks */
gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}


/* This function is called when the viewer has
   to draw its content */
void Draw(MAPdist::Viewer* view,void* user_data)
{

  /* The viewing area is dedicated to represent 
     values x,y,z in [0..1] */

  view->DrawAxis();
  view->DrawDistrib();
  
}

int main (int argc, char *argv[])
{
  GtkWidget *window1;
  MAPdist::Viewer* viewer;
  MAPdist::Picture* distrib;
  std::string title = "Distribution of colors in ";


  if(argc!=2)
    {
      std::cout << "Usage : " << argv[0] << " <ppm file>" << std::endl;
      return 1;
    }

  /* This defines a grid step in space. At each
     point of the grid, the distribution is computed.
     Small steps imply heavy computation of distribution. */
  MAPdist::Distrib::SetResolution(.02);

  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "MAPdist-tutorial");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);


  /* Add the viewer in the widget tree */
  title += argv[1];
  viewer=new MAPdist::Viewer((char*)(title.c_str()), /* Title of the viewer's frame */
			     1       /* 0 <=> black distribution. If not nul,
					the viewer displays each point of the distribution
					with [x,y,z] as rgb color */
			     );
  viewer->SetDrawingCallback(Draw,NULL); /* Tell the viewer to call
					    the Draw function for drawing */
  gtk_container_add (GTK_CONTAINER (window1), viewer->GetWidget());
  

  /* We use 1000 random samples pixels in the image */
  distrib=new MAPdist::Picture(1000);
  
  if(!distrib->Load(argv[1]))
    {
      std::cerr << "Cannot open \"" << argv[1] << "\", or it isn't a well formed ppm file (P5 or P6 accepted)"
		<< std::endl;
      return 1;
    }

  /* Build actual points from distribution description */
  distrib->Build();
  /* Tells the viewer the distribution to display */
  viewer->SetDistrib(distrib);


  gtk_main ();
  return 0;
}
