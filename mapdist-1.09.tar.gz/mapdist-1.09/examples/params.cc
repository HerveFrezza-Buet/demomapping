#include <MAPdist.h>
#include <iostream>
#include <stdlib.h>

/* Gtk destroying callbacks */
gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}


/* These are idf parameters. They may not be global in non-tutorial application */
int idf_size;
int idf_weight;

/* This function will be called periodically */
gboolean timeout_callback(gpointer data)
{
  MAPdist::Params* params;
  float size,weight;

  params=(MAPdist::Params*)data;
  
  /* We get parameters value */
  size=params->GetValue(idf_size);
  weight=params->GetValue(idf_weight);
  
  std::cout << "Size (" << idf_size << ") : " << size
	    << "          "
	    << "Weight (" << idf_weight << ") : " << weight
	    << std::endl;

  return TRUE;
}

int main (int argc, char *argv[])
{
  GtkWidget *window1;
  MAPdist::Params* params;

  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "MAPdist-tutorial");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);


  /* Creating params container */
  params=new MAPdist::Params("Parameters" /* Frame title */);
  gtk_container_add (GTK_CONTAINER (window1), params->GetWidget());
  
  /* Adding params */

  idf_size  =params->Add("Size",     /* name                          */
			 1.75,       /* initial value                 */
			 .20, 2.72,  /* minimal and maximal values    */
			 .01, .1,    /* small and big increments      */
			 2           /* Decimals after floating point */);
  
  idf_weight=params->Add("Weight",   /* name                          */
			 75,         /* initial value                 */
			 1, 200,     /* minimal and maximal values    */
			 .5, 5,      /* small and big increments      */
			 1           /* Decimals after floating point */);
  
  /* Let's gtk call display function every 100 ms */
  gtk_timeout_add(100,timeout_callback,(gpointer)params);

  gtk_main ();
  return 0;
}
