#include <MAPdist.h>
#include <gtk/gtk.h>
#include <iostream>

MAPdist::Distrib* GetDistribution(int no);

/* Gtk destroying callbacks */
gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}


/* This function is called when the viewer has
   to draw its content */
void Draw(MAPdist::Viewer* view,void* user_data)
{

  /* The viewing area is dedicated to represent 
     values x,y,z in [0..1] */


  view->DrawAxis();
  view->SetDrawingColor(1,0,1); /* rgb is in [0..1], here is purple */
  view->DrawLine(.25,.25,.25,   /* first point */
 		 .75,.75,.75    /* last point  */
		 );
  view->DrawDistrib();

  view->SetDrawingColor(1,1,0);  /* Yellow */
  view->DrawPrototype(.25,.25,.25); /* Draw a small sphere at .25,.25,.25 */
  view->DrawPrototype(.75,.75,.75);
  
}

int main (int argc, char *argv[])
{
  GtkWidget *window1;
  MAPdist::Viewer* viewer;
  MAPdist::Distrib* distrib;

  /* This defines a grid step in space. At each
     point of the grid, the distribution is computed.
     Small steps imply heavy computation of distribution. */
  MAPdist::Distrib::SetResolution(.02);

  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "MAPdist-tutorial");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);


  /* Add the viewer in the widget tree */
  viewer=new MAPdist::Viewer("View", /* Title of the viewer's frame */
			     1       /* 0 <=> black distribution. If not nul,
					the viewer displays each point of the distribution
					with [x,y,z] as rgb color */
			     );
  viewer->SetDrawingCallback(Draw,NULL); /* Tell the viewer to call
					    the Draw function for drawing */
  gtk_container_add (GTK_CONTAINER (window1), viewer->GetWidget());
  

  /* This is a function of the tutorial to provide
     one distribution. Change argument to test other
     distributions. */
  distrib=GetDistribution(10);

  /* The distribution is centered on [0,0,0], so
     we translate it at the center of the exes. */
  distrib->Translate(.5,.5,.5); 
  /* Build actual points from distribution description */
  distrib->Build();
  /* Tells the viewer the distribution to display */
  viewer->SetDistrib(distrib);


  gtk_main ();
  return 0;
}

MAPdist::Distrib* GetDistribution(int no)
{
  float thick;
  float d;
  switch(no)
    {
    case 0:
      /* Block */
      return new MAPdist::Block(.3, /* x size  */
				.2, /* y size  */
				.1, /* z size  */
				.5  /* density */);

    case 1:
      /* Sphere */
      /* This is a radius=1 sphere */
      return new MAPdist::Sphere(.5  /* density */);

    case 2:
      /* Gauss */
      /* This is a ampl*exp(-r2/sigma) distribution
	 int a 1-side cube */
      return new MAPdist::Gauss(1, /* amplitude */
				.2 /* sigma     */);

    case 3:
      /* Cylinder */
      /* This is a radius=1, length=1 vertical cylinder */
      return new MAPdist::Cylinder(.5  /* density */);

    case 4:
      /* Torus */
      /* This is a radius=1 torus */
      return new MAPdist::Torus(.2, /* tube radius */
				.5  /* density     */);
      
    case 5:
      /* Scale */
      /* This allows to scale a distribution along x,y,z axis */
      return new MAPdist::Scale(new MAPdist::Sphere(.5),
				1, /* x factor  */
				.6, /* y factor  */
				.4  /* z factor  */);
    case 6:
      /* Rotate */
      /* This allows to rotate distribution around a given direction */
      return new MAPdist::Rotate(new MAPdist::Torus(.2,.5),
				 30,   /* angle in degrees */
				 1,0,0 /* x-axis           */);

    case 7:
      /* Union */
      /* This allows to make a distribution from two ones as a union */
      return new MAPdist::Or(new MAPdist::Block(.5,.5,.5,1),
			     .5,.2,0, /* Translation of second distribution
					 from the first one */
			     new MAPdist::Sphere(.3));

    case 8:
      /* Intersection */
      /* This allows to make a distribution from two ones as an intersection */
      return new MAPdist::And(new MAPdist::Block(.5,.5,.5,1),
			      .5,.2,0, /* Translation of second distribution
					  from the first one */
			      new MAPdist::Sphere(.3));
      
    case 9:
      /* Not */
      /* This inverts a distribution. You may use it for extrusions */
      return new MAPdist::Not(new MAPdist::Cylinder(1));

    default:
      thick=.1;
      d=1;
      return new MAPdist::Scale(new MAPdist::Or(new MAPdist::Or(new MAPdist::Or(new MAPdist::And(new MAPdist::Not(new MAPdist::Rotate(new MAPdist::Or(new MAPdist::Block(2,2,2,0),
																		      0,0,0,
																		      new MAPdist::Scale(new MAPdist::Cylinder(1),
																					 .5,.5,2)),
																      45,0,1,0)),
												 0,0,0,
												 new MAPdist::Block(1,1,1,d)),
										.85,0,0,
										new MAPdist::Block(.7,1,thick,d)),
								1.4,0,0,
								new MAPdist::Scale(new MAPdist::Rotate(new MAPdist::Cylinder(d),
												       90,0,1,0),
										   .5,thick,thick)),
						2,0,0,
						new MAPdist::Torus(thick/2,d)),
				.4,.4,.4);
			      
			      
    }
}
