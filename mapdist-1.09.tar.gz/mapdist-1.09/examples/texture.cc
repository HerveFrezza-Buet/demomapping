#include <MAPdist.h>
#include <gtk/gtk.h>
#include <iostream>


/* Gtk destroying callbacks */
gboolean
on_window_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

struct RGB {
  unsigned char r,g,b;
};
#define TEX_SIDE 128
RGB texture[TEX_SIDE*TEX_SIDE];
#define PAD 10


int global_time=0;

MAPdist::Viewer* viewer;
MAPdist::Steps* steps;

void Restart(MAPdist::Steps* steps,void* user_data)
{
  global_time=0;
  viewer->Redisplay();
}

/* Function called at each step */
void Step(MAPdist::Steps* steps,void* user_data)
{
  ++global_time;
  if(global_time>=100)
    global_time=0;
  viewer->Redisplay();
}

/* This function is called when the viewer has
   to draw its content */
void Draw(MAPdist::Viewer* view,void* user_data)
{
  int w,h,ww,hh,www,hhh;
  float x,y;
  RGB* pix;

  // Let us update the texture
  for(h=0, hh=global_time, pix = texture;
      h<TEX_SIDE;++h,++hh) {
    hhh = hh/PAD;
    for(w=0, ww=global_time;w<TEX_SIDE;++w,++ww,++pix) {
      www = ww/PAD;
      if(www%2 == hhh%2) {
  	pix->r = 255;
  	pix->g = 255;
  	pix->b = 0;
      }
      else {
  	pix->r = 255;
  	pix->g = 0;
  	pix->b = 0;
      }
    }
  }

  view->PostTexture(TEX_SIDE,(unsigned char*)texture);
  view->BeginDrawingTexPoints(3);
  for(x=0;x<=1;x+=.01)
    for(y=0;y<=1;y+=.01)
      view->DrawPoint(x,y,.5+.5*sin(8*y),x,y);
  view->EndDrawingTexPoints();
  view->DrawAxis();

}

int main (int argc, char *argv[])
{
  GtkWidget *window1;
  GtkWidget *window2;

  MAPdist::Distrib::SetResolution(.02);

  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "MAPdist-tutorial");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window_delete_event),
                      NULL);

  window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window2), "MAPdist-tutorial");
  gtk_widget_show(window2);

  gtk_signal_connect (GTK_OBJECT (window2), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
                      GTK_SIGNAL_FUNC (on_window_delete_event),
                      NULL);


  /* Add the viewer in the widget tree */
  viewer=new MAPdist::Viewer("View", /* Title of the viewer's frame */
			     1       /* 0 <=> black distribution. If not nul,
					the viewer displays each point of the distribution
					with [x,y,z] as rgb color */
			     );
  viewer->SetDrawingCallback(Draw,NULL); /* Tell the viewer to call
					    the Draw function for drawing */
  gtk_container_add (GTK_CONTAINER (window1), viewer->GetWidget());
  

  steps=new MAPdist::Steps("Control");
  steps->SetDelay(10);
  steps->SetStepCallback(Step,NULL);
  steps->SetRestartCallback(Restart,NULL);
  gtk_container_add (GTK_CONTAINER (window2), steps->GetWidget());


  gtk_main ();
  return 0;
}

