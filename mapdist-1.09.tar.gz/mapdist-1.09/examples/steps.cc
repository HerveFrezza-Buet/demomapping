#include <MAPdist.h>
#include <iostream>
#include <stdlib.h>

/* Gtk destroying callbacks */
gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}


/* Function called when restart */
void Restart(MAPdist::Steps* steps,void* user_data)
{
  std::cout << "Restart" << std::endl;
}

/* Function called at each step */
void Step(MAPdist::Steps* steps,void* user_data)
{
  std::cout << "Step" << std::endl;
}

int main (int argc, char *argv[])
{
  GtkWidget *window1;
  MAPdist::Steps* steps;

  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "MAPdist-tutorial");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);

  /* Creating steps */
  steps=new MAPdist::Steps("Control" /* Frame title */);
  gtk_container_add (GTK_CONTAINER (window1), steps->GetWidget());

  /* We set the delay between two successive steps */
  steps->SetDelay(1000 /* ms */);

  /* We set callbacks */
  steps->SetStepCallback(Step,NULL);
  steps->SetRestartCallback(Restart,NULL);


  gtk_main ();
  return 0;
}
