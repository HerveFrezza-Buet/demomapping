#include <MAPdist.h>


/* Gtk destroying callbacks */
gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}


int main (int argc, char *argv[])
{
  GtkWidget *window1;
  MAPdist::Map* map;

  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "MAPdist-tutorial");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);

  /* Creating map */
  map=new MAPdist::Map("Map", /* Frame title */
		       5,     /* Width       */
		       3,     /* Height      */
		       50     /* Cell size   */);
  gtk_container_add (GTK_CONTAINER (window1), map->GetWidget());

  /* Set coordinate values to some map points.
     They will be displayed as RGB colors (r,g,b [0..1]) 
     according to x,y,z */
  map->SetValue(0,0,
		0,0,1); /* blue */
  map->SetValue(1,0,
		1,0,1); /* purple */
  map->SetValue(1,1,
		.2,.5,.2); /* dark green*/

  gtk_main ();
  return 0;
}
