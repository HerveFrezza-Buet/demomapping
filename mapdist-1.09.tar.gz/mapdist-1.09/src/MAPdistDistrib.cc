#include "MAPdistDistrib.h"
#include <GL/gl.h>
#include <iostream>
#include <cstdlib>

#define MAPdistDISTRIB_PAD 1000

float MAPdist::Distrib::resolution=.1;

void MAPdist::Distrib::SetResolution(float  res)
{
  resolution=res;
}

MAPdist::Distrib::Distrib(float _dx,float _dy,float _dz)
{
  dist1=(Distrib*)NULL;
  dist2=(Distrib*)NULL;

  trans_x=0;
  trans_y=0;
  trans_z=0;

  ptx=NULL;
  pty=NULL;
  ptz=NULL;
  nb=0;
  size=0;

  offset_x1=0;
  offset_y1=0;
  offset_z1=0;

  offset_x2=0;
  offset_y2=0;
  offset_z2=0;
  
  dx=_dx;
  dy=_dy;
  dz=_dz;
}

MAPdist::Distrib::Distrib(MAPdist::Distrib* arg1)
{
  dist1=arg1;
  dist2=(Distrib*)NULL;

  trans_x=0;
  trans_y=0;
  trans_z=0;

  ptx=NULL;
  pty=NULL;
  ptz=NULL;
  nb=0;
  size=0;

  offset_x1=0;
  offset_y1=0;
  offset_z1=0;

  offset_x2=0;
  offset_y2=0;
  offset_z2=0;

  dx=arg1->dx;
  dy=arg1->dy;
  dz=arg1->dz;
}

MAPdist::Distrib::Distrib(MAPdist::Distrib* arg1,
			  MAPdist::Distrib* arg2,
			  float off_x,float off_y,float off_z)
{
  float minx,miny,minz,maxx,maxy,maxz;

  dist1=arg1;
  dist2=arg2;
  
  trans_x=0;
  trans_y=0;
  trans_z=0;

  ptx=NULL;
  pty=NULL;
  ptz=NULL;
  nb=0;
  size=0;

  minx=-arg1->dx*.5;
  maxx=arg1->dx*.5;
  if(-arg2->dx*.5+off_x<minx)
    minx=-arg2->dx*.5+off_x;
  if(arg2->dx*.5+off_x>maxx)
    maxx=arg2->dx*.5+off_x;

  miny=-arg1->dy*.5;
  maxy=arg1->dy*.5;
  if(-arg2->dy*.5+off_y<miny)
    miny=-arg2->dy*.5+off_y;
  if(arg2->dy*.5+off_y>maxy)
    maxy=arg2->dy*.5+off_y;

  minz=-arg1->dz*.5;
  maxz=arg1->dz*.5;
  if(-arg2->dz*.5+off_z<minz)
    minz=-arg2->dz*.5+off_z;
  if(arg2->dz*.5+off_z>maxz)
    maxz=arg2->dz*.5+off_z;

  dx=maxx-minx;
  dy=maxy-miny;
  dz=maxz-minz;

  offset_x1=-dx*.5-minx;
  offset_y1=-dy*.5-miny;
  offset_z1=-dz*.5-minz;

  offset_x2=offset_x1+off_x;
  offset_y2=offset_y1+off_y;
  offset_z2=offset_z1+off_z;
}
 
int MAPdist::Distrib::IsInBounds(float x,float y,float z)
{
  return (x>=-dx*.5)&&(x<=dx*.5)
    &&(y>=-dy*.5)&&(y<=dy*.5)
    &&(z>=-dz*.5)&&(z<=dz*.5);
}

int MAPdist::Distrib::IsInBounds1(float x,float y,float z)
{
  if(dist1!=NULL)
    return dist1->IsInBounds(x-offset_x1,
			     y-offset_y1,
			     z-offset_z1);
  else
    return 0;
}

int MAPdist::Distrib::IsInBounds2(float x,float y,float z)
{
  if(dist2!=NULL)
    return dist2->IsInBounds(x-offset_x2,
			     y-offset_y2,
			     z-offset_z2);
  else
    return 0;
}

int MAPdist::Distrib::IsInBounds12(float x,float y,float z)
{
  return IsInBounds1(x,y,z)&&IsInBounds2(x,y,z);
}

MAPdist::Distrib::~Distrib(void)
{
  delete dist1;
  delete dist2;
  delete [] ptx;
  delete [] pty;
  delete [] ptz;
  glDeleteLists(list,1);
}

void MAPdist::Distrib::Translate(float x,float y,float z)
{
  trans_x=x;
  trans_y=y;
  trans_z=z;
}

void MAPdist::Distrib::AskForSize(int i)
{
  float *tmpx,*tmpy,*tmpz;
  if(i>=size)
    {
      tmpx=ptx;
      tmpy=pty;
      tmpz=ptz;

      ptx=new float[size+MAPdistDISTRIB_PAD];
      pty=new float[size+MAPdistDISTRIB_PAD];
      ptz=new float[size+MAPdistDISTRIB_PAD];

      for(i=0;i<size;i++)
	{
	  ptx[i]=tmpx[i];
	  pty[i]=tmpy[i];
	  ptz[i]=tmpz[i];
	}

      delete [] tmpx;
      delete [] tmpy;
      delete [] tmpz;

      size+=MAPdistDISTRIB_PAD;
    }
}

void MAPdist::Distrib::Build(void)
{
  nb=0;
  
  double xx,yy,zz;

  for(xx=-dx*.5;xx<=dx*.5;xx+=resolution)
    for(yy=-dy*.5;yy<=dy*.5;yy+=resolution)
      for(zz=-dz*.5;zz<=dz*.5;zz+=resolution)
	if(GetDensity(xx,yy,zz)>rand()%1000*.001)
	  {
	    AskForSize(nb+1);
	    ptx[nb]=xx+trans_x+resolution*((rand()%1000)*.001-.5);
	    pty[nb]=yy+trans_y+resolution*((rand()%1000)*.001-.5);
	    ptz[nb]=zz+trans_z+resolution*((rand()%1000)*.001-.5);
	    nb++;
	  }
    
}
 
int MAPdist::Distrib::GetNbPoints(void)
{
  return nb;
}

void MAPdist::Distrib::GetPoint(int i,float* x,float* y,float* z)
{
  *x=ptx[i];
  *y=pty[i];
  *z=ptz[i];
}

int MAPdist::Distrib::GenList(int colored)
{
  int i;

  list=glGenLists(1);
  glNewList(list,GL_COMPILE);
  glBegin(GL_POINTS);
  glColor3f(0,0,0);
  for(i=0;i<nb;i++)
    {
      if(colored)
	glColor3f(ptx[i],pty[i],ptz[i]);
      glVertex3f(ptx[i],pty[i],ptz[i]);
    }
  glEnd();
  glEndList();

  return list;
}

float MAPdist::Distrib::GetDensity(float x,float y,float z)
{
  return 0;
}


