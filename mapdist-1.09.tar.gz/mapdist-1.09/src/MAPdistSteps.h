#ifndef MAPdistSTEPS_H
#define MAPdistSTEPS_H

#include <gtk/gtk.h>

namespace MAPdist {

  class Steps
  {
  private:

    GtkWidget* main;

    void (*step_cb)(Steps*,void*);
    void* step_data;

    void (*restart_cb)(Steps*,void*);
    void* restart_data;

    guint32 d;
    int play;
    gint timeout;

  public:

    Steps(const char* title);
    ~Steps(void);

    GtkWidget* GetWidget(void);
    void SetDelay(guint32 delay);
    void SetStepCallback(void (*cb)(Steps*,void*),void* user_data);
    void SetRestartCallback(void (*cb)(Steps*,void*),void* user_data);

    static gint CBTimeout(gpointer data);
    static void CBPlayPause(GtkWidget *widget, gpointer data);
    static void CBStep(GtkWidget *widget, gpointer data);
    static void CBRestart(GtkWidget *widget, gpointer data);
  };

}

#endif
