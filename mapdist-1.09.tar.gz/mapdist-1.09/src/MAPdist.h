#ifndef MAPDIST_H
#define MAPDIST_H

#include <gtk/gtk.h>

#include <MAPdistViewer.h>
#include <MAPdistDistrib.h>
#include <MAPdistMap.h>
#include <MAPdistSteps.h>
#include <MAPdistParams.h>
#include <MAPdistShapes.h>

#endif
