#include "MAPdistShapes.h"
#include <math.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <fstream>


MAPdist::Not::Not(MAPdist::Distrib* arg1)
  :MAPdist::Distrib(arg1)
{
}

float MAPdist::Not::GetDensity(float x,float y,float z)
{

  return 1-dist1->GetDensity(x,y,z);
}



MAPdist::And::And(MAPdist::Distrib* arg1,
		  float _dx,float _dy,float _dz,
		  MAPdist::Distrib* arg2)
  :MAPdist::Distrib(arg1,arg2,_dx,_dy,_dz)
{
}

float MAPdist::And::GetDensity(float x,float y,float z)
{
  float tmp1,tmp2;
  float res;

  res=0;

  if(IsInBounds12(x,y,z))
    {
      tmp1=dist1->GetDensity(x-offset_x1,
			     y-offset_y1,
			     z-offset_z1);
      tmp2=dist2->GetDensity(x-offset_x2,
			     y-offset_y2,
			     z-offset_z2);
      if(tmp1>tmp2)
	res=tmp2;
      else
	res=tmp1;
    }

  return res;
}

MAPdist::Or::Or(MAPdist::Distrib* arg1,
		float _dx,float _dy,float _dz,
		MAPdist::Distrib* arg2)
  :MAPdist::Distrib(arg1,arg2,_dx,_dy,_dz)
{
}

float MAPdist::Or::GetDensity(float x,float y,float z)
{
  float tmp1,tmp2;
  float res;

  res=0;

  if(IsInBounds12(x,y,z))
    {
      tmp1=dist1->GetDensity(x-offset_x1,
			     y-offset_y1,
			     z-offset_z1);
      tmp2=dist2->GetDensity(x-offset_x2,
			     y-offset_y2,
			     z-offset_z2);
      if(tmp1>tmp2)
	res=tmp1;
      else
	res=tmp2;
    }
  else if(IsInBounds1(x,y,z))
    res=dist1->GetDensity(x-offset_x1,
			  y-offset_y1,
			  z-offset_z1);
  else if(IsInBounds2(x,y,z))
    res=dist2->GetDensity(x-offset_x2,
			  y-offset_y2,
			  z-offset_z2);

  return res;
}


MAPdist::Scale::Scale(MAPdist::Distrib* arg1,
		      float factor_x,float factor_y,float factor_z)
  :MAPdist::Distrib(arg1)
{
  fx=factor_x;
  fy=factor_y;
  fz=factor_z;

  dx=arg1->dx*fx;
  dy=arg1->dx*fy;
  dz=arg1->dx*fz;
}

float MAPdist::Scale::GetDensity(float x,float y,float z)
{

  return dist1->GetDensity(x/fx,y/fy,z/fz);
}


#define MAPR(X,Y,Z,x,y,z)	      			\
  X=R11*(x)+R12*(y)+R13*(z);				\
  Y=R21*(x)+R22*(y)+R23*(z);				\
  Z=R31*(x)+R32*(y)+R33*(z)
#define MAPr(X,Y,Z,x,y,z)      			      	\
  X=r11*(x)+r12*(y)+r13*(z);				\
  Y=r21*(x)+r22*(y)+r23*(z);				\
  Z=r31*(x)+r32*(y)+r33*(z)
#define MAPBOUND				\
if(X>maxx)					\
  maxx=X;					\
if(Y>maxy)					\
  maxy=Y;					\
if(Z>maxz)					\
  maxz=Z;					\
if(X<minx)					\
  minx=X;					\
if(Y<miny)					\
  miny=Y;					\
if(Z<minz)					\
  minz=Z


MAPdist::Rotate::Rotate(MAPdist::Distrib* arg1,
			float alpha,float x,float y,float z)
  :MAPdist::Distrib(arg1)
{
  float n,nn;
  float maxx,maxy,maxz;
  float minx,miny,minz;
  float X,Y,Z;
  float a;
  
  nn=pow(x,2)+pow(y,2)+pow(z,2);
  n=sqrt(nn);

  a=alpha*M_PI/180;
  

  R11=x*x/nn+cos(a)*(1-x*x/nn);         R12=x*y/nn-cos(a)*x*y/nn-sin(a)*z/n;    R13=x*y/nn-cos(a)*x*y/nn+sin(a)*y/n;
  R21=x*y/nn-cos(a)*x*y/nn+sin(a)*z/n;  R22=y*y/nn+cos(a)*(1-y*y/nn);           R23=y*z/nn-cos(a)*y*z/nn-sin(a)*x/n;
  R31=x*z/nn-cos(a)*x*z/nn-sin(a)*y/n;  R32=y*z/nn-cos(a)*y*z/nn+sin(a)*x/n;    R33=z*z/nn+cos(a)*(1-z*z/nn); 

  r11=R11; r12=R21; r13=R31;
  r21=R12; r22=R22; r23=R32;
  r31=R13; r32=R23; r33=R33;

  maxx=0;
  maxy=0;
  maxz=0;
  minx=0;
  miny=0;
  minz=0;
  MAPR(X,Y,Z,-dx/2,-dy/2,-dz/2); MAPBOUND;
  MAPR(X,Y,Z,-dx/2,-dy/2, dz/2); MAPBOUND;
  MAPR(X,Y,Z,-dx/2, dy/2,-dz/2); MAPBOUND;
  MAPR(X,Y,Z,-dx/2, dy/2, dz/2); MAPBOUND;
  MAPR(X,Y,Z, dx/2,-dy/2,-dz/2); MAPBOUND;
  MAPR(X,Y,Z, dx/2,-dy/2, dz/2); MAPBOUND;
  MAPR(X,Y,Z, dx/2, dy/2,-dz/2); MAPBOUND;
  MAPR(X,Y,Z, dx/2, dy/2, dz/2); MAPBOUND;

  dx=maxx-minx;
  dy=maxy-miny;
  dz=maxz-minz;
}

float MAPdist::Rotate::GetDensity(float x,float y,float z)
{
  float d;

  float X,Y,Z;
  MAPr(X,Y,Z,x,y,z);
  
  if(dist1->IsInBounds(X,Y,Z))
    d=dist1->GetDensity(X,Y,Z);
  else
    d=0;

  return d;
}

MAPdist::Block::Block(float _dx,float _dy,float _dz,float density)
  :MAPdist::Distrib(_dx,_dy,_dz)
{
  d=density;
}

float MAPdist::Block::GetDensity(float x,float y,float z)
{
  return d;
}


MAPdist::Sphere::Sphere(float density) /* Unit sphere */
  :MAPdist::Distrib(1,1,1)
{
  d=density;
}

float MAPdist::Sphere::GetDensity(float x,float y,float z)
{
  if(x*x+y*y+z*z<=.25)
    return d;
  else
    return 0;
}


MAPdist::Gauss::Gauss(float amplitude,float sigma) 
  :MAPdist::Distrib(1,1,1)
{
  a=amplitude;
  s=sigma*sigma;
}

float MAPdist::Gauss::GetDensity(float x,float y,float z)
{
  return a*exp(-(x*x+y*y+z*z)/s);
}


MAPdist::Cylinder::Cylinder(float density)
  :MAPdist::Distrib(1,1,1)
{
  d=density;
}

float MAPdist::Cylinder::GetDensity(float x,float y,float z)
{
  if(x*x+y*y<=.25)
    return d;
  else
    return 0;
}


MAPdist::Torus::Torus(float tube_radius,float density)
  :MAPdist::Distrib(1+2*tube_radius,1+2*tube_radius,2*tube_radius)
{
  d=density;
  r=tube_radius*tube_radius;
}

float MAPdist::Torus::GetDensity(float x,float y,float z)
{
  float m;

  m=sqrt(x*x+y*y)-.5;
  if(z*z+m*m<=r)
    return d;
  else
    return 0;
}


MAPdist::Picture::Picture(int nb_samples)
  :MAPdist::Distrib(1,1,1)
{
  width=0;
  height=0;
  img=(unsigned char*)NULL;
  nb_samp=nb_samples;
}

MAPdist::Picture::~Picture(void)
{
  delete [] img;
}

float MAPdist::Picture::GetDensity(float x,float y,float z) 
{
  return 0;
}

void MAPdist::Picture::Build(void)
{
  int img_size;
  int i,k;

  if(img==NULL)
    nb=0;
  else
    {
      AskForSize(nb_samp);
      img_size=width*height;
      
      for(i=0;i<nb_samp;i++)
	{
	  k=(int)(img_size*(rand()/(RAND_MAX+1.0)))*3;
	  ptx[i]=img[k  ]/255.0;
	  pty[i]=img[k+1]/255.0;
	  ptz[i]=img[k+2]/255.0;
	}
      nb=nb_samp;
    }
}

bool MAPdist::Picture::Load(std::string file_name)
{
  std::string header;
  std::string comment;
  std::ifstream file;
  char first;
  bool rgb;
  int w,h,k;
  
  delete [] img;
  img=(unsigned char*)NULL;

  file.open(file_name.c_str());
  if(!file)
    return false;

  file >> header;
  if(header=="P6")
    rgb=true;
  else if(header=="P5")
    rgb=false;
  else
    return false;

  std::getline(file,comment);
  
  file.get(first);
  file.putback(first);
  while(first=='#')
    {
      std::getline(file,comment);
      file.get(first);
      file.putback(first);
    }
  
  file >> width >> height;
  
  std::getline(file,comment); // \n
  std::getline(file,comment); // 255

  delete [] img;
  img=new unsigned char[width*height*3];
  if(rgb)
    for(h=0,k=0;h<height;h++)
      for(w=0;w<width*3;w++,k++)
	{
	  file.get(first);
	  img[k]=first;
	}
  else
    for(h=0,k=0;h<height;h++)
      for(w=0;w<width;w++)
	{
	  file.get(first);
	  img[k]=first; k++;
	  img[k]=first; k++;
	  img[k]=first; k++;
	}
  
  
  file.close();
  return true;
}
    
