#ifndef MAPdistPARAMS_H
#define MAPdistPARAMS_H

#include <gtk/gtk.h>

namespace MAPdist {
  class Params
    {
    private: 
  
      GtkWidget* main;
      GtkWidget *hbox1;
      GtkAdjustment** adj;
      int nb;
      int size;

    public: 

      Params(const char* title,GtkShadowType shadow=GTK_SHADOW_ETCHED_IN);
      ~Params(void);

      GtkWidget* GetWidget(void);
      int Add(const char* name,
	      float init,float min,float max,
	      float small_inc,float big_inc,
	      int decimals,
	      GtkShadowType shadow=GTK_SHADOW_ETCHED_OUT);
      float GetValue(int idf);

    };
}

#endif
