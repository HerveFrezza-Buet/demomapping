#ifndef MAPdistSHAPES_H
#define MAPdistSHAPES_H

#include <MAPdistDistrib.h>
#include <string>

namespace MAPdist {
  class Not : public Distrib
  {
  protected:


  public:
    Not(Distrib* arg1);
    virtual float GetDensity(float x,float y,float z);
  };

  class And : public Distrib
  {
  protected:


  public:
    And(Distrib* arg1,
	float _dx,float _dy,float _dz,
	Distrib* arg2);
    virtual float GetDensity(float x,float y,float z);
  };

  class Or : public Distrib
  {
  protected:


  public:
    Or(Distrib* arg1,
       float _dx,float _dy,float _dz,
       Distrib* arg2);
    virtual float GetDensity(float x,float y,float z);
  };

  class Scale : public Distrib
  {
  protected:

    float fx,fy,fz;

  public:
    Scale(Distrib* arg1,
	  float factor_x,float factor_y,float factor_z);
    virtual float GetDensity(float x,float y,float z);
  };

  class Rotate : public Distrib
  {
  protected:

    float 
    R11,R12,R13,
      R21,R22,R23,
      R31,R32,R33;
    float 
    r11,r12,r13,
      r21,r22,r23,
      r31,r32,r33;

  public:
    Rotate(Distrib* arg1,
	   float alpha /* degree */,float x,float y,float z);
    virtual float GetDensity(float x,float y,float z);
  };

  class Block : public Distrib
  {
  protected:

    float d;

  public:
    Block(float _dx,float _dy,float _dz,float density);
    virtual float GetDensity(float x,float y,float z);
  };

  class Sphere : public Distrib
  {
  protected:

    float d;

  public:
    Sphere(float density);
    virtual float GetDensity(float x,float y,float z);
  };

  class Gauss : public Distrib
  {
  protected:

    float a,s;

  public:
    Gauss(float amplitude,float sigma);
    virtual float GetDensity(float x,float y,float z);
  };

  class Cylinder : public Distrib
  {
  protected:

    float d;

  public:
    Cylinder(float density);
    virtual float GetDensity(float x,float y,float z);
  };


  class Torus : public Distrib
  {
  protected:

    float d;
    float r;

  public:
    Torus(float tube_radius,float density);
    virtual float GetDensity(float x,float y,float z);
  };


  // This cannot be used in And Or, etc..
  class Picture : public Distrib
  {
  protected:
    
    int nb_samp;
    
  public: 

    unsigned char* img;
    int width, height;

    Picture(int nb_samples);
    ~Picture(void);

    virtual void Build(void);

    // Loads from a raw ppm file.
    bool Load(std::string file_name);
    
    virtual float GetDensity(float x,float y,float z);
  };

}

#endif
