#include <MAPdistSteps.h>


MAPdist::Steps::Steps(const char* title)
{
  GtkWidget *vbuttonbox1;
  GtkWidget *button1;
  GtkWidget *button2;
  GtkWidget *button3;

  d=10;
  play=0;
  step_cb=(void (*)(MAPdist::Steps*,void*))NULL;
  step_data=NULL;
  restart_cb=(void (*)(MAPdist::Steps*,void*))NULL;
  restart_data=NULL;

  
  main = gtk_frame_new (title);
  gtk_widget_show (main);
  gtk_container_set_border_width (GTK_CONTAINER (main), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (main), GTK_SHADOW_ETCHED_IN);

  vbuttonbox1 = gtk_vbutton_box_new ();
  gtk_widget_show (vbuttonbox1);
  gtk_container_add (GTK_CONTAINER (main), vbuttonbox1);  
  gtk_container_set_border_width (GTK_CONTAINER (vbuttonbox1), 5);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (vbuttonbox1), GTK_BUTTONBOX_SPREAD);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (vbuttonbox1), 0);

  button1 = gtk_button_new_with_label ("Play/Pause");
  gtk_widget_ref (button1);
  gtk_widget_show (button1);
  gtk_container_add (GTK_CONTAINER (vbuttonbox1), button1);
  GTK_WIDGET_SET_FLAGS (button1, GTK_CAN_DEFAULT);

  button2 = gtk_button_new_with_label ("Step");
  gtk_widget_show (button2);
  gtk_container_add (GTK_CONTAINER (vbuttonbox1), button2);
  GTK_WIDGET_SET_FLAGS (button2, GTK_CAN_DEFAULT);

  button3 = gtk_button_new_with_label ("Restart");
  gtk_widget_show (button3);
  gtk_container_add (GTK_CONTAINER (vbuttonbox1), button3);
  GTK_WIDGET_SET_FLAGS (button3, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (button1), "clicked",
                      GTK_SIGNAL_FUNC (MAPdist::Steps::CBPlayPause),
                      (gpointer)this);
  gtk_signal_connect (GTK_OBJECT (button2), "clicked",
                      GTK_SIGNAL_FUNC (MAPdist::Steps::CBStep),
                      (gpointer)this);
  gtk_signal_connect (GTK_OBJECT (button3), "clicked",
                      GTK_SIGNAL_FUNC (MAPdist::Steps::CBRestart),
                      (gpointer)this);
  
}

MAPdist::Steps::~Steps(void)
{
}

GtkWidget* MAPdist::Steps::GetWidget(void)
{
  return main;
}

void MAPdist::Steps::SetDelay(guint32 delay)
{
  d=delay;
}

void MAPdist::Steps::SetStepCallback(void (*cb)(MAPdist::Steps*,void*),void* user_data)
{
  step_cb=cb;
  step_data=user_data;
}

void MAPdist::Steps::SetRestartCallback(void (*cb)(MAPdist::Steps*,void*),void* user_data)
{
  restart_cb=cb;
  restart_data=user_data;
}

gint MAPdist::Steps::CBTimeout(gpointer data)
{
  
  MAPdist::Steps* that;

  that=(MAPdist::Steps*)data;

  if(that->play)
    {
      if(that->step_cb!=NULL)
	(*that->step_cb)(that,that->step_data);
      that->timeout=gtk_timeout_add(that->d,MAPdist::Steps::CBTimeout,(gpointer)that);
    }

  return FALSE;
}

void MAPdist::Steps::CBPlayPause(GtkWidget *widget, gpointer data)
{
  MAPdist::Steps* that;

  that=(MAPdist::Steps*)data;

  if(that->play)
    {
      that->play=0;
      gtk_timeout_remove(that->timeout);
    }
  else
    {
      that->play=1;
      that->timeout=gtk_timeout_add(that->d,CBTimeout,(gpointer)that);
    }
  
}

void MAPdist::Steps::CBStep(GtkWidget *widget, gpointer data)
{
  MAPdist::Steps* that;

  that=(MAPdist::Steps*)data;

  if(that->play)
    {
      that->play=0;
      gtk_timeout_remove(that->timeout);
    }

  if(that->step_cb!=NULL)
    (*that->step_cb)(that,that->step_data);
}

void MAPdist::Steps::CBRestart(GtkWidget *widget, gpointer data)
{
  MAPdist::Steps* that;

  that=(MAPdist::Steps*)data;

  if(that->play)
    {
      that->play=0;
      gtk_timeout_remove(that->timeout);
    }

  if(that->restart_cb!=NULL)
    (*that->restart_cb)(that,that->restart_data);
}
