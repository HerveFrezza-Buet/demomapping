#ifndef MAPdistVIEWER_H
#define MAPdistVIEWER_H

#include <gtk/gtk.h>
#include <glop.h>
#include <glop-gtk.h>
#include <MAPdistDistrib.h>

namespace MAPdist {
  class  Viewer : public glop::gtkScene
  {
  private:
  
    GtkWidget* main;
    GtkWidget* gl;

    static void MoveTheWholeScene(glop::Drawable* that);

    class Stuff : public glop::Drawable,
		  public glop::Texture {

    protected:

      void InitDrawings(glop::Scene* scene);
      void Draw(glop::Scene* scene);

    public:
      Distrib* distrib;
      int gl_dist;
      int gl_axis;
      int gl_sphere;
      GLuint tex_idf(void) {return texture_idf;}
      
      void (*draw_cb)(Viewer*,void*);
      void* draw_data;
      
      int col_dist;
      int has_been_init;
    };

    Stuff stuff;
    glop::OrbitInteractiveView* view;


  public :

    Viewer(const char* title,
	   int colored_distribs);
    ~Viewer(void);

    GtkWidget* GetWidget(void);
    void SetDrawingCallback(void (*cb)(Viewer*,void*),void* user_data);
  
    void ChooseRandomPoint(float* x,float* y,float* z);
    void SetDistrib(Distrib* dist); /* dist will be deleted ! */
    Distrib* GetDistrib(void); /* dist will be deleted ! */
    void Redisplay(void);

    virtual void CbkInit(void);

    /* ########################### */
    /* #                         # */
    /* # Within Drawing Callback # */
    /* #                         # */
    /* ########################### */
    /*           ###               */
    /*           ###               */
    /*         #######             */
    /*          #####              */
    /*           ###               */
    /*            #                */

    void SetDrawingColor(float r,float g,float b); /* 0..1,0..1,0..1 */
    void DrawAxis(void);
    void DrawDistrib(int point_size=1);
    void DrawLine(float x1, float y1,float z1,
		  float x2, float y2,float z2);
    void DrawPrototype(float x, float y,float z,float radius=.02);
    void BeginDrawingPoints(int point_size);
    void DrawPoint(float x, float y, float z);
    void EndDrawingPoints(void);

    void PostTexture(int side,
		     unsigned char* rgb_data);
    void BeginDrawingTexPoints(int point_size);
    void DrawPoint(float x, float y, float z, float s, float t);
    void EndDrawingTexPoints(void);
  };
}


#endif
