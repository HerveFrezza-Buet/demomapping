#include "MAPdistParams.h"


#define MAPdistPARAMS_PAD 100


MAPdist::Params::Params(const char* title,GtkShadowType shadow)
{

  main = gtk_frame_new (title);
  gtk_widget_show (main);
  gtk_container_set_border_width (GTK_CONTAINER (main), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (main), shadow);

  hbox1 = gtk_hbox_new (TRUE, 5);
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (main), hbox1);
  gtk_container_set_border_width (GTK_CONTAINER (hbox1), 5);

  adj=new GtkAdjustment*[MAPdistPARAMS_PAD];
  nb=0;
  size=MAPdistPARAMS_PAD;

}

MAPdist::Params::~Params(void)
{
  delete [] adj;
}

GtkWidget* MAPdist::Params::GetWidget(void)
{
  return main;
}

int MAPdist::Params::Add(const char* name,
			 float init,float min,float max,
			 float small_inc,float big_inc,
			 int decimals,
			 GtkShadowType shadow)
{
  GtkWidget *frame;
  GtkWidget *frame2;
  GtkWidget *vscale;
  GtkAdjustment** tmp;
  int i;
  int idf;

  if(nb>=size)
    {
      tmp=new GtkAdjustment*[size+MAPdistPARAMS_PAD];
      for(i=0;i<size;i++)
	tmp[i]=adj[i];
      delete [] adj;
      adj=tmp;
    }

  adj[nb]=GTK_ADJUSTMENT(gtk_adjustment_new (init,
					     min, max, 
					     small_inc,big_inc,
					     0));
  idf=nb;
  nb++;

  frame = gtk_frame_new (name);
  gtk_widget_show (frame);
  gtk_box_pack_start (GTK_BOX (hbox1), frame, TRUE, TRUE, 0);
  gtk_frame_set_shadow_type (GTK_FRAME (frame), shadow);

  frame2 = gtk_frame_new ((char*)NULL);
  gtk_widget_show (frame2);
  gtk_container_add (GTK_CONTAINER (frame), frame2);
  gtk_container_set_border_width (GTK_CONTAINER (frame2), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame2), GTK_SHADOW_NONE);

  vscale = gtk_vscale_new (adj[idf]);
  gtk_widget_show (vscale);
  gtk_container_add (GTK_CONTAINER (frame2), vscale);
  gtk_scale_set_value_pos (GTK_SCALE (vscale), GTK_POS_RIGHT);
  gtk_scale_set_digits (GTK_SCALE (vscale), decimals);

  return idf;
}

float MAPdist::Params::GetValue(int idf)
{
  return (float)adj[idf]->value;
}
