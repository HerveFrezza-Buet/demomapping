#include <GL/gl.h>
#include <GL/glu.h>
#include <gtk/gtk.h>
#include <gtk/gtkgl.h>

#include <iostream>

#include "MAPdistViewer.h"

/* Colors */
#define _BACKGROUND        .8,   .8,  .8
#define BACKGROUND    { _BACKGROUND }
#define AMBIENT       {    .4,  .4,  .4,  1}
#define THIN_LINE          .7,  .7,  .7,  1


void MAPdist::Viewer::MoveTheWholeScene(glop::Drawable* that)
{
  glTranslatef(-.5,-.5,-.5);
}

MAPdist::Viewer::Viewer(const char* title,
			int colored_distribs)
  :glop::gtkScene(320,240)
{
  GtkWidget* frame1;

  stuff.draw_cb=(void (*)(MAPdist::Viewer*,void*))NULL;
  stuff.draw_data=NULL;
  stuff.col_dist=colored_distribs;
  stuff.distrib=(MAPdist::Distrib*)NULL;
  stuff.has_been_init=0;

  main = gtk_frame_new (title);
  gtk_widget_show (main);
  gtk_container_set_border_width (GTK_CONTAINER (main), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (main), GTK_SHADOW_ETCHED_IN);

  frame1 = gtk_frame_new ((char*)NULL);
  gtk_widget_show (frame1);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame1), GTK_SHADOW_IN);
  gtk_container_add (GTK_CONTAINER (main), frame1);  

  gl=glop::gtkScene::GetWidget();
  gtk_widget_show(gl);
  gtk_container_add (GTK_CONTAINER (frame1), gl);  


  // Drawings 
  view       = new glop::OrbitInteractiveView;

  AddMouseEvent(view);
  AddDrawable(&stuff,MoveTheWholeScene);
  

}

MAPdist::Viewer::~Viewer(void)
{
  delete stuff.distrib;
  delete view;
}

GtkWidget* MAPdist::Viewer::GetWidget(void)
{
  return main;
}

void MAPdist::Viewer::SetDrawingCallback(void (*cb)(MAPdist::Viewer*,void*),
					 void* user_data)
{
  stuff.draw_data=user_data;
  stuff.draw_cb=cb;
}
  
void MAPdist::Viewer::ChooseRandomPoint(float* x,float* y,float* z)
{
  if(stuff.distrib!=NULL)
    stuff.distrib->GetPoint((int) (((double)(stuff.distrib->GetNbPoints()))*rand()/(RAND_MAX+1.0)),
			    x,y,z);
  else
    {
      *x=0;
      *y=0;
      *z=0;
    }
}

MAPdist::Distrib* MAPdist::Viewer::GetDistrib(void)
{
  return stuff.distrib;
}

void MAPdist::Viewer::SetDistrib(MAPdist::Distrib* dist)
{
  GdkGLContext *glcontext;
  GdkGLDrawable *gldrawable;

  delete stuff.distrib;
  stuff.distrib=dist;

  if(stuff.has_been_init)
    {
      glcontext = gtk_widget_get_gl_context (gl);
      gldrawable = gtk_widget_get_gl_drawable (gl);

      if (gdk_gl_drawable_gl_begin (gldrawable, glcontext)) {
	glDeleteLists(stuff.gl_dist,1);
	stuff.gl_dist=stuff.distrib->GenList(stuff.col_dist);
	gdk_gl_drawable_gl_end (gldrawable);
      }
    }
}

void MAPdist::Viewer::Redisplay(void)
{
  Refresh();
}

void MAPdist::Viewer::DrawAxis(void)
{
  glCallList(stuff.gl_axis);
}

void MAPdist::Viewer::DrawDistrib(int point_size)
{
  glPointSize(point_size);
  glCallList(stuff.gl_dist);
  glPointSize(1);
}

void MAPdist::Viewer::DrawPrototype(float x, float y,float z,float radius)
{
  glPushMatrix();
  glTranslatef(x,y,z);
  glScalef(radius,radius,radius);
  glCallList(stuff.gl_sphere);
  glPopMatrix();
}
void MAPdist::Viewer::BeginDrawingPoints(int point_size) {
  glPointSize(point_size);
  glBegin(GL_POINTS);
}

void MAPdist::Viewer::DrawPoint(float x, float y, float z) {
  glVertex3f(x,y,z);
}

void MAPdist::Viewer::DrawPoint(float x, float y, float z, 
				float s, float t) {
  glTexCoord2f(s,t);
  glVertex3f(x,y,z);
}

void MAPdist::Viewer::EndDrawingPoints(void) {
  glEnd();
  glPointSize(0);
}


void MAPdist::Viewer::PostTexture(int side,
				  unsigned char* rgb_data) {
  glBindTexture(GL_TEXTURE_2D,stuff.tex_idf());
  glPixelStorei(GL_UNPACK_ALIGNMENT,1); 
  glTexImage2D(GL_TEXTURE_2D,
	       0,      
	       GL_RGB, side, side,
	       0,  
	       GL_RGB,    
	       GL_UNSIGNED_BYTE,   
	       rgb_data);
}

void MAPdist::Viewer::BeginDrawingTexPoints(int point_size) {
  glPointSize(point_size);
  stuff.BeginTexturing();
  glBegin(GL_POINTS);
}

void MAPdist::Viewer::EndDrawingTexPoints(void) {
  glEnd();
  stuff.EndTexturing();
  glPointSize(0);
}



void MAPdist::Viewer::DrawLine(float x1, float y1,float z1,
			       float x2, float y2,float z2)
{
  glBegin(GL_LINES);
  /*  */ glVertex3f(x1,y1,z1);
  /*  */ glVertex3f(x2,y2,z2);
  glEnd();
}

void MAPdist::Viewer::SetDrawingColor(float r,float g,float b)
{
  glColor3f(r,g,b);
}

void MAPdist::Viewer::Stuff::Draw(glop::Scene* scene)
{
  if(draw_cb!=NULL)
    (*draw_cb)((MAPdist::Viewer*)scene,draw_data);
}

void MAPdist::Viewer::CbkInit(void) {
  
  glop::gtkScene::CbkInit();
  SetBackgroundColor(_BACKGROUND);
}

void MAPdist::Viewer::Stuff::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;

  InitTexturing();

  params = gluNewQuadric();
  gluQuadricDrawStyle   (params,GLU_FILL);    // Polygon filled.
  gluQuadricNormals     (params,GLU_SMOOTH);  // Lighting smooth
  gluQuadricOrientation (params,GLU_OUTSIDE); // Normals outside.
  gluQuadricTexture     (params,GL_FALSE);    // Do not generate texture coords.

  
    
  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL); 

  /* Lists */
  gl_sphere=glGenLists(1);
  glNewList(gl_sphere,GL_COMPILE);
  gluSphere(params,1,7,5);
  glEnd();
  glEndList();
  

  gl_axis=glGenLists(1);
  glNewList(gl_axis,GL_COMPILE);
  if(col_dist) 
    {
      glColor3f(1,0,0);
      glBegin(GL_LINES);
      /*  */ glVertex3f(0,0,0);
      /*  */ glVertex3f(1,0,0);
      glEnd();
      glColor3f(0,1,0);
      glBegin(GL_LINES);
      /*  */ glVertex3f(0,0,0);
      /*  */ glVertex3f(0,1,0);
      glEnd();
      glColor3f(0,0,1);
      glBegin(GL_LINES);
      /*  */ glVertex3f(0,0,0);
      /*  */ glVertex3f(0,0,1);
      glEnd();
    }
  else
    {
      glColor3f(0,0,0);
      glBegin(GL_LINES);
      /*  */ glVertex3f(0,0,0);
      /*  */ glVertex3f(1,0,0);
      glEnd();
      glBegin(GL_LINES);
      /*  */ glVertex3f(0,0,0);
      /*  */ glVertex3f(0,1,0);
      glEnd();
      glBegin(GL_LINES);
      /*  */ glVertex3f(0,0,0);
      /*  */ glVertex3f(0,0,1);
      glEnd();
    }
  glColor4f(THIN_LINE);
  glBegin(GL_LINES);
  /*  */ glVertex3f(1,1,1);
  /*  */ glVertex3f(1,1,0);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(1,1,1);
  /*  */ glVertex3f(0,1,1);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(1,1,1);
  /*  */ glVertex3f(1,0,1);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(1,1,0);
  /*  */ glVertex3f(0,1,0);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(0,1,0);
  /*  */ glVertex3f(0,1,1);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(0,1,1);
  /*  */ glVertex3f(0,0,1);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(0,0,1);
  /*  */ glVertex3f(1,0,1);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(1,0,1);
  /*  */ glVertex3f(1,0,0);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(1,0,0);
  /*  */ glVertex3f(1,1,0);
  glEnd();
  glEndList();

  if(distrib!=NULL)
    gl_dist=distrib->GenList(col_dist);
  else
    {
      gl_dist=glGenLists(1);
      glNewList(gl_dist,GL_COMPILE);
      glEndList();
    }

  has_been_init=1;
}
