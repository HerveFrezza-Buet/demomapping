#include "MAPdistMap.h"


gint MAPdist::Map::CBExpose(GtkWidget *widget,GdkEventExpose *event,gpointer data)
{
  MAPdist::Map* that;

  // Draw only last expose
  if (event->count <= 0) 
    {
      that=(MAPdist::Map*)data;
      that->exposed=1;
      that->Redisplay();
    }
  
  return (TRUE);
}


void MAPdist::Map::Resize(int w,int h)
{
  int k;

  width=w;
  height=h;

  delete [] colors;
  colors=new GdkColor[width*height];

  for(k=0,h=0;h<height;h++)
    for(w=0;w<width;w++,k++)
      {
	gdk_color_parse("DimGrey",
			&(colors[k]));
	gdk_colormap_alloc_color(colormap,
				 &(colors[k]),
				 FALSE, /* not writable */
				 TRUE); /* best match allowed */
      }

  gtk_drawing_area_size(GTK_DRAWING_AREA(pad),
			width*size,
			height*size);
  gtk_widget_set_usize(pad,
		       width*size,
		       height*size);
  gtk_widget_queue_draw(pad); 
}

MAPdist::Map::Map(const char* title,
		  int w,int h,
		  int cell_size)
{
  GtkWidget* frame1;

  size=cell_size;
  gc=(GdkGC*)NULL;
  exposed=0;

  colors=(GdkColor*)NULL;

  main = gtk_frame_new (title);
  gtk_widget_show (main);
  gtk_container_set_border_width (GTK_CONTAINER (main), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (main), GTK_SHADOW_ETCHED_IN);

  frame1 = gtk_frame_new ((char*)NULL);
  gtk_widget_show (frame1);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame1), GTK_SHADOW_IN);
  gtk_container_add (GTK_CONTAINER (main), frame1); 

  pad = gtk_drawing_area_new ();
  gtk_widget_show (pad);
  gtk_container_add(GTK_CONTAINER(frame1),
		    pad);
  gtk_widget_set_events (pad,
			 GDK_EXPOSURE_MASK);
  gtk_signal_connect (GTK_OBJECT (pad), "expose_event",
		      GTK_SIGNAL_FUNC (MAPdist::Map::CBExpose),
		      (gpointer)this);

  colormap=gdk_colormap_get_system();
  
  gdk_color_parse("black",
		  &col_black);
  gdk_colormap_alloc_color(colormap,
			   &col_black,
			   FALSE, /* not writable */
			   TRUE); /* best match allowed */
  Resize(w,h);

}

MAPdist::Map::~Map(void)
{
  delete [] colors;
}

void MAPdist::Map::SetValue (int w,int h,
			   float x,float y,float z)
{
  int k;

  if(x<0)
    x=0;
  if(x>1)
    x=1;

  if(y<0)
    y=0;
  if(y>1)
    y=1;

  if(z<0)
    z=0;
  if(z>1)
    z=1;

  k=h*width+w;
  colors[k].red=(gushort)(x*65535);
  colors[k].green=(gushort)(y*65535);
  colors[k].blue=(gushort)(z*65535);

  if(exposed)
    gdk_colormap_alloc_color(colormap,
			     &(colors[k]),
			     FALSE, /* not writable */
			     TRUE); /* best match allowed */
}

void MAPdist::Map::Redisplay(void)
{
  int w,h,k;

  if(exposed)
    {
      if(gc==NULL)
	{
	  gc=gdk_gc_new(pad->window);
	  for(k=0,h=0;h<height;h++)
	    for(w=0;w<width;w++,k++)
	      gdk_colormap_alloc_color(colormap,
				       &(colors[k]),
				       FALSE, /* not writable */
				       TRUE); /* best match allowed */
	}

      for(k=0,h=0;h<height;h++)
	for(w=0;w<width;w++,k++)
	  {
	    gdk_gc_set_foreground(gc,
				  &(colors[k]));
	    gdk_draw_rectangle(pad->window,
			       gc,
			       TRUE,
			       w*size,h*size,size,size);
	  }
      
      gdk_gc_set_foreground(gc,
			    &col_black);
      for(k=0,h=0;h<height;h++)
	for(w=0;w<width;w++,k++)
	  gdk_draw_rectangle(pad->window,
			     gc,
			     FALSE,
			     w*size,h*size,size,size);
    }
}

GtkWidget* MAPdist::Map::GetWidget(void)
{
  return main;
}
