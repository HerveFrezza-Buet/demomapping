#ifndef MAPdistDISTRIB_H
#define MAPdistDISTRIB_H


namespace MAPdist {

  class Distrib
  {
  private:

  protected:

    static float resolution;

    float trans_x,trans_y,trans_z;
    float offset_x1,offset_y1,offset_z1;
    float offset_x2,offset_y2,offset_z2;
  
    float *ptx,*pty,*ptz;
    int nb;
    int size;

    int list;

    void AskForSize(int i);

  public:

    Distrib* dist1;
    Distrib* dist2;
    float dx,dy,dz; /* size */
    int IsInBounds(float x,float y,float z);
    int IsInBounds1(float x,float y,float z);
    int IsInBounds2(float x,float y,float z);
    int IsInBounds12(float x,float y,float z);

  public:
    
    static void SetResolution(float  res);
    
    /* The distribution is centered. Translate it ! */
    Distrib(float _dx,float _dy,float _dz); /* This is size */
    Distrib(Distrib* arg1); 
    Distrib(Distrib* arg1,
	    Distrib* arg2,
	    float off_x,float off_y,float off_z); 
    virtual ~Distrib(void);

    void Translate(float x,float y,float z);
    virtual void Build(void); /* Builds a list of points */

    virtual float GetDensity(float x,float y,float z); 
    /* origin is always the center of the block,
       ignoring translation */

    /* After building */
    int GetNbPoints(void);
    void GetPoint(int i,float* x,float* y,float* z);
    int GenList(int colored);
  };


}


#endif
