#ifndef MAPdistMAP_H
#define MAPdistMAP_H

#include <gtk/gtk.h>

namespace MAPdist {

  class Map
  {
  private:

    GtkWidget* main;
    GtkWidget* pad;
    int width,height;
    int size;
    int exposed;

    GdkColormap* colormap;
    GdkColor* colors;
    GdkColor col_black;
    GdkGC* gc;
  
  public:
  
    Map(const char* title,
	int w,int h,
	int cell_size);
    ~Map(void);
  
    GtkWidget* GetWidget(void);
    void SetValue (int w,int h,
		   float x,float y,float z);
    void Redisplay(void);

    void Resize(int w,int h);
  
    static gint CBExpose(GtkWidget *widget,
			 GdkEventExpose *event,
			 gpointer data);
  };

}

#endif
