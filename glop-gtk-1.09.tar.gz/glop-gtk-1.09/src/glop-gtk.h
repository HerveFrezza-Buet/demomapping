#ifndef gtkSCENE_H
#define gtkSCENE_H

#include <glop.h>

#include <gtk/gtk.h>
#include <gtk/gtkgl.h>

namespace glop{

  class gtkScene : public Scene {
    
  private :
    
    bool first_exposure;
    int _time_period;
    GtkWidget *drawing_area;  // widget GtkGLArea
    GdkGLConfig *glconfig;
    static void gl_realize (GtkWidget *widget,gpointer   data);
    static gboolean gl_configure_event (GtkWidget *widget,GdkEventConfigure *event,gpointer data);
    static gboolean gl_expose_event (GtkWidget *widget,GdkEventExpose *event,gpointer data);
    static gint gl_motion_notify(GtkWidget* widget, GdkEventMotion* event,gpointer data);
    static gint gl_button_press(GtkWidget* widget, GdkEventButton* event,gpointer data);
    static gint on_time(gpointer data);
    
  protected :
    
  public :
    
    gtkScene(int width,int height,int time_period_ms=50);
    virtual ~gtkScene(void);
    
    virtual void Refresh(void);
    GtkWidget* GetWidget(void);
    void Resize(int width,int height);
    
  };
}


#endif
