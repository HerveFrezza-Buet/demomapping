
#include "glop-gtk.h"

#include <iostream>
#include <stdlib.h>


glop::gtkScene::gtkScene(int width,int height,int time_period_ms)
  :glop::Scene()
{
  GdkGLConfigMode config_mode,old_config_mode;
  GdkGLConfig* glconfig_tmp;

  drawing_area=gtk_drawing_area_new ();
  gtk_widget_set_size_request (drawing_area, width, height);

  first_exposure=true;

  // Probe gl device (sorry for memory leaks...)
  old_config_mode=(GdkGLConfigMode)0;
  g_print("\n");
  g_print("Probing openGL config :\n");
  g_print("---------------------  \n");
  g_print("\n");

  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_RGB);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig_tmp==NULL)
    {
      config_mode=old_config_mode;
      g_print("  RGB          [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  RGB          [  OK  ]\n");
      glconfig = glconfig_tmp;
      
    }

  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_RGBA);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig_tmp==NULL)
    {
      config_mode=old_config_mode;
      g_print("  RGBA         [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  RGBA         [  OK  ]\n");
      glconfig = glconfig_tmp;
    }

  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_DOUBLE);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig_tmp==NULL)
    {
      config_mode=old_config_mode;
      g_print("  DOUBLE       [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  DOUBLE       [  OK  ]\n");
      glconfig = glconfig_tmp;
    }

  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_DEPTH);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig==NULL)
    {
      config_mode=old_config_mode;
      g_print("  DEPTH        [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  DEPTH        [  OK  ]\n");
      glconfig = glconfig_tmp;
    }

  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_ALPHA);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig_tmp==NULL)
    {
      config_mode=old_config_mode;
      g_print("  ALPHA        [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  ALPHA        [  OK  ]\n");
      glconfig = glconfig_tmp;
    }

  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_STENCIL);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig_tmp==NULL)
    {
      config_mode=old_config_mode;
      g_print("  STENCIL      [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  STENCIL      [  OK  ]\n");
      glconfig = glconfig_tmp;
    }


  config_mode=(GdkGLConfigMode)(old_config_mode | GDK_GL_MODE_ACCUM);
  glconfig_tmp = gdk_gl_config_new_by_mode (config_mode);
  if(glconfig_tmp==NULL)
    {
      config_mode=old_config_mode;
      g_print("  ACCUM        [FAILED]\n");
    }
  else
    {
      old_config_mode=config_mode;
      g_print("  ACCUM        [  OK  ]\n");
      glconfig = glconfig_tmp;
    }
  
  
  
  if (glconfig == NULL)
    {
      g_print ("\n*** No appropriate OpenGL-capable visual found.\n");
      g_print("\n\n");
      exit (1);
    }

  g_print("\n\n");

  /* Set OpenGL-capability to the widget. */
  gtk_widget_set_gl_capability (drawing_area,
				glconfig,
				NULL,
				TRUE,
				GDK_GL_RGBA_TYPE);
  gtk_widget_add_events (drawing_area,
			 GDK_EXPOSURE_MASK |
			 GDK_BUTTON_PRESS_MASK |
			 GDK_BUTTON_RELEASE_MASK |
			 GDK_BUTTON_MOTION_MASK |
			 GDK_POINTER_MOTION_MASK);

  g_signal_connect_after (G_OBJECT (drawing_area), "realize",
                          G_CALLBACK (gl_realize), (void*)this);
  g_signal_connect (G_OBJECT (drawing_area), "configure_event",
		    G_CALLBACK (gl_configure_event), (void*)this);
  g_signal_connect (G_OBJECT (drawing_area), "expose_event",
		    G_CALLBACK (gl_expose_event), (void*)this);
  g_signal_connect (G_OBJECT(drawing_area), "button_press_event", 
		    G_CALLBACK(gl_button_press), (void*)this);
  g_signal_connect (G_OBJECT(drawing_area), "motion_notify_event", 
		    G_CALLBACK(gl_motion_notify), (void*)this);


  // The timout 
  _time_period=time_period_ms;
  gtk_timeout_add(_time_period,on_time,(void*)this);
}

glop::gtkScene::~gtkScene(void)
{
}
    
void glop::gtkScene::Resize(int width,int height) {
  gtk_widget_set_size_request (drawing_area, width, height);
}



GtkWidget* glop::gtkScene::GetWidget(void)
{
  return drawing_area;
}

gint glop::gtkScene::gl_button_press(GtkWidget* widget, 
				      GdkEventButton* event,
				      gpointer data) {

  int x = (int)event->x;  
  int y = (int)event->y;
  
  switch(event->button)
    {
    case 1:
      ((glop::Scene*)data)->CbkClickNotify(glop::buttonLeft,x,y);
      break;
    case 2:
      ((glop::Scene*)data)->CbkClickNotify(glop::buttonMiddle,x,y);
      break;
    case 3:
      ((glop::Scene*)data)->CbkClickNotify(glop::buttonRight,x,y);
      break;
    default:
      break;
    }

  return FALSE;
}

gint glop::gtkScene::gl_motion_notify(GtkWidget* widget, 
				GdkEventMotion* event,
				gpointer data) {

  int x;  
  int y;  
  glop::Button b;
  GdkModifierType state;  

  if (event->is_hint)
  {
    gdk_window_get_pointer(event->window, &x, &y, &state);
  } 
  else 
  {
    x = (int)event->x;
    y = (int)event->y;
    state = (GdkModifierType)event->state;
  }

  if(state & GDK_BUTTON1_MASK)
    b=glop::buttonLeft;
  else if(state & GDK_BUTTON2_MASK)
    b=glop::buttonMiddle;
  else if(state & GDK_BUTTON3_MASK)
    b=glop::buttonRight;
  else
    b=glop::buttonNone;

  ((glop::Scene*)data)->CbkMotionNotify(b,x,y);
  
  return TRUE;
}


void glop::gtkScene::gl_realize (GtkWidget *widget,
				  gpointer   data)
{
  
//   GdkGLContext *glcontext = gtk_widget_get_gl_context (widget);
//   GdkGLDrawable *gldrawable = gtk_widget_get_gl_drawable (widget);
  
//   /*** OpenGL BEGIN ***/
//   if (!gdk_gl_drawable_gl_begin (gldrawable, glcontext))
//     return;

//   ((glop::Scene*)data)->CbkInit();
  
//   gdk_gl_drawable_gl_end (gldrawable);
//   /*** OpenGL END ***/
}

gboolean glop::gtkScene::gl_configure_event (GtkWidget *widget,
					      GdkEventConfigure *event,
					      gpointer data)
{
  int gl_width;
  int gl_height;

  GdkGLContext *glcontext = gtk_widget_get_gl_context (widget);
  GdkGLDrawable *gldrawable = gtk_widget_get_gl_drawable (widget);

  gl_width = widget->allocation.width;  
  gl_height = widget->allocation.height;  

  /*** OpenGL BEGIN ***/
  if (!gdk_gl_drawable_gl_begin (gldrawable, glcontext))
    return FALSE;

  ((glop::Scene*)data)->ImageSize(gl_width,gl_height);

  gdk_gl_drawable_gl_end (gldrawable);
  /*** OpenGL END ***/

  return TRUE;
}

gboolean glop::gtkScene::gl_expose_event (GtkWidget *widget,
					   GdkEventExpose *event,
					   gpointer data)
{ 
  GdkGLContext *glcontext = gtk_widget_get_gl_context (widget);
  GdkGLDrawable *gldrawable = gtk_widget_get_gl_drawable (widget);

  // ne redessine que le dernier �v�nement d'exposition
  if (event->count > 0) {
    return(TRUE);
  }
  
  /*** OpenGL BEGIN ***/
  if (!gdk_gl_drawable_gl_begin (gldrawable, glcontext))
    return FALSE;

  if( ((glop::gtkScene*)data)->first_exposure)
    {
      ((glop::Scene*)data)->CbkInit();
       ((glop::gtkScene*)data)->first_exposure=false;
    }

  ((glop::Scene*)data)->CbkDraw();

  /*** OpenGL END ***/

  // �change les 2 buffers du double buffering
  if (gdk_gl_drawable_is_double_buffered (gldrawable))
    gdk_gl_drawable_swap_buffers (gldrawable);
  else
    glFlush ();
  
  gdk_gl_drawable_gl_end (gldrawable);

  return (TRUE);
}

void glop::gtkScene::Refresh(void)
{
  gtk_widget_queue_draw(drawing_area); 
}

gint glop::gtkScene::on_time(gpointer data)
{
  glop::gtkScene* that;
  
  that=(glop::gtkScene*)data;

  that->CbkTime();
  gtk_timeout_add(that->_time_period,on_time,data);

  return false;
}
