#ifndef EXAMPLE_3
#define EXAMPLE_3

#include <glop.h>

class Example3 : public glop::Drawable, public glop::TimeEvent {
  
private:
  
  double angle;
    
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  virtual void Time (glop::Scene *scene);
    
};

#endif
