#include "example09.h"
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>


/* ######### */
/* #       # */
/* # Torus # */
/* #       # */
/* ######### */

Torus::Torus(void)
{
}

#define RAD1     .2
#define RAD2     .3
#define LENGTH  1.0

void Torus::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;

  idf_cylinder = glGenLists(4);
  idf_sphere   = idf_cylinder+1;
  idf_stick    = idf_sphere+1;
  idf_torus    = idf_stick+1;

  params = gluNewQuadric();
  gluQuadricDrawStyle   (params,GLU_FILL);    // Polygon filled.
  gluQuadricNormals     (params,GLU_SMOOTH);  // Lighting smooth
  gluQuadricOrientation (params,GLU_OUTSIDE); // Normals outside.
  gluQuadricTexture     (params,GL_FALSE);    // Do not generate texture coords.

  glNewList(idf_cylinder,GL_COMPILE);
  /* */ gluCylinder(params,   // Cylinder from (0,0,0) to (0,0,LENGTH)
		    RAD1,     // Base radius.
		    RAD1,     // Top radius.
		    LENGTH,   // Height.
		    20,2);    // 20 slices, 2 stacks.
  glEndList();
  
  glNewList(idf_sphere,GL_COMPILE);
  /* */ gluSphere(params,    
		  RAD2,      // Radius
		  15,10);    // 15 longitudes and 10 latitudes.
  glEndList();

  // This is a sphere at (0,0,length/2) from wher starts a cylinder
  // toward positive z.
  glNewList(idf_stick,GL_COMPILE);
  /*   */ glPushMatrix();
  /*     */ glTranslatef(0,0,-LENGTH/2);
  /*     */ glCallList(idf_sphere);
  /*     */ glCallList(idf_cylinder);
  /*   */ glPopMatrix();
  glEndList();

  glNewList(idf_torus,GL_COMPILE);
  /* */ glPushMatrix();
  /*   */ glTranslatef(-LENGTH/2,0,0);
  /*   */ glCallList(idf_stick);
  /* */ glPopMatrix();
  /* */ glPushMatrix();
  /*   */ glTranslatef(0,0,LENGTH/2);
  /*   */ glRotatef(90,0,1,0);
  /*   */ glCallList(idf_stick);
  /* */ glPopMatrix();
  /* */ glPushMatrix();
  /*   */ glTranslatef(LENGTH/2,0,0);
  /*   */ glRotatef(180,0,1,0);
  /*   */ glCallList(idf_stick);
  /* */ glPopMatrix();
  /* */ glPushMatrix();
  /*   */ glTranslatef(0,0,-LENGTH/2);
  /*   */ glRotatef(270,0,1,0);
  /*   */ glCallList(idf_stick);
  /* */ glPopMatrix();
  glEndList();

  // Set background color
  glClearColor(0,0,0,0);

  free(params);
}

void Torus::Draw(glop::Scene* scene)
{
  BeginMaterial();
  /* */ glCallList(idf_torus);
  EndMaterial();
}


/* ######## */
/* #      # */
/* # Star # */
/* #      # */
/* ######## */


Star::Star(GLuint light_channel)
  :PointLight(light_channel,
	      0,0,0,
	      1,1,0),
   TimeEvent()
{
  t=0;
}

void Star::Time(glop::Scene* scene)
{
  t+=.05;
  if(t>M_PI)
    t-=2*M_PI;

  position[1]=3*sin(t);
}


/* ############ */
/* #          # */
/* # StarBulb # */
/* #          # */
/* ############ */

#define RAD3     .1

void StarBulb::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;

  t=0;
  height=0;

  idf_sphere = glGenLists(1);

  params = gluNewQuadric();
  gluQuadricDrawStyle   (params,GLU_FILL); 
  gluQuadricNormals     (params,GLU_SMOOTH);
  gluQuadricOrientation (params,GLU_INSIDE);  // Normals INSIDE, to see light on the right side.
  gluQuadricTexture     (params,GL_FALSE);   

  glNewList(idf_sphere,GL_COMPILE);
  /* */ gluSphere(params,   
		  RAD3,     
		  15,10); 
  glEndList();

  Color(1,1,0);


  free(params);
}

void StarBulb::Draw(glop::Scene* scene)
{
  BeginMaterial();
  /* */ glPushMatrix();
  /*   */ glTranslatef(0,height,0);
  /*   */ glCallList(idf_sphere);
  /* */ glPopMatrix();
  EndMaterial();
}


void StarBulb::Time(glop::Scene* scene)
{
  t+=.05;
  if(t>M_PI)
    t-=2*M_PI;

  height=3*sin(t);
}


/* ######## */
/* #      # */
/* # Spin # */
/* #      # */
/* ######## */


Spin::Spin(GLuint light_channel)
  :SpotLight(light_channel,
	     0,0,0,   // Position
	     0,0,1,   // Direction
	     1,0,0,   // Color
	     60,5),   // Cone angle and exponant (small => less angular attenuation) 
   TimeEvent()
{
  angle=0;
  height=0;
}

void Spin::Time(glop::Scene* scene)
{
  t+=.01;
  angle+=5;

  if(t>M_PI)
    t-=2*M_PI;
  if(angle>180)
    angle-=360;

  height=1.2*sin(t);
}


void Spin::Draw(glop::Scene* scene)
{
  glPushMatrix();
  /* */ glTranslatef(0,height,0);
  /* */ glRotatef(angle,0,1,0);
  /* */ LightSetup();
  glPopMatrix();
}


/* ############ */
/* #          # */
/* # SpinBulb # */
/* #          # */
/* ############ */

#define RAD4    .1
#define LENGTH2 .2

void SpinBulb::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;


  // We want the bulb be a cone, enlighted inside. It could work with
  // a cone and a point light, But we have to use a spot light, so
  // once you've cut off the light beam, you won't see the cone
  // enlighted. The trick is to put the cone in front of the light. It
  // will be lighted... but the out side of the cone is
  // enlighted. Just invert normal vectors to make inner side be
  // enlighted, as if a point light were inside the cone.

  t=0;
  height=0;

  idf_cylinder = glGenLists(1);

  params = gluNewQuadric();
  gluQuadricDrawStyle   (params,GLU_FILL); 
  gluQuadricNormals     (params,GLU_SMOOTH);
  gluQuadricOrientation (params,GLU_INSIDE); // event if the cone is
					     // in front of the light,
					     // it's internal part
					     // will shine.
  gluQuadricTexture     (params,GL_FALSE);   

  glNewList(idf_cylinder,GL_COMPILE);
  /* */ glTranslatef(0,0,+.05); // so that light is just behinde the cone.
  /* */ gluCylinder(params,   // Cylinder from (0,0,0) to (0,0,LENGTH)
		    0,        // Base radius.
		    RAD4,     // Top radius.
		    LENGTH2,  // Height.
		    20,2);    // 20 slices, 2 stacks.
  glEndList();

  Color(1,0,0);


  free(params);
}

void SpinBulb::Draw(glop::Scene* scene)
{
  BeginMaterial();
  /* */ glPushMatrix();
  /*   */ glTranslatef(0,height,0);
  /*   */ glRotatef(angle,0,1,0);
  /*   */ glCallList(idf_cylinder);
  /* */ glPopMatrix();
  EndMaterial();
}


void SpinBulb::Time(glop::Scene* scene)
{
  t+=.01;
  angle+=5;

  if(t>M_PI)
    t-=2*M_PI;
  if(angle>180)
    angle-=360;

  height=1.2*sin(t);
}
