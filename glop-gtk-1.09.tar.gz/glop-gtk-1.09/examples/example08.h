#ifndef EXAMPLE_8
#define EXAMPLE_8

#include <glop.h>
#include <string>

class Gabor : public glop::Drawable, public glop::TimeEvent {
  
private:
  
  double phase;
    
protected:

  virtual void Vertex(GLfloat u,GLfloat v);   // u,v in [-.5,.5]
  virtual void Normal(GLfloat u,GLfloat v);   // u,v in [-.5,.5]
  virtual void TexCoord(GLfloat u,GLfloat v); // u,v in [-.5,.5]
  void Mesh(void);
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  virtual void Time (glop::Scene *scene);
    
};

class GaborFill : public Gabor {
protected:
  virtual void Draw(glop::Scene* scene);  
};

class GaborTex1 : public Gabor, glop::Texture {

protected:
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  

public :

  GaborTex1(std::string texture_file_name);
};

class GaborTex2 : public GaborTex1 {

protected:

  virtual void TexCoord(GLfloat u,GLfloat v);

public :

  GaborTex2(std::string texture_file_name);
};


class GaborTex3 : public Gabor, glop::TextureMap {

protected:

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  

public :

  GaborTex3(std::string texture_file_name);
};


class GaborTex4 : public GaborTex3 {

protected:

  void Vertex(GLfloat u,GLfloat v); 
  void Normal(GLfloat u,GLfloat v);

public:

  GaborTex4(std::string texture_file_name);
};

class GaborStatic : public Gabor {

private:

  GLuint idf;

protected:

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  

};

class GaborPlastic : public Gabor, public glop::Material {

protected:

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  

};

class GaborTex5 : public Gabor, public glop::Material, public glop::TextureModulate {

protected:

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  

public:

  GaborTex5(std::string texture_file_name);

};

#endif
