#include <iostream>
#include "example03.h"
#include <math.h>



#define RADIUS              5
#define AMPLITUDE          15
#define SPEED             .07

void Example3::InitDrawings(glop::Scene* scene)
{
  angle=0;
}

void Example3::Draw(glop::Scene* scene)
{  

  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL); 

  // We draw a green square oscillating between two blue and red
  // squares.

  glPushMatrix(); // Read transforms from last to first !

  glTranslatef(0,RADIUS,0);
  glRotatef(AMPLITUDE*sin(angle),
	    0,0,1);
  glTranslatef(0,-RADIUS,0);

  glColor3f(0,1,0);
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.75,-.75,0);
  /* */ glVertex3f( .75,-.75,0);
  /* */ glVertex3f( .75, .75,0);
  /* */ glVertex3f(-.75, .75,0);
  glEnd();

  glPopMatrix(); // End of this transformation.
  
  glColor3f(1,0,0); 
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5, .5,-.5);
  /* */ glVertex3f( .5, .5,-.5);
  /* */ glVertex3f( .5, .5, .5);
  /* */ glVertex3f(-.5, .5, .5);
  glEnd();

  glColor3f(0,0,1);
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5,-.5,-.5);
  /* */ glVertex3f( .5,-.5,-.5);
  /* */ glVertex3f( .5,-.5, .5);
  /* */ glVertex3f(-.5,-.5, .5);
  glEnd();
}

void Example3::Time(glop::Scene* scene)
{  
  angle+=SPEED;
  if(angle>M_PI)
    angle-=2*M_PI;
}
