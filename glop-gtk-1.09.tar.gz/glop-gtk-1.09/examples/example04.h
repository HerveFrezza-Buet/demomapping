#ifndef EXAMPLE_4
#define EXAMPLE_4

#include <glop.h>
#include "example03.h"

class Example4 : public Example3 {
  
private:
      
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
    
};

#endif
