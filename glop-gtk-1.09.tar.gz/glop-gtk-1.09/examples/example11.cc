#include "example11.h"
#include <GL/gl.h>
#include <GL/glu.h>
#include <iostream>
#include <stdlib.h>


/* ########## */
/* #        # */
/* # Sphere # */
/* #        # */
/* ########## */

GLuint Sphere::idf_sphere=0;

void Sphere::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;

  if(idf_sphere==0)
    {
      idf_sphere = glGenLists(1);
      if(idf_sphere==0)
	{
	  std::cerr << "Not enough place for Sphere list." << std::endl;
	  ::exit(0);
	}
      params = gluNewQuadric();
      gluQuadricDrawStyle   (params,GLU_FILL); 
      gluQuadricNormals     (params,GLU_SMOOTH);
      gluQuadricOrientation (params,GLU_OUTSIDE);
      gluQuadricTexture     (params,GL_TRUE);
      
      
      glNewList(idf_sphere,GL_COMPILE);
      /* */ gluSphere(params,    
		      .5,      // Radius
		      7,5); // 15 longitudes and 10 latitudes.
      glEndList();
      
      free(params);
    }

  Color(1,1,1);
}

void Sphere::Draw(glop::Scene* scene)
{
  BeginMaterial();
  glCallList(idf_sphere);
  EndMaterial();
}


void Sphere::SelectionNotify(int rank)
{
  if(rank<0)
    Color(1,1,1); // default color for a sphere.
  else
    {
      switch(rank)
	{
	case 0: // first
	  Color(1,1,0);
	  break;
	case 1: // second
	  Color(1,.6,0); // Orange
	  break;
	case 2:
	  Color(1,0,0); // Red
	  break;
	case 3:
	  Color(1,0,1); // Purple
	  break;
	default:
	  Color(0,0,1); // Blue
	  break;
	}
    }
}


/* ################## */
/* #                # */
/* # Spinning frame # */
/* #                # */
/* ################## */

void SpinningFrame::InitDrawings(glop::Scene* scene)
{
  angle=0;
  red=1;
  green=1;
  blue=0;
}

void SpinningFrame::SelectionNotify(int rank)
{
  if(rank!=0)
    {
      // default color : yellow
      red=1;
      green=1;
      blue=0;
    }
  else 
    {
      // Winner : green
      red=0;
      green=1;
      blue=0;
    }
}

void SpinningFrame::Draw(glop::Scene* scene)
{
  GLboolean is_lighting;

  is_lighting=glIsEnabled(GL_LIGHTING);

  if(is_lighting==GL_TRUE)
    glDisable(GL_LIGHTING);

  glColor3f(red,green,blue);
  
  glPushMatrix();
  glRotatef(angle,0,1,0);
  glBegin(GL_LINE_STRIP);
  /*  */ glVertex3f(-.5,-.5,-.5);
  /*  */ glVertex3f(-.5,+.5,-.5);
  /*  */ glVertex3f(+.5,+.5,-.5);
  /*  */ glVertex3f(+.5,-.5,-.5);
  /*  */ glVertex3f(+.5,-.5,+.5);
  /*  */ glVertex3f(+.5,+.5,+.5);
  /*  */ glVertex3f(-.5,+.5,+.5);
  /*  */ glVertex3f(-.5,-.5,+.5);
  /*  */ glVertex3f(-.5,-.5,-.5);
  /*  */ glVertex3f(+.5,-.5,-.5);
  glEnd();
  glBegin(GL_LINES);
  /*  */ glVertex3f(-.5,+.5,-.5);
  /*  */ glVertex3f(-.5,+.5,+.5);
  /*  */ glVertex3f(+.5,+.5,-.5);
  /*  */ glVertex3f(+.5,+.5,+.5);
  /*  */ glVertex3f(-.5,-.5,+.5);
  /*  */ glVertex3f(+.5,-.5,+.5);
  glEnd();
  
  if(is_lighting==GL_TRUE)
    glEnable(GL_LIGHTING);
}

void SpinningFrame::Time(glop::Scene* scene)
{
  angle+=5;
  if(angle>180)
    angle-=360;
}


/* ################# */
/* #               # */
/* # Framed sphere # */
/* #               # */
/* ################# */

FramedSphere::FramedSphere(void)
{
  sphere = new Sphere();
  frame  = new SpinningFrame();

  AddDrawable(sphere,NULL);
  AddDrawable(frame,NULL);
  AddTimeEvent(frame);

  // The whole object is selected : i.e no child objects are
  // selectable.
  sphere->Selectable(false); // default
  frame->Selectable(false);  // default
}

FramedSphere::~FramedSphere(void)
{
  delete sphere;
  delete frame;
}


/* ################## */
/* #                # */
/* # Example11 Line # */
/* #                # */
/* ################## */

void Line1(glop::Drawable*)
{
  glTranslatef(-3,0,0);
}

void Line2(glop::Drawable*)
{
  glTranslatef(-1,0,0);
}

void Line3(glop::Drawable*)
{
  glTranslatef(+1,0,0);
}

void Line4(glop::Drawable*)
{
  glTranslatef(+3,0,0);
}

Example11Line::Example11Line(bool with_spin)
{
  // We make elementary objects selectable.

  if(with_spin)
    {
      s1  = (Sphere*)NULL;
      fs1 = new FramedSphere();
      AddDrawable(fs1,Line1);
      AddTimeEvent(fs1);
      fs1->Selectable(true);
    }
  else
    {
      fs1= (FramedSphere*)NULL;
      s1 = new Sphere();
      AddDrawable(s1,Line1);
      s1->Selectable(true);
    }

  s2 = new Sphere();
  AddDrawable(s2,Line2);
  s2->Selectable(true);

  s3 = new Sphere();
  AddDrawable(s3,Line3);
  s3->Selectable(true);

  if(with_spin)
    {
      s4  = (Sphere*)NULL;
      fs4 = new FramedSphere();
      AddDrawable(fs4,Line4);
      AddTimeEvent(fs4);
      fs4->Selectable(true);
    }
  else
    {
      fs4= (FramedSphere*)NULL;
      s4 = new Sphere();
      AddDrawable(s4,Line4);
      s4->Selectable(true);
    }
}

Example11Line::~Example11Line(void)
{
  delete  s1;
  delete fs1;
  delete  s2;
  delete  s3;
  delete  s4;
  delete fs4;
}


/* ################# */
/* #               # */
/* # Example11 Map # */
/* #               # */
/* ################# */

void Map1(glop::Drawable*)
{
  glTranslatef(0,0,-3);
}

void Map2(glop::Drawable*)
{
  glTranslatef(0,0,-1);
}

void Map3(glop::Drawable*)
{
  glTranslatef(0,0,+1);
}

void Map4(glop::Drawable*)
{
  glTranslatef(0,0,+3);
}

Example11Map::Example11Map(bool with_spin)
{
  l1 = new Example11Line(with_spin);
  AddDrawable(l1,Map1);
  AddTimeEvent(l1);

  l2 = new Example11Line(false);
  AddDrawable(l2,Map2);

  l3 = new Example11Line(false);
  AddDrawable(l3,Map3);

  l4 = new Example11Line(with_spin);
  AddDrawable(l4,Map4);
  AddTimeEvent(l4);
}

Example11Map::~Example11Map(void)
{
  delete  l1;
  delete  l2;
  delete  l3;
  delete  l4;
}




/* ################## */
/* #                # */
/* # Example11 Cube # */
/* #                # */
/* ################## */

void Cube1(glop::Drawable*)
{
  glTranslatef(0,-3,0);
}

void Cube2(glop::Drawable*)
{
  glTranslatef(0,-1,0);
}

void Cube3(glop::Drawable*)
{
  glTranslatef(0,+1,0);
}

void Cube4(glop::Drawable*)
{
  glTranslatef(0,+3,0);
}

Example11Cube::Example11Cube(bool with_spin)
{
  m1 = new Example11Map(with_spin);
  AddDrawable(m1,Cube1);
  AddTimeEvent(m1);

  m2 = new Example11Map(false);
  AddDrawable(m2,Cube2);

  m3 = new Example11Map(false);
  AddDrawable(m3,Cube3);

  m4 = new Example11Map(with_spin);
  AddDrawable(m4,Cube4);
  AddTimeEvent(m4);
}

Example11Cube::~Example11Cube(void)
{
  delete  m1;
  delete  m2;
  delete  m3;
  delete  m4;
}
