#include <glop.h>


class ExampleMesh2 :
  public glop::Drawable, 
  public glop::Material {
  
 private: 
  
  
  // Method that give vertex from u,v
  void Point(glop::Vertex& pt,int u,int v);
  
  bool* holes;
  glop::Vertex* points;
  
  glop::Mesh* mesh_filled;
  glop::Mesh* mesh_line; 
  
  bool anaglyph_mode;
  
 protected: 
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  
 public:
  
  ExampleMesh2(bool anaglyph_mode);
  ~ExampleMesh2(void);
  
};
