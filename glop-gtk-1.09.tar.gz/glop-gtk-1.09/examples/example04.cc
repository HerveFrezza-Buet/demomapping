#include <iostream>
#include "example04.h"
#include <math.h>


void Example4::InitDrawings(glop::Scene* scene)
{
  GLfloat fog_color[4]={0.2812, 0.2383, 0.543, 0}; // background color

  glEnable(GL_FOG);
  glFogi(GL_FOG_MODE,GL_EXP2);
  glFogfv(GL_FOG_COLOR,fog_color);
  glFogf(GL_FOG_DENSITY, 0.1);
  glFogf(GL_FOG_START,0.0); 
  glFogf(GL_FOG_END,30.0); 

  Example3::InitDrawings(scene);
}
