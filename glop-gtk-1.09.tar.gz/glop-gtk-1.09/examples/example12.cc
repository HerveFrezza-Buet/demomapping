#include "example12.h"
#include "math.h"
#include <GL/glu.h>


/* ##################### */
/* #                   # */
/* # Symetry sensitive # */
/* #                   # */
/* ##################### */

/* ####### */
/* #     # */
/* # UFO # */
/* #     # */
/* ####### */


GLuint UFO::idf_saucer_1=0; 
GLuint UFO::idf_saucer_2=0; 
GLuint UFO::idf_light_1=0; 
GLuint UFO::idf_light_2=0; 

UFO::UFO(Mirror* mirror,
	 UFOArmy* army,
	 GLfloat red,GLfloat green, GLfloat blue)
{
  the_mirror=mirror;
  the_army = army;
  r=red;
  g=green;
  b=blue;
}

UFO::~UFO(void)
{
}

int UFO::ArmyTime(void) {
  return the_army->time;
}

void UFO::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;

  if(idf_saucer_1==0)
    {
      idf_saucer_1 = glGenLists(4);
      if(idf_saucer_1==0)
	{
	  std::cerr << "Not enough place for flying saucer list." << std::endl;
	  ::exit(0);
	}
      idf_saucer_2 = idf_saucer_1+1;
      idf_light_1  = idf_saucer_2+1;
      idf_light_2  = idf_light_1+1;

      params = gluNewQuadric();

      // Outside normals.

      gluQuadricDrawStyle   (params,GLU_FILL); 
      gluQuadricNormals     (params,GLU_SMOOTH);
      gluQuadricOrientation (params,GLU_OUTSIDE);
      gluQuadricTexture     (params,GL_TRUE);

      glNewList(idf_saucer_1,GL_COMPILE);
      /* */ glPushMatrix();
      /*   */ glRotatef(90,1,0,0);
      /*   */ glTranslatef(0,0,-.5);
      /*   */ gluCylinder(params,.5,.5,1,
			  15,2);
      /*   */ gluDisk(params,0,.5,
		      15,2);
      /*   */ glPushMatrix();
      /*     */ glTranslatef(0,0,1);
      /*     */ gluDisk(params,0,.5,
		      15,2);
      /*   */ glPopMatrix();
      /* */ glPopMatrix();
      glEndList();

      glNewList(idf_light_1,GL_COMPILE);
      /* */ gluSphere(params,    
		      .2, 
		      7,5); 
      glEndList();

      // Inside normals.

      gluQuadricOrientation (params,GLU_INSIDE); // With my openGL
						 // version, this
						 // doesn't work with
						 // spheres.

      glNewList(idf_saucer_2,GL_COMPILE);
      /* */ glPushMatrix();
      /*   */ glRotatef(90,1,0,0);
      /*   */ glTranslatef(0,0,-.5);
      /*   */ gluCylinder(params,.5,.5,1,
			  15,2);
      /*   */ gluDisk(params,0,.5,
		      15,2);
      /*   */ glPushMatrix();
      /*     */ glTranslatef(0,0,1);
      /*     */ gluDisk(params,0,.5,
		      15,2);
      /*   */ glPopMatrix();
      /* */ glPopMatrix();
      glEndList();

      glNewList(idf_light_2,GL_COMPILE);
      /* */ gluSphere(params,    
		      .2,      // Radius
		      7,5);    // 15 longitudes and 10 latitudes.
      glEndList();

      
      free(params);
    }
}

void UFO::Draw(glop::Scene* scene)
{
  GLuint saucer,light;

  if(the_mirror->reflect_mode)
    {
      saucer = idf_saucer_2;
      light  = idf_light_2;
    }
  else
    {
      saucer = idf_saucer_1;
      light  = idf_light_1;
    }

  Shininess(1);
  Specular(0,0,0);

  Color(r,g,b);
  BeginMaterial();
  /* */ glCallList(saucer);
  EndMaterial();

  Color(1,0,0);
  glPushMatrix();
  /* */ glRotatef(angle,0,1,0);
  /* */ glTranslatef(.7,0,0);
  /* */ BeginMaterial();
  /*   */ glCallList(light);
  /* */ EndMaterial();
  glPopMatrix();
  
}

void UFO::Time(glop::Scene* scene)
{
  angle+=15;
  if(angle>180)
    angle-=360;
}


/* ############ */
/* #          # */
/* # UFO Army # */
/* #          # */
/* ############ */

#define UFO1_RADIUS 2
#define UFO2_RADIUS 4
#define UFO3_RADIUS 5

#define UFO1_SPEED 1
#define UFO2_SPEED 10
#define UFO3_SPEED 3

#define UFO_WAVE_COEF .1
#define UFO_WAVE_ANGLE 30

void UFO1Position(glop::Drawable* that)
{
  int time = ((UFO*)that)->ArmyTime();

  glRotatef(time*UFO1_SPEED,0,1,0);
  glTranslatef(UFO1_RADIUS,1,0);
  glRotatef(sin(UFO_WAVE_COEF*time)*UFO_WAVE_ANGLE,0,0,1);
}

void UFO2Position(glop::Drawable* that)
{
  int time = ((UFO*)that)->ArmyTime();

  glRotatef(time*UFO2_SPEED+100,0,1,0);
  glTranslatef(UFO2_RADIUS,0,0);
  glRotatef(sin(UFO_WAVE_COEF*time+1)*UFO_WAVE_ANGLE,0,0,1);
}

void UFO3Position(glop::Drawable* that)
{
  int time = ((UFO*)that)->ArmyTime();

  glRotatef(time*UFO3_SPEED-150,0,1,0);
  glTranslatef(UFO3_RADIUS,-1+sin(time*.2),0);
  glRotatef(sin(UFO_WAVE_COEF*time+2)*UFO_WAVE_ANGLE,0,0,1);
}


UFOArmy::UFOArmy(Mirror* mirror)
{
  time=0;
  ufo1 = new UFO(mirror,this,1,1,0);
  ufo2 = new UFO(mirror,this,0,.5,0);
  ufo3 = new UFO(mirror,this,0,.1,1);

  AddDrawable(ufo1,UFO1Position);
  AddDrawable(ufo2,UFO2Position);
  AddDrawable(ufo3,UFO3Position);

  AddTimeEvent(ufo1);
  AddTimeEvent(ufo2);
  AddTimeEvent(ufo3);
}

UFOArmy::~UFOArmy(void)
{
  delete ufo1;
  delete ufo2;
  delete ufo3;
}


void UFOArmy::Time(glop::Scene* scene)
{

  time++;
  glop::TimeEventSet::Time(scene);
}


/* ######### */
/* #       # */
/* # Glass # */
/* #       # */
/* ######### */

Glass::Glass(std::string texture_file_name)
{
  LoadTexturePPM(texture_file_name,128);

  // Mirror color
  Color(1,1,1,.7);
  BackColor(0,.5,0,1);
}

Glass::~Glass(void)
{
}

void Glass::InitDrawings(glop::Scene* scene)
{
  InitTexturing();
}

#define HALF_SIZE 3
void Glass::Draw(glop::Scene *scene)
{
  BeginMaterial();
  BeginTexturing();
  glBegin(GL_POLYGON);  // A vertical square
  /* */ glTexCoord2f(0,1); glVertex3f(-HALF_SIZE,-HALF_SIZE,0);
  /* */ glTexCoord2f(1,1); glVertex3f(+HALF_SIZE,-HALF_SIZE,0);
  /* */ glTexCoord2f(1,0); glVertex3f(+HALF_SIZE,+HALF_SIZE,0);
  /* */ glTexCoord2f(0,0); glVertex3f(-HALF_SIZE,+HALF_SIZE,0);
  glEnd();
  EndTexturing();
  EndMaterial();
}


/* ########## */
/* #        # */
/* # Mirror # */
/* #        # */
/* ########## */

Mirror::Mirror(std::string texture_file_name)
{
  // These are managed specifically, and are not added in the scene.

  glass = new Glass(texture_file_name);

  clip  = new glop::Clip(GL_CLIP_PLANE0);
  clip->Set(0,0,-1,0);

  blender = new glop::Blender();

  reflect_mode=false;

  draw_reflect=true;
  use_stencil=true;
  use_clip=true;
  draw_mirror=true;
  draw_real=true;
}

Mirror::~Mirror(void)
{
  delete glass;
  delete clip;
  delete blender;
}

void Mirror::InitDrawings(glop::Scene* scene)
{
  glass->SystemInitDrawings(scene);
  clip->Begin()->SystemInitDrawings(scene);
  clip->End()->SystemInitDrawings(scene);
  blender->Begin()->SystemInitDrawings(scene);
  blender->End()->SystemInitDrawings(scene);

  glop::DrawableSet::InitDrawings(scene);
}

void Mirror::Draw(glop::Scene *scene)
{
  bool reflect_is_visible;
  glop::Coord z,dummy;

  
  scene->GetView(dummy,dummy,z,
		 dummy,dummy,dummy);
  reflect_is_visible = (z>=0);
  
  //////////////////
  //
  // We make the drawings by hand.
  //
  //////////////////

  // We clear buffers.
  ///////////////////

  glClear(GL_COLOR_BUFFER_BIT
	  |GL_DEPTH_BUFFER_BIT
	  |GL_STENCIL_BUFFER_BIT);
  
  glEnable(GL_DEPTH_TEST);  // Allow depth test.      

  // Projection setting.
  ///////////////////

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity(); 
  scene->MakeProjection();
  
  // We draw the glass in the stencil buffer.
  ///////////////////

  if(reflect_is_visible)
    {
      glDepthMask(GL_FALSE);                            // Don't write z-buffer.
      if(use_stencil) glEnable(GL_STENCIL_TEST);        // Allow stencil test.      
      glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE); // Don't write frame buffer.
      
      // We set stencil test function.
      glStencilFunc(GL_ALWAYS, // This is the test : always succeed.
		    0x1,       // It concerns layer 1.
		    0x1);      // Comparison element.

      // We set what to do to the stencil after testing.
      glStencilOp(GL_REPLACE, // If test fails. Useless here.
		  GL_REPLACE, // If test succeeds, but depth test fails. Useless here.
		  GL_REPLACE);// If both tests succeed, we replace stencil value by comparison element.
      
      // We draw the glass.
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      scene->MakeModelView();
      glass->SystemDraw(scene,last_name);

      // Frame buffer is now reset writable.
      glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
      // Depth test is also reset.
      glDepthMask(GL_TRUE); 
    }

  // We set the stencil test so that only areas of the screen
  // corresponding to the glass are drawn.
  ////////////////////

  if(reflect_is_visible)
    {
      // We set the appropriate stencil test function.
      glStencilFunc(GL_EQUAL,  // This is the test : Succeeds is stencil is equal to comparison element.
		    0x1,       // It concerns layer 1.
		    0x1);      // Comparison element.

      // We set what to do after testing... we keep it as it is.
      glStencilOp(GL_KEEP,GL_KEEP,GL_KEEP);
    }
  

  // We draw the clipped symetrical scene.
  ///////////////////

  if(reflect_is_visible)
    {
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      scene->MakeModelView();
      
      if(use_clip) clip->Begin()->SystemDraw(scene,last_name);
      glPushMatrix();
      /* */ glScalef(1,1,-1); // xy plane symetry.
      /* */ reflect_mode = true;
      /* */ if(draw_reflect) DrawContents(scene);
      /* */ reflect_mode = false;
      glPopMatrix();
      if(use_clip) clip->End()->SystemDraw(scene,last_name);
    }


  // We clear depth buffer, and disable stencil.
  ///////////////////

  glClear(GL_DEPTH_BUFFER_BIT);
  glDisable(GL_STENCIL_TEST);

  // Now, we draw the real scene, starting with the blent mirror.
  ///////////////////

  
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  scene->MakeModelView();

  if(reflect_is_visible)
    blender->Begin(true)->SystemDraw(scene,last_name);
  if(draw_mirror) glass->SystemDraw(scene,last_name);
  if(reflect_is_visible)
    blender->End()->SystemDraw(scene,last_name);

  if(draw_real) DrawContents(scene);

}
