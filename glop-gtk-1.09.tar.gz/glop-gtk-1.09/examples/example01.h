#ifndef EXAMPLE_1
#define EXAMPLE_1

#include <glop.h>

class Example1 : public glop::Drawable {
  
  protected :
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);
  
};

#endif
