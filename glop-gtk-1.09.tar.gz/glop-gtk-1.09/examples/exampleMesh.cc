#include <exampleMesh.h>
#include <math.h>

#define U_SIZE 20
#define V_SIZE 50

#define WAVE_STEP .1;

#define BIG_RADIUS   5
#define SMALL_RADIUS 2

double ExampleMesh::Wave(int v)
{
  double xx;
  double x;

  x = v - wave_pos;
  xx = v + (V_SIZE-1) - wave_pos;
  if(fabs(xx)<fabs(x))
    x = xx;
  xx = v - (V_SIZE-1) - wave_pos;
  if(fabs(xx)<fabs(x))
    x = xx;

  // some kind of gabor function, according to v.
  return 2.5*sin(.25*x)*exp(-.02*x*x);
}

void  ExampleMesh::Point(glop::Vertex& pt,int u,int v)
{
  double 
    r,R,
    u_angle,v_angle;

  // Torus equation : small circle is u, big one is v.

  u_angle = (u*2*M_PI)/(U_SIZE-1) + M_PI;
  v_angle = (v*2*M_PI)/(V_SIZE-1);
  r = SMALL_RADIUS + Wave(v);
  R = BIG_RADIUS + r*cos(u_angle);
  
  pt._x = R*cos(v_angle);
  pt._y = R*sin(v_angle);
  pt._z = r*sin(u_angle);
}


ExampleMesh::ExampleMesh(void)
{
  int w;

  wave_pos = 0;
 
  // This is the places of holes (true).
  holes = new bool[U_SIZE*V_SIZE];
  for(w=0;w<U_SIZE*V_SIZE;w++)
    holes[w]=false;

  holes[110]=true;

  holes[129]=true;
  holes[130]=true;
  holes[131]=true;

  holes[148]=true;
  holes[149]=true;
  holes[151]=true;
  holes[152]=true;


  holes[410]=true;
  holes[411]=true;
  holes[412]=true;
  holes[413]=true;
  holes[414]=true;
  holes[415]=true;

  holes[430]=true;
  holes[431]=true;
  holes[434]=true;
  holes[435]=true;

  holes[450]=true;
  holes[455]=true;

  holes[470]=true;
  holes[471]=true;
  holes[472]=true;
  holes[474]=true;
  holes[475]=true;

  // This is the colors to set to each point.
  colors = new GLfloat[U_SIZE*V_SIZE*4];

  // These are the vertexes of the mesh.
  points = new glop::Vertex[U_SIZE*V_SIZE];

  // Mesh computation for a filled surface.
  mesh_filled = new glop::Mesh(U_SIZE,V_SIZE);
  mesh_filled->SetHueMode(true); // The color of a point is given arbitrarily from a color array (usually hue values).
  mesh_filled->SetNormalMode(true); // We will need normals to be computed.
  mesh_filled->SetMaterialMode(true); // We will operate in a material context.
  mesh_filled->SetFunctionSelector(new glop::FillFunctionSelector()); // We draw with filled polygons.
  mesh_filled->Prepare(holes); // Do it once to read holes.

  // Mesh computation for a lineded surface.
  mesh_line = new glop::Mesh(U_SIZE,V_SIZE);
  mesh_line->SetHueMode(false); // The color of a point is given arbitrarily from a color array (usually hue values).
  mesh_line->SetNormalMode(false); // We will not need normals to be computed.
  mesh_line->SetMaterialMode(false); // We will not use light.
  mesh_line->SetFunctionSelector(new glop::LineFunctionSelector()); // We draw with line polygons.
  mesh_line->Prepare(holes); // Do it once to read holes.
}

ExampleMesh::~ExampleMesh(void)
{
  delete [] holes;
  delete [] colors;
  delete [] points;
  delete mesh_filled;
  delete mesh_line;
}


void ExampleMesh::InitDrawings(glop::Scene* scene)
{
  // We trigger first computation.
  Time(scene);
}

void ExampleMesh::Draw(glop::Scene* scene)
{
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(1,1);
  mesh_filled->Render(points,colors);
  glDisable(GL_POLYGON_OFFSET_FILL);

  glDisable(GL_LIGHTING);
  glColor3f(.5,.5,.5);
  mesh_line->Render(points);
  glEnable(GL_LIGHTING);
}

void ExampleMesh::Time(glop::Scene *scene)
{
  GLfloat* color;
  int u,v,w;

  wave_pos += WAVE_STEP;
  if(wave_pos >  V_SIZE)
    wave_pos -= V_SIZE;

  // We re-compute the grids of values.
  for(v=0,w=0,color=colors;
      v<V_SIZE;
      v++)
    for(u=0;
	u<U_SIZE;
	u++,w++,color+=4) {

      // We compute vertex
      Point(points[w],u,v);
      
      // We compute the color of that vertex from wave value, rescaled in [0..1]. This color is the 
      glop::AbstractHueComputer::CalcHue((GLfloat)(.5*(1+Wave(v))),
					 color);
    }
  
}
