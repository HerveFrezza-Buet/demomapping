#include <exampleMesh2.h>
#include <math.h>

#define U_SIZE 100
#define V_SIZE U_SIZE


#define CORNER_RADIUS 50
#define SIDE_SIZE  10
#define HOLE_RADIUS  15
#define HOLE_U 50
#define HOLE_V 50


void ExampleMesh2::Point(glop::Vertex& pt,int u,int v)
{
  pt._x = SIDE_SIZE*(u-U_SIZE*.5)/(double)U_SIZE;
  pt._y = SIDE_SIZE*(v-V_SIZE*.5)/(double)V_SIZE;
  pt._z = sin(.1*u)*cos(.1*v);
}


ExampleMesh2::ExampleMesh2(bool anglyph)
{
  int w,h,k;
  int d,delta;

  anaglyph_mode = anglyph;

 
  // These are the vertexes of the mesh.
  points = new glop::Vertex[U_SIZE*V_SIZE];
  // This is the places of holes (true).
  holes = new bool[U_SIZE*V_SIZE];
  for(w=0,k=0;w<U_SIZE;w++)
    for(h=0;h<V_SIZE;h++,k++) {
      Point(points[k],w,h);
      delta = w-U_SIZE/2;
      d = delta*delta;
      delta = h-V_SIZE/2;
      d += delta*delta;
      if(d > CORNER_RADIUS*CORNER_RADIUS) 
	holes[k]=true;
      else {
	delta = w-HOLE_U;
	d = delta*delta;
	delta = h-HOLE_V;
	d += delta*delta;
	holes[k]=d<HOLE_RADIUS*HOLE_RADIUS;
      }
    }

  holes[25*V_SIZE+25]=true;
  holes[29*V_SIZE+29]=true;
  holes[30*V_SIZE+30]=true;
  holes[31*V_SIZE+31]=true;
  holes[32*V_SIZE+32]=true;
  holes[34*V_SIZE+34]=true;
  holes[35*V_SIZE+35]=true;
  holes[36*V_SIZE+36]=true;
  holes[36*V_SIZE+37]=true;
  holes[36*V_SIZE+38]=true;
  holes[35*V_SIZE+38]=true;

  holes[75*V_SIZE+70]=true;
  holes[75*V_SIZE+71]=true;
  holes[75*V_SIZE+72]=true;
  holes[75*V_SIZE+73]=true;
  holes[75*V_SIZE+74]=true;
  holes[75*V_SIZE+75]=true;
  holes[75*V_SIZE+76]=true;
  holes[75*V_SIZE+77]=true;
  holes[75*V_SIZE+78]=true;
  holes[75*V_SIZE+79]=true;
  holes[75*V_SIZE+80]=true;

  holes[70*V_SIZE+75]=true;
  holes[71*V_SIZE+75]=true;
  holes[72*V_SIZE+75]=true;
  holes[73*V_SIZE+75]=true;
  holes[74*V_SIZE+75]=true;
  holes[75*V_SIZE+75]=true;
  holes[76*V_SIZE+75]=true;
  holes[77*V_SIZE+75]=true;
  holes[78*V_SIZE+75]=true;
  holes[79*V_SIZE+75]=true;
  holes[80*V_SIZE+75]=

  holes[(2+75)*V_SIZE+2+20]=true;
  holes[(2+75)*V_SIZE+2+21]=true;
  holes[(2+75)*V_SIZE+2+22]=true;
  holes[(2+75)*V_SIZE+2+23]=true;
  holes[(2+75)*V_SIZE+2+24]=true;
  holes[(2+75)*V_SIZE+2+25]=true;
  holes[(2+75)*V_SIZE+2+26]=true;
  holes[(2+75)*V_SIZE+2+27]=true;
  holes[(2+75)*V_SIZE+2+28]=true;
  holes[(2+75)*V_SIZE+2+29]=true;
  holes[(2+75)*V_SIZE+2+30]=true;

  holes[(2+70)*V_SIZE+2+25]=true;
  holes[(2+71)*V_SIZE+2+25]=true;
  holes[(2+72)*V_SIZE+2+25]=true;
  holes[(2+73)*V_SIZE+2+25]=true;
  holes[(2+74)*V_SIZE+2+25]=true;
  holes[(2+75)*V_SIZE+2+25]=true;
  holes[(2+76)*V_SIZE+2+25]=true;
  holes[(2+77)*V_SIZE+2+25]=true;
  holes[(2+78)*V_SIZE+2+25]=true;
  holes[(2+79)*V_SIZE+2+25]=true;
  holes[(2+80)*V_SIZE+2+25]=true;

  
  // Mesh computation for a filled surface.
  mesh_filled = new glop::Mesh(U_SIZE,V_SIZE);
  mesh_filled->SetHueMode(false); // The color of a point is given arbitrarily from a color array (usually hue values).
  mesh_filled->SetNormalMode(true); // We will need normals to be computed.
  mesh_filled->SetMaterialMode(true); // We will operate in a material context.
  mesh_filled->SetFunctionSelector(new glop::FillFunctionSelector()); // We draw with filled polygons.
  mesh_filled->Prepare(holes); // Do it once to read holes.

  // Mesh computation for a lineded surface.
  mesh_line = new glop::Mesh(U_SIZE,V_SIZE);
  mesh_line->SetHueMode(false); // The color of a point is given arbitrarily from a color array (usually hue values).
  mesh_line->SetNormalMode(false); // We will not need normals to be computed.
  mesh_line->SetMaterialMode(false); // We will not use light.
  mesh_line->SetFunctionSelector(new glop::LineFunctionSelector()); // We draw with line polygons.
  mesh_line->SetGridComputer(new glop::PeriodicGridComputer(U_SIZE,V_SIZE,5,5)); // for smart grids.
  mesh_line->Prepare(holes); // Do it once to read holes.
}

  ExampleMesh2::~ExampleMesh2(void)
{
  delete [] holes;
  delete [] points;
  delete mesh_filled;
  delete mesh_line;
}


void ExampleMesh2::InitDrawings(glop::Scene* scene)
{
  if(anaglyph_mode)
    Color(.8,.8,.8);
  else
    Color(1,.1,.3);
}

void ExampleMesh2::Draw(glop::Scene* scene)
{
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(1,1);
  BeginMaterial();
  mesh_filled->Render(points);
  EndMaterial();
  glDisable(GL_POLYGON_OFFSET_FILL);

  glDisable(GL_LIGHTING);
  glColor3f(0,0,0);
  mesh_line->Render(points);
  glEnable(GL_LIGHTING);
}
