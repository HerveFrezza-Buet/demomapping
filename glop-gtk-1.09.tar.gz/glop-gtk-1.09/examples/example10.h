#ifndef EXAMPLE_10
#define EXAMPLE_10

#include <glop.h>

class Tree : 
  public glop::Drawable, 
  public glop::TimeEvent,
  public glop::Material
{

private:
  
  GLuint idf_cylinder;
  GLuint idf_sphere;
  GLfloat angle;

  void Draw(int n, GLfloat length, GLfloat speed);

protected: 

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);
  void Time(glop::Scene* scene);
};


#endif
