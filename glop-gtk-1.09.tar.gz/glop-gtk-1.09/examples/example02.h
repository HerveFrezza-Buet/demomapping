#ifndef EXAMPLE_2
#define EXAMPLE_2

#include <glop.h>

class Example2 : public glop::Drawable, public glop::MouseEvent {
  
private:
  
  glop::Coord x,y,z,rx,ry,rz;
  glop::Coord _x,_y,_z,_rx,_ry,_rz;
  
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);
  
  virtual void Click (glop::Scene *scene, 
		      glop::Button b, 
		      int x, int y);
  virtual void Motion(glop::Scene *scene, 
		      glop::Button b, int x, int y, 
		      int dx, int dy, 
		      int ddx, int ddy);
    
public:

  Example2(void);

};

#endif
