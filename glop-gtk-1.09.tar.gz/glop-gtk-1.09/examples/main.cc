
#include <GL/gl.h>
#include <GL/glu.h>

#include <gtk/gtk.h>
#include <gtk/gtkgl.h>

#include <glop.h>
#include <glop-gtk.h>


#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <math.h>

#include "example01.h"
#include "example02.h"
#include "example03.h"
#include "example04.h"
#include "example05.h"
#include "example06.h"
#include "example07.h"
#include "example08.h"
#include "example09.h"
#include "example10.h"
#include "example11.h"
#include "example12.h"
#include "exampleMesh.h"
#include "exampleMesh2.h"
#include "exampleBoy.h"


void MoveTree(glop::Drawable* that)
{
  glTranslatef(0,-1,0);
}

void MoveTorusUp(glop::Drawable* that)
{
  glTranslatef(0,1,0);
  glRotatef(15,0,1,0);
}

void MoveTorusDown(glop::Drawable* that)
{
  glTranslatef(0,-1,0);
  glRotatef(-15,0,1,0);
}

void MoveTorusFront(glop::Drawable* that)
{
  glTranslatef(0,0,2);
  glRotatef(15,0,0,1);
}

void MoveTorusBack(glop::Drawable* that)
{
  glTranslatef(0,0,-2);
  glRotatef(-15,0,0,1);
}

void MoveTorusLeft(glop::Drawable* that)
{
  glTranslatef(-2,0,0);
  glRotatef(-15,1,0,0);
}

void MoveTorusRight(glop::Drawable* that)
{
  glTranslatef(2,0,0);
  glRotatef(15,1,0,0);
}

// This is a class for our scene.

class OurScene : public glop::gtkScene {
public:

  OurScene(void) : glop::gtkScene(320,240) {}
  
  virtual void CbkInit(void) {
    
    
    // Enable z-buffer test
    glEnable(GL_DEPTH_TEST);
    
    // Call upper-class inits last.
    glop::gtkScene::CbkInit();
  }
};


// This is gtk stuff for main window.

static gboolean delete_event( GtkWidget *widget,
                              GdkEvent  *event,
                              gpointer   data )
{

  return FALSE;
}

static void destroy( GtkWidget *widget,
                     gpointer   data )
{
    gtk_main_quit ();
}


void
on_select_button_toggled(GtkToggleButton *togglebutton,
			 gpointer         user_data)
{
  glop::SelectorInteractiveView* selector;

  selector=(glop::SelectorInteractiveView*)user_data;
  
  if(gtk_toggle_button_get_active(togglebutton))
    selector->SetSelectionMode(true);
  else
    selector->SetSelectionMode(false);
}


// And this is typical gtk main.

int main(int argc, char *argv[]) 
{
  GtkWidget *window;
  GtkWidget *box;
  glop::gtkScene* scene;
  std::string file_name;
  std::string shadow;
  char sep;
 
  
  // initialisation de gtk
  gtk_init(&argc, &argv);
  gtk_gl_init (&argc, &argv);

  if(argc!=2)
    {
      std::cout << "Usage : " << std::endl
		<< "  " << argv[0] << " i "
		<< "                       (for example i)" << std::endl
		<< std::endl;
      return 1;
    }



  // Window

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  g_signal_connect (G_OBJECT (window), "delete_event",
		    G_CALLBACK (delete_event), NULL);
  g_signal_connect (G_OBJECT (window), "destroy",
		    G_CALLBACK (destroy), NULL);
  gtk_container_set_border_width (GTK_CONTAINER (window), 0);

  box = gtk_vbox_new(FALSE,5);
  gtk_container_add (GTK_CONTAINER (window),box);
  gtk_widget_show(box);

  // The Scene
  scene = new OurScene();
  scene->SetBackgroundColor(0.2812, 0.2383, 0.543); 

  // Example selection.

  std::cout << std::endl
	    << std::endl
	    << std::endl
	    << "##############" << std::endl
	    << "#            #" << std::endl
	    << "# Example " << std::setw(2) << atoi(argv[1]) << " #" << std::endl
	    << "#            #" << std::endl
	    << "##############" << std::endl
	    << std::endl;

  switch(atoi(argv[1]))
    {

    case  1: /* ######################################################## */
      
      std::cout << "This draws a cube that you can move around, " << std::endl
		<< "by controlling directly x,y,z,rx,ry,rz." << std::endl
		<< std::endl
		<< "Left   button : left-right <=> rx, up-down <=> ry" << std::endl
		<< "Middle button : left-right <=> rz, up-down <=>  z" << std::endl
		<< "Right  button : left-right <=>  x, up-down <=>  y" << std::endl
		<< std::endl;
      
      // We use unconvenient but pedagogical viewer.  As this changes
      // view according to mouse events, this is an actual mouse
      // event.
      scene->AddMouseEvent(new glop::DirectInteractiveView);

      // We add an object to view.
      scene->AddDrawable(new Example1,NULL);

      break;

    case  2: /* ######################################################## */   

      Example2* example2;
      
      std::cout << "This draws the frustum and the way the whole scene moves, " << std::endl
		<< "simulating the camera motion." << std::endl
		<< std::endl
		<< "Left   button : left-right <=> rx, up-down <=> ry" << std::endl
		<< "Middle button : left-right <=> rz, up-down <=>  z" << std::endl
		<< "Right  button : left-right <=>  x, up-down <=>  y" << std::endl
		<< std::endl;

      // Allocation
      example2 = new Example2;

      // We set a fixed view.
      scene->SetView(8,2,-4,// Almost on X axis.
		     30,120,-30);

      // We add the object to view.
      scene->AddDrawable(example2,NULL);
      
      // We also add it as a mouse event, because it is sensitive to
      // clicks.
      scene->AddMouseEvent(example2);


      break;

    case  3: /* ######################################################## */   
   
      int view_choice;
      glop::FlightInteractiveView* flight1;

      std::cout << "This is the same as example 1, " << std::endl
		<< "exept that viewing is convenient." << std::endl
		<< std::endl
		<< "  1 - Orbit view." << std::endl
		<< "  2 - Flight view." << std::endl
		<< std::endl
		<< "Your choice > " << std::flush;

      std::cin >> view_choice;
      
      switch(view_choice)
	{
	case 1:
	default:
	  scene->AddMouseEvent(new glop::OrbitInteractiveView);

	  std::cout << std::endl
		    << std::endl
		    << "Left   button : rotate object" << std::endl
		    << "Middle button : rotate view" << std::endl
		    << "Right  button : left-right <=> zoom" << std::endl
		    << std::endl; 
	  break;
	  
	case 2:
	  flight1 = new glop::FlightInteractiveView;
	  scene->AddMouseEvent(flight1);
	  scene->AddTimeEvent(flight1);
	  break;
	  
	}

      // We add an object to view.
      scene->AddDrawable(new Example1,NULL);

      break;

    case  4: /* ######################################################## */      

      Example3* example3;

      std::cout << "Something oscillating..." << std::endl
		<< "You can see aliasing effects !" << std::endl;

      example3 = new Example3;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(example3,NULL);
      scene->AddTimeEvent(example3);

      break;

    case  5: /* ######################################################## */      

      Example4* example4;

      std::cout << "Something oscillating..." << std::endl
		<< "Fog effect can render depth." << std::endl;

      example4 = new Example4;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(example4,NULL);
      scene->AddTimeEvent(example4);

      break;

    case  6: /* ######################################################## */      

      Example5* example5;

      std::cout << "Blending." << std::endl
		<< "1- Draw solid objects." << std::endl
		<< "2- Lock z-buffer." << std::endl
		<< "3- Draw transparent objects, with blending." << std::endl;

      example5 = new Example5;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(example5,NULL);
      scene->AddTimeEvent(example5);

      break;

    case  7: /* ######################################################## */      

      Example6* example6;

      std::cout << "Offset." << std::endl
		<< "You draw fill polygons and lined once," << std::endl
		<< "making the lined once be a little bit closer to moint of view." << std::endl;

      example6 = new Example6;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(example6,NULL);
      scene->AddTimeEvent(example6);

      scene->SetBackgroundColor(.85,.85,.85);

      break;

    case  8: /* ######################################################## */      

      Example7* example7;

      std::cout << "Texturing." << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      example7 = new Example7(file_name);
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(example7,NULL);
      scene->AddTimeEvent(example7);

      break;

    case  9: /* ######################################################## */      

      Example7bis* example7bis;

      std::cout << "Texturing and blending : we use alpha component of textures." << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      example7bis = new Example7bis(file_name);
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(example7bis,NULL);
      scene->AddTimeEvent(example7bis);

      break;

    case 10: /* ######################################################## */      

      Gabor* gabor;

      std::cout << "Gabor function." << std::endl
		<< " ... wired." << std::endl;

      gabor = new Gabor;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gabor,NULL);
      scene->AddTimeEvent(gabor);

      break;

    case 11: /* ######################################################## */      

      GaborFill* gaborfill;

      std::cout << "Gabor function." << std::endl
		<< " ... Filled. We need lighting !" << std::endl;

      gaborfill = new GaborFill;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gaborfill,NULL);
      scene->AddTimeEvent(gaborfill);

      break;

    case 12: /* ######################################################## */      

      GaborTex1* gabortex1;

      std::cout << "Gabor function." << std::endl
		<< " ... Textured, spreading the texture along the whole surface !" << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      gabortex1 = new GaborTex1(file_name);
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gabortex1,NULL);
      scene->AddTimeEvent(gabortex1);

      break;

    case 13: /* ######################################################## */      

      GaborTex2* gabortex2;

      std::cout << "Gabor function." << std::endl
		<< " ... Textured, the texture being repeated." << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      gabortex2 = new GaborTex2(file_name);
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gabortex2,NULL);
      scene->AddTimeEvent(gabortex2);

      break;

    case 14: /* ######################################################## */      

      GaborTex3* gabortex3;

      std::cout << "Gabor function." << std::endl
		<< " ... Textured, using spherical coordinates." << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      gabortex3 = new GaborTex3(file_name);
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gabortex3,NULL);
      scene->AddTimeEvent(gabortex3);

      break;

    case 15: /* ######################################################## */      

      GaborTex4* gabortex4;

      std::cout << "Gabor function." << std::endl
		<< " ... Textured, using spherical coordinates." << std::endl
		<< "     Is it a good mirror ?" << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      gabortex4 = new GaborTex4(file_name);
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gabortex4,NULL);
      scene->AddTimeEvent(gabortex4);

      break;

    case 16: /* ######################################################## */      

      GaborStatic* gaborstatic;

      std::cout << "Gabor function." << std::endl
		<< " ... Wired with hidden faces." << std::endl;

      gaborstatic = new GaborStatic;
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gaborstatic,NULL);
      scene->AddTimeEvent(gaborstatic);

      break;

    case 17: /* ######################################################## */      

      GaborPlastic* gaborplastic;   // the surface.
      glop::Light* light1;           // The light source.
      glop::LightModel* lightmodel1; // The light computation algorithm.

      std::cout << "Gabor function." << std::endl
		<< " ... with light." << std::endl;

      gaborplastic = new GaborPlastic;
      lightmodel1 = new glop::LightModel;
      light1=new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      1,1,1);   // Color is white.

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gaborplastic,NULL);
      scene->AddTimeEvent(gaborplastic);
      scene->AddDrawable(lightmodel1,NULL);
      scene->AddLight(light1,NULL);
      
      // The openGL device can managed a limited number of lights.
      lightmodel1->Enable(GL_LIGHT0);
      
      // We switch light on.
      light1->SwitchOn();
      




      shadow = "dummy";
      while((shadow!="flat")&&(shadow!="smooth"))
	{
	  std::cout << "Shadow type (flat/smooth) : ";
	  std::cin >> shadow;
	  std::cin.get(sep);
	}

      if(shadow=="flat")
	lightmodel1->Shading(GL_FLAT);
      else
	lightmodel1->Shading(GL_SMOOTH); // default.
	
      break;


    case 18: /* ######################################################## */      

      GaborTex5* gabortex5;          // the surface.
      glop::Light* light2;           // The light source.
      glop::LightModel* lightmodel2; // The light computation algorithm.

      std::cout << "Gabor function." << std::endl
		<< " ... Textured and shadowed." << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      gabortex5 = new GaborTex5(file_name);
      lightmodel2 = new glop::LightModel;
      light2=new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      1,1,1);   // Color is white.

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(gabortex5,NULL);
      scene->AddTimeEvent(gabortex5);

      scene->AddDrawable(lightmodel2,NULL);
      scene->AddLight(light2,NULL);

      lightmodel2->Enable(GL_LIGHT0);
      light2->SwitchOn();

      break;


    case 19: /* ######################################################## */      

      Torus*             torus1;
      Star*              star;
      StarBulb*          starbulb;
      glop::Light*       light3;      // The light source.
      glop::LightModel*  lightmodel3; // The light computation algorithm.

      std::cout << "Lights and glu objects." << std::endl
		<< std::endl;

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      
      lightmodel3 = new glop::LightModel;
      scene->AddDrawable(lightmodel3,NULL);
      lightmodel3->Enable(GL_LIGHT0);
      lightmodel3->Enable(GL_LIGHT1);

      light3=new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      .3,.3,.3);   // Color is weak white.
      scene->AddLight(light3,NULL);
      light3->SwitchOn();

      torus1 = new Torus;
      scene->AddDrawable(torus1,NULL);
      scene->AddDrawable(torus1,MoveTorusUp);
      scene->AddDrawable(torus1,MoveTorusDown);

      star = new Star(GL_LIGHT1);
      scene->AddLight(star,NULL);
      scene->AddTimeEvent(star);
      star->SwitchOn();

      starbulb = new StarBulb;
      scene->AddDrawable(starbulb,NULL);
      scene->AddTimeEvent(starbulb);

      break;


    case 20: /* ######################################################## */      

      Torus*             torus2;
      Spin*              spin;
      SpinBulb*          spinbulb;
      glop::Light*       light4;      // The light source.
      glop::LightModel*  lightmodel4; // The light computation algorithm.

      std::cout << "Lights and glu objects." << std::endl
		<< std::endl;

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      
      lightmodel4 = new glop::LightModel;
      scene->AddDrawable(lightmodel4,NULL);
      lightmodel4->Enable(GL_LIGHT0);
      lightmodel4->Enable(GL_LIGHT1);

      light4=new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      .3,.3,.3);   // Color is weak white.
      scene->AddLight(light4,NULL);
      light4->SwitchOn();

      torus2 = new Torus;
      scene->AddDrawable(torus2,MoveTorusDown);
      scene->AddDrawable(torus2,NULL);
      scene->AddDrawable(torus2,MoveTorusUp);

      spin = new Spin(GL_LIGHT1);
      scene->AddLight(spin,NULL);
      scene->AddTimeEvent(spin);
      spin->SwitchOn();

      spinbulb = new SpinBulb;
      scene->AddDrawable(spinbulb,NULL);
      scene->AddTimeEvent(spinbulb);

      break;


    case 21: /* ######################################################## */      
      
      Tree*              tree;
      glop::Light*       light5;      // The light source.
      glop::LightModel*  lightmodel5; // The light computation algorithm.

      std::cout << "We use matrix stacks to generate fractal objects easily." << std::endl
		<< std::endl;

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      
      lightmodel5 = new glop::LightModel;
      scene->AddDrawable(lightmodel5,NULL);
      lightmodel5->Enable(GL_LIGHT0);
      lightmodel5->Ambient(.5,.5,.5,1);

      light5=new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      .3,.3,.3);   // Color is weak white.
      scene->AddLight(light5,NULL);
      light5->SwitchOn();

      tree = new Tree;
      scene->AddDrawable(tree,MoveTree);
      scene->AddTimeEvent(tree);

      break;


    case 22: /* ######################################################## */      

      Torus*             torus3;
      glop::Light*       light6;      // The light source.
      glop::LightModel*  lightmodel6; // The light computation algorithm.
      glop::Clip*        clip1;
      glop::Clip*        clip2;

      std::cout << "Two clipping planes." << std::endl
		<< std::endl;

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      
      lightmodel6 = new glop::LightModel;
      scene->AddDrawable(lightmodel6,NULL);
      lightmodel6->Enable(GL_LIGHT0);
      lightmodel6->Ambient(.5,.5,.5,1);

      light6 = new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      .3,.3,.3);   // Color is weak white.
      scene->AddLight(light6,NULL);
      light6->SwitchOn();

      torus3 = new Torus;
      torus3->BackColor(.8,1,.8);

      clip1 = new glop::Clip(GL_CLIP_PLANE0);
      clip2 = new glop::Clip(GL_CLIP_PLANE1);

      // Planes equations
      clip1->Set(.1,-.9,0,0);
      clip2->Set(1,0,0,.5);

      // And we draw the objects.
      scene->AddDrawable(torus3,MoveTorusDown);
      scene->AddDrawable(clip1->Begin(),NULL);
      scene->AddDrawable(clip2->Begin(),NULL);
      scene->AddDrawable(torus3,NULL);
      scene->AddDrawable(clip1->End(),NULL);
      scene->AddDrawable(torus3,MoveTorusUp);
      scene->AddDrawable(clip2->End(),NULL);
      

      break;


    case 23: /* ######################################################## */      

      Torus*              torus4;
      glop::Light*        light7;      // The light source.
      glop::LightModel*   lightmodel7; // The light computation algorithm.
      glop::DepthOfField* dof1;        // The depth of field renderer.
      double x,y,z;

      std::cout << "We use the accumulation buffer to render "
		<< "depth of field effects. " << std::endl
		<< "This his lots of computation !" << std::endl
		<< std::endl;

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      
      lightmodel7 = new glop::LightModel;
      scene->AddDrawable(lightmodel7,NULL);
      lightmodel7->Enable(GL_LIGHT0);
      lightmodel7->Ambient(.5,.5,.5,1);

      light7 = new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      .3,.3,.3);   // Color is weak white.
      scene->AddLight(light7,NULL);
      light7->SwitchOn();

      torus4 = new Torus;
      torus4->Color(1,0,.7);

      dof1 = new glop::DepthOfField();
      dof1->SetNbTries(20);
      dof1->SetJitter(1);

      // And we draw the objects.

      dof1->AddDrawable(torus4,NULL);
      dof1->AddDrawable(torus4,MoveTorusDown);
      dof1->AddDrawable(torus4,MoveTorusUp);
      dof1->AddDrawable(torus4,MoveTorusLeft);
      dof1->AddDrawable(torus4,MoveTorusRight);
      dof1->AddDrawable(torus4,MoveTorusFront);
      dof1->AddDrawable(torus4,MoveTorusBack);
      
      scene->AddDrawable(dof1,NULL);

      x=4;
      y=1;
      z=1.5;
      scene->SetView(x,y,z,
		     0,0,0);
      scene->LookAt(0,0,0,
		    0,1,0);
      dof1->SetFocus(sqrt(x*x+y*y+z*z));
      

      break;

    case 24: /* ######################################################## */      

      glop::DepthOfField* dof2;         // The depth of field renderer.
      glop::FlightInteractiveView* flight2;

      std::cout << "We use the accumulation buffer to render "
		<< "depth of field effects. " << std::endl
		<< "Smaller stuff makes it real time." << std::endl
		<< std::endl;

      flight2 = new glop::FlightInteractiveView;
      scene->AddMouseEvent(flight2);
      scene->AddTimeEvent(flight2);
      

      dof2 = new glop::DepthOfField();

      dof2->SetNbTries(7);

      dof2->SetJitter(.3);
      dof2->SetFocus(3);
      dof2->ShowFocusPoint(true);

      // And we draw the objects.

      dof2->AddDrawable(new Example1,NULL);
      scene->AddDrawable(dof2,NULL);

      // We set camera.
      scene->SetView(10,10,10,
		     0,0,0);
      scene->LookAt(0,0,0,
		    0,1,0);
      

      break;

    case 25: /* ######################################################## */      
      
      GtkWidget* select_button;

      Example11Cube* example11;
      glop::Light*        light8;      // The light source.
      glop::LightModel*   lightmodel8; // The light computation algorithm.
      glop::SelectorInteractiveView* selector;

      std::cout << "Select objects with the mouse." << std::endl
		<< std::endl;
      
      selector = new glop::SelectorInteractiveView(new glop::OrbitInteractiveView);
      scene->AddMouseEvent(selector);

      example11 = new Example11Cube;
      scene->AddDrawable(example11,NULL);
      scene->AddTimeEvent(example11);

      lightmodel8 = new glop::LightModel;
      scene->AddDrawable(lightmodel8,NULL);
      lightmodel8->Enable(GL_LIGHT0);
      lightmodel8->Ambient(.5,.5,.5,1);

      light8 = new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,    // Direction of the sun.
				      .3,.3,.3);   // Color is weak white.
      scene->AddLight(light8,NULL);
      light8->SwitchOn();

      
      // We build a widget for activating selection.
      
      select_button = gtk_check_button_new_with_mnemonic ("Selection mode");  
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (select_button), FALSE);
      g_signal_connect ((gpointer) select_button, "toggled",
			G_CALLBACK (on_select_button_toggled),
			(gpointer)selector);
      gtk_box_pack_end(GTK_BOX(box),select_button,FALSE,FALSE,0);
      gtk_widget_show (select_button); 

      break;

    case 26: /* ######################################################## */      

      int choice;

      Mirror* mirror;
      UFOArmy* army;
      glop::Light*       light9;      // The light source.
      glop::Light*       light10;     // The light source.
      glop::LightModel*  lightmodel9; // The light computation algorithm.

      std::cout << "See space invaders in a galactic mirror." << std::endl
		<< std::endl
		<< "Enter image file name for texture : ";
      std::cin >> file_name;

      scene->AddMouseEvent(new glop::OrbitInteractiveView);

      mirror = new Mirror(file_name);
      scene->AddDrawable(mirror,NULL);
      scene->AddTimeEvent(mirror);
      
      // Now, we add all the scene elements in the mirror object.

      lightmodel9 = new glop::LightModel;
      mirror->AddDrawable(lightmodel9,NULL);
      lightmodel9->Ambient(.5,.5,.5,1);
      lightmodel9->Enable(GL_LIGHT0);
      lightmodel9->Enable(GL_LIGHT1);

      light9=new glop::DirectionLight(GL_LIGHT0,
				      3,2,1,       // Direction of the sun.
				      .7,.7,.7);   // Color.
      mirror->AddLight(light9,NULL);
      light9->SwitchOn();

      light10=new glop::DirectionLight(GL_LIGHT1,
				       0,-1,-2,   // Direction of the sun.
				      .3,.3,.3); // Color.
      mirror->AddLight(light10,NULL);
      light10->SwitchOn();

      army = new UFOArmy(mirror);
      mirror->AddDrawable(army,NULL);
      mirror->AddTimeEvent(army);

      scene->SetView(0,0,20,
		     0,0,0);

      choice=1;
      while(choice!=0)
	{
	  std::cout << std::endl
		    << std::endl
		    << std::endl
		    << " 0 - exit." << std::endl
		    << " 1 - draw_real     = " << mirror->draw_real << std::endl
		    << " 2 - draw_mirror   = " << mirror->draw_mirror << std::endl
		    << " 3 - draw_reflect  = " << mirror->draw_reflect << std::endl
		    << " 4 - use_clipping  = " << mirror->use_clip << std::endl
		    << " 5 - use_stencil   = " << mirror->use_stencil << std::endl
		    << "> ";
	  std::cin >> choice;
	  switch(choice)
	    {
	    default:
	      break;
	    case 1:
	      mirror->draw_real = ! mirror->draw_real;
	      break;
	    case 2:
	      mirror->draw_mirror = ! mirror->draw_mirror;
	      break;
	    case 3:
	      mirror->draw_reflect = ! mirror->draw_reflect;
	      break;
	    case 4:
	      mirror->use_clip = ! mirror->use_clip;
	      break;
	    case 5:
	      mirror->use_stencil = ! mirror->use_stencil;
	      break;
	    }
	}
      
      break;

    case 27: /* ######################################################## */      

      ExampleMesh* mesh1;              // The mesh.
      glop::Light* light11;           // The light source.
      glop::LightModel* lightmodel11; // The light computation algorithm.

      std::cout << "Mesh functionnalities" << std::endl;

      mesh1 = new ExampleMesh();
      lightmodel11 = new glop::LightModel;
      light11=new glop::DirectionLight(GL_LIGHT0,
				       3,2,1,    // Direction of the sun.
				       1,1,1);   // Color is white.
      
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(mesh1,NULL);
      scene->AddTimeEvent(mesh1);
      scene->AddDrawable(lightmodel11,NULL);
      scene->AddLight(light11,NULL);
      
      // The openGL device can manage a limited number of lights.
      lightmodel11->Enable(GL_LIGHT0);
      lightmodel11->Shading(GL_SMOOTH);
      
      // We switch light on.
      light11->SwitchOn();
      break;

    case 28: /* ######################################################## */      

      Torus*              torus5;
      glop::Light*        light12;      // The light source.
      glop::LightModel*   lightmodel12; // The light computation algorithm.

      std::cout << "Anaglyph" << std::endl
		<< std::endl;

      scene->SetBackgroundColor(.9,.9,.9);

      // We set anaglyph mode.
      scene->SetAnaglyph(true);
      scene->AnaglyphParam(1.5,                         // Distance between eyes.
			   GL_TRUE, GL_FALSE,GL_FALSE,  // Color of left glass is red.
			   GL_FALSE,GL_TRUE ,GL_TRUE ); // Color of right glass is cyan.
      

      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      
      lightmodel12 = new glop::LightModel;
      scene->AddDrawable(lightmodel12,NULL);
      lightmodel12->Enable(GL_LIGHT0);
      lightmodel12->Ambient(.5,.5,.5,1);

      light12 = new glop::DirectionLight(GL_LIGHT0,
					 3,2,1,    // Direction of the sun.
					 1,1,1);   // Color is weak white.
      scene->AddLight(light12,NULL);
      light12->SwitchOn();

      torus5 = new Torus;
      scene->AddDrawable(torus5,NULL);
      scene->AddDrawable(torus5,MoveTorusDown);
      scene->AddDrawable(torus5,MoveTorusUp);
      scene->AddDrawable(torus5,MoveTorusLeft);
      scene->AddDrawable(torus5,MoveTorusRight);
      scene->AddDrawable(torus5,MoveTorusFront);
      scene->AddDrawable(torus5,MoveTorusBack);

      // Has to be done before any drawing here.
      scene->SetView(4,1,1.5,
		     0,0,0);
      scene->LookAt(0,0,0,
		    0,1,0);
      break;

    case 29: /* ######################################################## */      

      ExampleMesh* mesh2;              // The mesh.
      glop::Light* light13;           // The light source.
      glop::LightModel* lightmodel13; // The light computation algorithm.
      std::cout << "Mesh functionnalities and anaglyph" << std::endl;

      scene->SetAnaglyph(true);

      mesh2 = new ExampleMesh();
      lightmodel13 = new glop::LightModel;
      light13=new glop::DirectionLight(GL_LIGHT0,
				       3,2,1,    // Direction of the sun.
				       1,1,1);   // Color is white.
      
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(mesh2,NULL);
      scene->AddTimeEvent(mesh2);
      scene->AddDrawable(lightmodel13,NULL);
      scene->AddLight(light13,NULL);
      
      // The openGL device can manage a limited number of lights.
      lightmodel13->Enable(GL_LIGHT0);
      lightmodel13->Shading(GL_SMOOTH);
      
      // We switch light on.
      light13->SwitchOn();
      break;


    case 30: /* ######################################################## */      

      ExampleMesh2* mesh3;            // The mesh.
      glop::Light* light14;           // The light source.
      glop::Light* light15;           // The light source.
      glop::LightModel* lightmodel14; // The light computation algorithm.
      bool anaglyph;
      char got;


      std::cout << "Smart mesh grid" << std::endl
		<< std::endl
		<< "Type 'a' for anaglyph_mode : " << std::flush;
      std::cin.get(got);
      anaglyph = (got == 'a');

      if(anaglyph) {
	scene->SetBackgroundColor(.5,.5,.5); 
	scene->SetAnaglyph(true);
      }
      mesh3 = new ExampleMesh2(anaglyph);
      lightmodel14 = new glop::LightModel;
      light14 = new glop::DirectionLight(GL_LIGHT0,
					 3,2,1,    // Direction of the sun.
					 1,1,1);   // Color is white.
      light15 = new glop::DirectionLight(GL_LIGHT1,
					 -3,-2,1,    // Direction of the sun.
					 .5,.5,.5);   // Color is grey.
      
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(mesh3,NULL);
      scene->AddDrawable(lightmodel14,NULL);
      scene->AddLight(light14,NULL);
      scene->AddLight(light15,NULL);
      
      // The openGL device can manage a limited number of lights.
      lightmodel14->Enable(GL_LIGHT0);
      lightmodel14->Enable(GL_LIGHT1);
      lightmodel14->Shading(GL_SMOOTH);
      
      // We switch light on.
      light14->SwitchOn();
      light15->SwitchOn();
      break;

    case 31: /* ######################################################## */      

      ExampleBoy*  boy;               // The boy surface.
      ExampleBoy*  boy_line;          // The boy grid.
      glop::Light* light16;           // The light source.
      glop::Light* light17;           // The light source.
      glop::LightModel* lightmodel15; // The light computation algorithm.
      bool anaglyph2;
      char got2;
      glop::Clip*        clip3;
      glop::Clip*        clip4;



      std::cout << "Boy surface" << std::endl
		<< std::endl
		<< "Type 'a' for anaglyph_mode : " << std::flush;
      std::cin.get(got2);
      anaglyph2 = (got2 == 'a');

      if(anaglyph2) {
	scene->SetBackgroundColor(.5,.5,.5); 
	scene->SetAnaglyph(true);
      }

      boy      = new ExampleBoy(anaglyph2,false);
      boy_line = new ExampleBoy(anaglyph2,true);
      lightmodel15 = new glop::LightModel;
      light16 = new glop::DirectionLight(GL_LIGHT0,
					 3,2,1,    // Direction of the sun.
					 1,1,1);   // Color is white.
      light17 = new glop::DirectionLight(GL_LIGHT1,
					 -3,-2,1,    // Direction of the sun.
					 .5,.5,.5);   // Color is grey.


      clip3 = new glop::Clip(GL_CLIP_PLANE0);
      clip4 = new glop::Clip(GL_CLIP_PLANE1);

      // Planes equations
      clip3->Set(0,0,1,.6);
      clip4->Set(0,0,-1,.1);

      
      scene->AddMouseEvent(new glop::OrbitInteractiveView);
      scene->AddDrawable(clip3->Begin(),NULL);
      scene->AddDrawable(clip4->Begin(),NULL);
      scene->AddDrawable(boy,NULL);
      scene->AddDrawable(clip3->End(),NULL);
      scene->AddDrawable(clip4->End(),NULL);
      scene->AddDrawable(boy_line,NULL);
      scene->AddDrawable(lightmodel15,NULL);
      scene->AddLight(light16,NULL);
      scene->AddLight(light17,NULL);
      
      // The openGL device can manage a limited number of lights.
      lightmodel15->Enable(GL_LIGHT0);
      lightmodel15->Enable(GL_LIGHT1);
      lightmodel15->Shading(GL_SMOOTH);
      
      // We switch light on.
      light16->SwitchOn();
      light17->SwitchOn();
      break;
      
    default:  /* ######################################################## */     

      std::cout << "Example \"" << argv[1] << "\" is not defined.\n";
      break;
    }

  std::cout << std::endl
	    << std::endl
	    << std::endl;

  // Hang up the OpenGL window in the Gtk Tree.

  gtk_box_pack_start(GTK_BOX(box),scene->GetWidget(),TRUE,TRUE,0);
  gtk_widget_show (scene->GetWidget());

  // Let's go...

  gtk_widget_show (window);
  gtk_main ();
    

  delete scene;
  
  return 0;
}
