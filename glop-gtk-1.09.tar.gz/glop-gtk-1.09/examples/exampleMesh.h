#include <glop.h>


class ExampleMesh :
  public glop::Drawable, 
  public glop::TimeEvent,
  public glop::Material {
  
 private: 
  
  double wave_pos;
  
  // Method that give vertex from u,v
  void Point(glop::Vertex& pt,int u,int v);
  double Wave(int v);
  
  bool* holes;
  GLfloat* colors;
  glop::Vertex* points;
  
  glop::Mesh* mesh_filled;
  glop::Mesh* mesh_line;
  
 protected: 
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  virtual void Time (glop::Scene *scene);
  
 public:
  
  ExampleMesh(void);
  ~ExampleMesh(void);
  
};
