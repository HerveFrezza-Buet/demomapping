#ifndef EXAMPLE_11
#define EXAMPLE_11

#include <glop.h>


class Sphere : 
  public glop::Drawable, 
  public glop::Material 
{
private:

  static GLuint idf_sphere; // A single list for all spheres.

protected: 

  virtual void InitDrawings(glop::Scene* scene); 
  virtual void Draw(glop::Scene* scene);
  virtual void SelectionNotify(int rank);
};


class SpinningFrame : 
  public glop::Drawable, 
  public glop::TimeEvent
{
private:
  
  GLfloat angle;
  
protected:

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);
  void Time(glop::Scene* scene);
  virtual void SelectionNotify(int rank);

public:
  
  GLfloat red,green,blue;
};

class FramedSphere : 
  public glop::DrawableSet, 
  public glop::TimeEventSet
{
private:

  Sphere* sphere;
  SpinningFrame* frame;
  
public:
  
  FramedSphere(void);
  ~FramedSphere(void);
};


class Example11Line :
  public glop::DrawableSet, 
  public glop::TimeEventSet
{
private:

  bool has_spin;

  Sphere *s1,*s2,*s3,*s4;
  FramedSphere *fs1,*fs4;
  
public:

  Example11Line(bool with_spin=true);
  ~Example11Line(void);
};

class Example11Map :
  public glop::DrawableSet, 
  public glop::TimeEventSet
{
private:

  Example11Line *l1,*l2,*l3,*l4;

public:

  Example11Map(bool with_spin=true);
  ~Example11Map(void);
};

class Example11Cube :
  public glop::DrawableSet, 
  public glop::TimeEventSet
{
private:

  Example11Map *m1,*m2,*m3,*m4;

public:

  Example11Cube(bool with_spin=true);
  ~Example11Cube(void);
};
#endif
