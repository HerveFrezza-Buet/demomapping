#ifndef EXAMPLE_6
#define EXAMPLE_6

#include <glop.h>

class Example6 : public glop::Drawable, public glop::TimeEvent {
  
private:
  
  double angle;
  int pendulum,up,down;
    
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  virtual void Time (glop::Scene *scene);
    
};

#endif
