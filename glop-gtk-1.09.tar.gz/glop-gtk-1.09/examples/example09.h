#ifndef EXAMPLE_9
#define EXAMPLE_9

#include <glop.h>


// That's not a real torus...
class Torus : public glop::Drawable, public glop::Material {

private :
  
  GLuint idf_cylinder;
  GLuint idf_sphere;
  GLuint idf_stick;
  GLuint idf_torus;

  
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  
public:

  Torus(void);

};

class Star : public glop::PointLight, public glop::TimeEvent {

private:

  double t;

protected:

  void Time(glop::Scene* scene);

public:

  Star(GLuint light_channel);
};

class StarBulb : public glop::Drawable, public glop::Material, public glop::TimeEvent {

private :
  
  double t,height;
  GLuint idf_sphere;

  
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  void Time(glop::Scene* scene);
  
};

class Spin : public glop::SpotLight, public glop::TimeEvent {

private:

  double t,angle,height;

protected:

  void Time(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  
public:

  Spin(GLuint light_channel);
};

class SpinBulb : public glop::Drawable, public glop::Material, public glop::TimeEvent {

private:

  double t,angle,height;
  GLuint idf_cylinder;

protected:

  virtual void InitDrawings(glop::Scene* scene);
  void Time(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
};

#endif
