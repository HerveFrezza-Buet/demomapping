#include <iostream>
#include "example05.h"
#include <math.h>

/* ############ */
/* #          # */
/* # Pendulum # */
/* #          # */
/* ############ */

#define RADIUS              5
#define AMPLITUDE          15
#define SPEED             .07

void Pendulum::InitDrawings(glop::Scene* scene)
{
  angle=0;
}

void Pendulum::Transform(void)
{
  // Read transforms from last to first !
  glTranslatef(0,RADIUS,0);
  glRotatef(AMPLITUDE*sin(angle),
	    0,0,1);
  glTranslatef(0,-RADIUS,0);
}

void Pendulum::Draw(glop::Scene* scene)
{  

  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL);

  glPushMatrix(); 
  Transform();


  glColor4f(0,1,0,.4); // We specify alpha value !!!
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.75,-.75,0);
  /* */ glVertex3f( .75,-.75,0);
  /* */ glVertex3f( .75, .75,0);
  /* */ glVertex3f(-.75, .75,0);
  glEnd();

  glPopMatrix(); // End of this transformation.
  
}

void Pendulum::Time(glop::Scene* scene)
{  
  angle+=SPEED;
  if(angle>M_PI)
    angle-=2*M_PI;
}



/* ########## */
/* #        # */
/* # Sheets # */
/* #        # */
/* ########## */

void Sheets::InitDrawings(glop::Scene* scene)
{
}

void Sheets::Draw(glop::Scene* scene)
{  
  
  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL);
  
  glColor3f(1,0,0); 
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5, .5,-.5);
  /* */ glVertex3f( .5, .5,-.5);
  /* */ glVertex3f( .5, .5, .5);
  /* */ glVertex3f(-.5, .5, .5);
  glEnd();

  glColor3f(0,0,1);
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5,-.5,-.5);
  /* */ glVertex3f( .5,-.5,-.5);
  /* */ glVertex3f( .5,-.5, .5);
  /* */ glVertex3f(-.5,-.5, .5);
  glEnd();
}


/* ############ */
/* #          # */
/* # Example5 # */
/* #          # */
/* ############ */

Example5::Example5(void)
{
  pendulum = new Pendulum;
  sheets   = new Sheets;
  blender  = new glop::Blender;

  AddDrawable(sheets          ,NULL);
  AddDrawable(blender->Begin(),NULL);
  AddDrawable(pendulum        ,NULL);
  AddDrawable(blender->End()  ,NULL);

  AddTimeEvent(pendulum);
}

Example5::~Example5(void)
{
  delete pendulum;
  delete sheets;
  delete blender;
}
