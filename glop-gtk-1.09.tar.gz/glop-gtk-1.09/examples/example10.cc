#include "example10.h"
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include <iostream>

#define RAD_CYLINDER .1
#define RAD_SPHERE   (RAD_CYLINDER+.08)
#define COEF .8
#define SPEED_COEF 2
#define ANGLE_STEP .3

void Tree::InitDrawings(glop::Scene* scene)
{
  GLUquadricObj *params;

  idf_cylinder = glGenLists(2);
  idf_sphere   = idf_cylinder+1;

  params = gluNewQuadric();
  gluQuadricDrawStyle   (params,GLU_FILL); 
  gluQuadricNormals     (params,GLU_SMOOTH);
  gluQuadricOrientation (params,GLU_OUTSIDE);
  gluQuadricTexture     (params,GL_FALSE);

  glNewList(idf_cylinder,GL_COMPILE);
  /* */ gluCylinder(params,
		    RAD_CYLINDER,     // Base radius.
		    RAD_CYLINDER,     // Top radius.
		    1,                // Height.
		    20,2);            // 20 slices, 2 stacks.
  glEndList();

  glNewList(idf_sphere,GL_COMPILE);
  /* */ gluSphere(params,    
		  RAD_SPHERE,  // Radius
		  15,10);      // 15 longitudes and 10 latitudes.
  glEndList();

  angle=0;

  free(params);
}

void Tree::Draw(glop::Scene* scene)
{
  Color(1,0,0);
  BeginMaterial();
  glCallList(idf_sphere);
  EndMaterial();

  glPushMatrix();
  /* */ glRotatef(-90,1,0,0);
  /* */ Draw(6,1.5,1);
  glPopMatrix();
}

void Tree::Time(glop::Scene* scene)
{
  angle+=ANGLE_STEP;
}

void Tree::Draw(int n, GLfloat length,GLfloat speed)
{
  if(n>0)
    {
      /* */ glPushMatrix();
      /* */   glRotatef(angle*speed,0,0,1);
      /* */   glPushMatrix();
      /* */     glScalef(1,1,length);
      /* */     Color(1,.8,.5);
      /* */     BeginMaterial();
      /* */     glCallList(idf_cylinder);
      /* */     EndMaterial();
      /* */   glPopMatrix();
      /* */   glPushMatrix();
      /* */     glTranslatef(0,0,length);
      /* */     Color(1,0,0);
      /* */     BeginMaterial();
      /* */     glCallList(idf_sphere);
      /* */     EndMaterial();
      /* */     glPushMatrix();
      /* */       glRotatef( 90,1,0,0);
      /* */       Draw(n-1,length*COEF,speed*SPEED_COEF);
      /* */     glPopMatrix();
      /* */     glPushMatrix();
      /* */       glRotatef(-90,1,0,0);
      /* */       Draw(n-1,length*COEF,speed*SPEED_COEF);
      /* */     glPopMatrix();
      /* */   glPopMatrix();  
      /* */ glPopMatrix();
    }
}
