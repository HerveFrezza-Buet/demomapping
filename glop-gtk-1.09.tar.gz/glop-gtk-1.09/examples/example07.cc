#include <iostream>
#include "example07.h"
#include <math.h>

/* ############### */
/* #             # */
/* # TexPendulum # */
/* #             # */
/* ############### */

TexPendulum::TexPendulum(std::string texture_file_name)
  :Pendulum(),glop::Texture()
{
  LoadTexturePPM(texture_file_name,128);
}

void TexPendulum::InitDrawings(glop::Scene* scene)
{
  Pendulum::InitDrawings(scene);
  InitTexturing();
}

void TexPendulum::Draw(glop::Scene* scene)
{  
  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL);

  glPushMatrix(); 
  Transform();

  BeginTexturing();
  /* */ glBegin(GL_POLYGON); 
  /*   */ glTexCoord2f(0,1); glVertex3f(-.75,-.75,0);
  /*   */ glTexCoord2f(1,1); glVertex3f( .75,-.75,0);
  /*   */ glTexCoord2f(1,0); glVertex3f( .75, .75,0);
  /*   */ glTexCoord2f(0,0); glVertex3f(-.75, .75,0);
  /* */ glEnd();
  EndTexturing();

  glPopMatrix(); // End of this transformation.
}

/* ############ */
/* #          # */
/* # Example7 # */
/* #          # */
/* ############ */

Example7::Example7(std::string texture_file_name)
{
  pendulum = new TexPendulum(texture_file_name);
  sheets   = new Sheets;

  AddDrawable(sheets   ,NULL);
  AddDrawable(pendulum ,NULL);

  AddTimeEvent(pendulum);
}

Example7::~Example7(void)
{
  delete pendulum;
  delete sheets;
}

/* ############### */
/* #             # */
/* # Example7bis # */
/* #             # */
/* ############### */

Example7bis::Example7bis(std::string texture_file_name)
{
  int t,s,size,k;
  char* img;
  char alpha;

  pendulum = new TexPendulum(texture_file_name);
  sheets   = new Sheets;
  blender  = new glop::Blender;

  AddDrawable(sheets          ,NULL);
  AddDrawable(blender->Begin(),NULL);
  AddDrawable(pendulum        ,NULL);
  AddDrawable(blender->End()  ,NULL);

  AddTimeEvent(pendulum);

  // We set alpha component of the texture.
  
  // We know that TexPendulum only defines 0-scale texture. But we
  // test as if we don't.
  
  if(pendulum->Exists(0))
    {
      size = pendulum->Size(0);
      img  = pendulum->Image(0);
      
      for(k=3,t=0; // k points alpha byte.
	  t<size;
	  t++)
	{
	  alpha=(char) ((size-t)/(double)size * 255 +.5);
	  for(s=0;
	      s<size;
	      s++,k+=4)
	    img[k]=alpha;
	}
    }
}

Example7bis::~Example7bis(void)
{
  delete pendulum;
  delete sheets;
  delete blender;
}
