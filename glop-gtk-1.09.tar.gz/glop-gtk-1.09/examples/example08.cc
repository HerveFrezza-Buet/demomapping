#include "example08.h"
#include <math.h>
#include <GL/gl.h>

#define D_PHASE .05
#define FREQ    13
#define SPAT    13
#define AMPL    .3

#define STEP .03


/* ######### */
/* #       # */
/* # Gabor # */
/* #       # */
/* ######### */

void Gabor::Vertex(GLfloat u,GLfloat v)
{
  // Make sure that orientation is direct.
  glVertex3f(v,
	     AMPL*cos(FREQ*u+phase)*exp(-SPAT*(u*u+v*v)),
	     u);
}

void Gabor::Normal(GLfloat u,GLfloat v)
{
  double e,c,s;
  double
    Ux,Uy,Uz, // d/du
    Vx,Vy,Vz; // d/dv

  double Nx,Ny,Nz,N;

  e=exp(-SPAT*(u*u+v*v));
  c=cos(FREQ*u+phase);
  s=sin(FREQ*u+phase);

  Ux=0;
  Uy=-AMPL*e*(2*SPAT*u*c + FREQ*s);
  Uz=1;

  Vx=1;
  Vy=-2*AMPL*SPAT*v*c*e;
  Vz=0;


  // N = U . V

  Nx = Uy*Vz - Uz*Vy;
  Ny = Uz*Vx - Ux*Vz;
  Nz = Ux*Vy - Uy*Vx;

  N=sqrt(Nx*Nx + Ny*Ny + Nz*Nz);

  glNormal3f(Nx/N,Ny/N,Nz/N);
  
}

void Gabor::TexCoord(GLfloat u,GLfloat v)
{
  glTexCoord2f(u+.5,v+.5);
}

void Gabor::Mesh(void)
{
  GLfloat u,v,U,V;
  
  glBegin(GL_TRIANGLES);
  for(u=-.5;u<.5;u+=STEP)
    for(v=-.5;v<.5;v+=STEP)
      {
	// First triangle
	U=u;V=v;
	TexCoord(U,V);Normal(U,V);Vertex(U,V);
	U=u+STEP;
	TexCoord(U,V);Normal(U,V);Vertex(U,V);
	V=V+STEP;
	TexCoord(U,V);Normal(U,V);Vertex(U,V);

	// Second triangle
	U=u;V=v;
	TexCoord(U,V);Normal(U,V);Vertex(U,V);
	U=u+STEP;V=v+STEP;
	TexCoord(U,V);Normal(U,V);Vertex(U,V);
	U=u;V=v+STEP;
	TexCoord(U,V);Normal(U,V);Vertex(U,V);
      }
  glEnd();
}

void Gabor::InitDrawings(glop::Scene* scene)
{
  phase=0;
}

void Gabor::Draw(glop::Scene* scene)
{
  glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
  glColor3f(1,1,0);
  Mesh();
}
  
void Gabor::Time (glop::Scene *scene)
{
  phase+=D_PHASE;
}


/* ############## */
/* #            # */
/* # Gabor Fill # */
/* #            # */
/* ############## */


void GaborFill::Draw(glop::Scene* scene)
{
  glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
  glColor3f(1,1,0);
  Mesh();
}  


/* ############## */
/* #            # */
/* # Gabor Tex1 # */
/* #            # */
/* ############## */

GaborTex1:: GaborTex1(std::string texture_file_name)
  :Gabor(), glop::Texture()
{
  LoadTexturePPM(texture_file_name,128);
}

void GaborTex1::InitDrawings(glop::Scene* scene)
{
  Gabor::InitDrawings(scene);
  InitTexturing();
}

void GaborTex1::Draw(glop::Scene* scene)
{
  BeginTexturing();
  Mesh();
  EndTexturing();
}


/* ############## */
/* #            # */
/* # Gabor Tex2 # */
/* #            # */
/* ############## */

GaborTex2::GaborTex2(std::string texture_file_name)
  :GaborTex1(texture_file_name)
{
}

void GaborTex2::TexCoord(GLfloat u,GLfloat v)
{
  glTexCoord2f((u+.5)*6,
	       (v+.5)*6);
}


/* ############## */
/* #            # */
/* # Gabor Tex3 # */
/* #            # */
/* ############## */

GaborTex3:: GaborTex3(std::string texture_file_name)
  :Gabor(), glop::TextureMap()
{
  LoadTexturePPM(texture_file_name,128);
}

void GaborTex3::InitDrawings(glop::Scene* scene)
{
  Gabor::InitDrawings(scene);
  InitTexturing();
}

void GaborTex3::Draw(glop::Scene* scene)
{
  BeginTexturing();
  Mesh();
  EndTexturing();
}


/* ############## */
/* #            # */
/* # Gabor Tex4 # */
/* #            # */
/* ############## */

GaborTex4::GaborTex4(std::string texture_file_name)
  :GaborTex3(texture_file_name)
{
}

void GaborTex4::Vertex(GLfloat u,GLfloat v)
{
  glVertex3f(u,0,v);
}

void GaborTex4::Normal(GLfloat u,GLfloat v)
{
  glNormal3f(0,-1,0);
}


/* ################ */
/* #              # */
/* # Gabor Static # */
/* #              # */
/* ################ */

void GaborStatic::InitDrawings(glop::Scene* scene)
{
  Gabor::InitDrawings(scene);
  idf=glGenLists(1);

  glNewList(idf,GL_COMPILE);
  /* */ Mesh();
  glEndList();

  // And we change background !
  glClearColor(0.85, 0.85, 0.85, 0);
}

void GaborStatic::Draw(glop::Scene* scene)
{    
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL); 

  glColor3f(.1,0,.6);
  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(1,1);
  glCallList(idf);
  glDisable(GL_POLYGON_OFFSET_FILL);

  glColor3f(1,.8,0);
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_LINE); 
  glCallList(idf);
}


/* ################# */
/* #               # */
/* # Gabor Plastic # */
/* #               # */
/* ################# */

void GaborPlastic::InitDrawings(glop::Scene* scene)
{
  Gabor::InitDrawings(scene);
  Color(1,.1,.3);
}

void GaborPlastic::Draw(glop::Scene* scene)
{  
  BeginMaterial();
  Mesh();
  EndMaterial();
}


/* ############## */
/* #            # */
/* # Gabor Tex5 # */
/* #            # */
/* ############## */

GaborTex5::GaborTex5(std::string texture_file_name)
{
  LoadTexturePPM(texture_file_name,128);
}


void GaborTex5::InitDrawings(glop::Scene* scene)
{
  Gabor::InitDrawings(scene);
  InitTexturing();
  
  // default material is white and shiny.
}

void GaborTex5::Draw(glop::Scene* scene)
{  
  BeginMaterial();
  BeginTexturing();
  Mesh();
  EndMaterial();
  EndTexturing();
}
