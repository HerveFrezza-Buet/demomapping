#include <iostream>
#include "example02.h"



#define DIST_COEF .005
#define ROT_COEF  .05


Example2::Example2(void)
{
  x=0,y=0,z=0;
  rx=0,ry=0,rz=0;
}

void Example2::Click (glop::Scene *scene, 
		      glop::Button b, 
		      int w, int h)
{
  _rx=rx;
  _ry=ry;
  _rz=rz;
  _x=x;
  _y=y;
  _z=z;

}

void Example2::Motion(glop::Scene *scene,
		      glop::Button b, 
		      int w, int h, 
		      int dw, int dh, 
		      int ddw, int ddh)
{
  switch(b)
    {
    case glop::buttonLeft:

      rx = _rx + dw*ROT_COEF;
      ry = _ry + (-dh)*ROT_COEF;

      break;
    case glop::buttonMiddle:

      z  =  _z + (-dh)*DIST_COEF;
      rz = _rz + dw*ROT_COEF;

      break;
    case glop::buttonRight:

      x  =  _x + dw*DIST_COEF;
      y  =  _y + (-dh)*DIST_COEF;

      break;
    default:
      break;
    }
}


void Example2::InitDrawings(glop::Scene* scene)
{
  // Nothing to do.
}

#define BOUND 2
void Example2::Draw(glop::Scene* scene)
{  
  int i,j;

  
  

  /* ############### */
  /* #             # */
  /* # The Frustum # */
  /* #             # */
  /* ############### */


  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL); 

  glColor3f(1,0,0); 
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(-.5, -.4,  0);
  /* */ glVertex3f( .5, -.4,  0);
  /* */ glVertex3f( .5,  .4,  0);
  /* */ glVertex3f(-.5,  .4,  0);
  glEnd();
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(-1, -.8,  -1.5);
  /* */ glVertex3f( 1, -.8,  -1.5);
  /* */ glVertex3f( 1,  .8,  -1.5);
  /* */ glVertex3f(-1,  .8,  -1.5);
  glEnd();
  

  glColor3f(0,1,0); 
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(-.5, -.4,  0);
  /* */ glVertex3f( -1, -.8,  -1.5);
  /* */ glVertex3f(  1, -.8,  -1.5);
  /* */ glVertex3f( .5, -.4,  0);
  glEnd();
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(-.5,  .4,  0);
  /* */ glVertex3f( -1,  .8,  -1.5);
  /* */ glVertex3f(  1,  .8,  -1.5);
  /* */ glVertex3f( .5,  .4,  0);
  glEnd();

  glColor3f(0,0,1); 
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(-.5,  .4,  0);
  /* */ glVertex3f( -1,  .8,  -1.5);
  /* */ glVertex3f( -1, -.8,  -1.5);
  /* */ glVertex3f(-.5, -.4,  0);
  glEnd();
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(.5,  .4,  0);
  /* */ glVertex3f( 1,  .8,  -1.5);
  /* */ glVertex3f( 1, -.8,  -1.5);
  /* */ glVertex3f(.5, -.4,  0);
  glEnd();

  
  


  /* ############# */
  /* #           # */
  /* # The lines # */
  /* #           # */
  /* ############# */

  // This is what the scene does with the world.
  glPushMatrix();
  glRotatef(-rz,0,0,1); 
  glRotatef(-ry,0,1,0);  
  glRotatef(-rx,1,0,0);
  glTranslatef(-x,-y,-z);

  // The polygone drawing mode is useless here, we draw lines.

  glColor3f(0,0,1); // X axis
  glBegin(GL_LINES);
  /* */glVertex3f(-BOUND,0,0);
  /* */glVertex3f( BOUND,0,0);
  glEnd();

  glColor3f(0,1,0); // Y axis
  glBegin(GL_LINES);
  /* */glVertex3f(0,-BOUND,0);
  /* */glVertex3f(0, BOUND,0);
  glEnd();

  glColor3f(1,0,0); // Z axis
  glBegin(GL_LINES);
  /* */glVertex3f(0,0,-BOUND);
  /* */glVertex3f(0,0, BOUND);
  glEnd();

  glColor3f(.7,.7,.7); // Grid
  glBegin(GL_LINES); 
  for(i=-BOUND;i<BOUND+1;i++)
    for(j=-BOUND;j<BOUND+1;j++)
      if(i!=0 || j!=0)
	{
	  glVertex3f( i, j,-BOUND);
	  glVertex3f( i, j, BOUND);
	  
	  glVertex3f( i,-BOUND, j);
	  glVertex3f( i, BOUND, j);
	  
	  glVertex3f(-BOUND, i, j);
	  glVertex3f( BOUND, i, j);
	}
  glEnd();


  glPopMatrix();
}
