#include <exampleBoy.h>
#include <math.h>

#define U_SIZE 200
#define V_SIZE U_SIZE


#define SIDE_SIZE  10


void ExampleBoy::Point(glop::Vertex& pt,int u,int v)
{
  double s = M_PI*u/(double)(U_SIZE-1);
  double t = M_PI*v/(double)(V_SIZE-1);
  double cs = cos(s);
  double ss = sin(s);
  double ct = cos(t);
  double st = sin(t);
  double c2t = cos(2*t);
  double s2t = sin(2*t);
  double s3t = sin(3*t);
  double a = sqrt(2);
  double b = a/3;
  double c = 2/3.0;
  double d = cs/(1 - a*ss*cs*s3t);
  double e = b*cs;
  double f = c*ss;

  pt._x = d*(e*c2t + f*ct);
  pt._y = d*(e*s2t - f*st);
  pt._z = d*cs - 1;
}


ExampleBoy::ExampleBoy(bool anglyph,
		       bool line)
{
  int w,h,k;
 
  anaglyph_mode = anglyph;
  line_mode = line;

  // These are the vertexes of the mesh.
  points = new glop::Vertex[U_SIZE*V_SIZE];
  // This is the places of holes (true).
  holes = new bool[U_SIZE*V_SIZE];
  for(w=0,k=0;w<U_SIZE;w++)
    for(h=0;h<V_SIZE;h++,k++) {
      holes[k]=false;
      Point(points[k],w,h);
    }

  if(!line_mode) {
    // Mesh computation for a filled surface.
    mesh_filled = new glop::Mesh(U_SIZE,V_SIZE);
    mesh_filled->SetHueMode(false); // The color of a point is given arbitrarily from a color array (usually hue values).
    mesh_filled->SetNormalMode(true); // We will need normals to be computed.
    mesh_filled->SetMaterialMode(true); // We will operate in a material context.
    mesh_filled->SetFunctionSelector(new glop::FillFunctionSelector()); // We draw with filled polygons.
    mesh_filled->Prepare(holes); // Do it once to read holes.
  }
  else {
    // Mesh computation for a lineded surface.
    mesh_line = new glop::Mesh(U_SIZE,V_SIZE);
    mesh_line->SetHueMode(false); // The color of a point is given arbitrarily from a color array (usually hue values).
    mesh_line->SetNormalMode(false); // We will not need normals to be computed.
    mesh_line->SetMaterialMode(false); // We will not use light.
    mesh_line->SetFunctionSelector(new glop::LineFunctionSelector()); // We draw with line polygons.
    mesh_line->SetGridComputer(new glop::PeriodicGridComputer(U_SIZE,V_SIZE,10,10)); // for smart grids.
    mesh_line->Prepare(holes); // Do it once to read holes.
  }
}

  ExampleBoy::~ExampleBoy(void)
{
  delete [] holes;
  delete [] points;
  delete mesh_filled;
  delete mesh_line;
}


void ExampleBoy::InitDrawings(glop::Scene* scene)
{
  if(anaglyph_mode)
    Color(.8,.8,.8);
  else
    Color(1,.1,.3);
}

void ExampleBoy::Draw(glop::Scene* scene)
{
  if(!line_mode) {
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1,1);
    BeginMaterial();
    mesh_filled->Render(points);
    EndMaterial();
    glDisable(GL_POLYGON_OFFSET_FILL);
  }
  else {
    glDisable(GL_LIGHTING);
    glColor3f(.2,.2,.3);
    mesh_line->Render(points);
    glEnable(GL_LIGHTING);
  }
}
