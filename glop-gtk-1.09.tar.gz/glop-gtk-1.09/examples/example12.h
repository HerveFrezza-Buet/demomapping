#ifndef EXAMPLE_12
#define EXAMPLE_12

#include <glop.h>
#include <string>
#include "example09.h"

class Mirror;
class UFOArmy;

class UFO : 
  public glop::Material, 
  public glop::Drawable, 
  public glop::TimeEvent
{
private:

  Mirror* the_mirror;
  UFOArmy* the_army;
  GLfloat r,g,b;
  GLfloat angle;
  
  
  static GLuint idf_saucer_1; 
  static GLuint idf_saucer_2; 
  static GLuint idf_light_1; 
  static GLuint idf_light_2; 

protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  virtual void Time(glop::Scene* scene);  

public:

  UFO(Mirror* mirror,
      UFOArmy* army,
      GLfloat red,GLfloat green, GLfloat blue);
  virtual ~UFO(void);

  int ArmyTime(void);
};

class UFOArmy :
  public glop::DrawableSet, 
  public glop::TimeEventSet
{
private:
  
  UFO* ufo1;
  UFO* ufo2;
  UFO* ufo3;
  

protected:

  virtual void Time(glop::Scene* scene);

public:
  
  int time;

  UFOArmy(Mirror* mirror);
  ~UFOArmy(void);
};

class Glass :
  public glop::Drawable,  
  public glop::TextureModulate,
  public glop::Material
{
public:

  
  Glass(std::string texture_file_name);
  ~Glass(void);

protected:
  
  virtual void Draw(glop::Scene *scene);
  virtual void InitDrawings(glop::Scene* scene);
};

class Mirror :
  public glop::DrawableSet,  
  public glop::TimeEventSet
{
private:

  Glass* glass;
  glop::Clip* clip;
  glop::Blender* blender;

public:
  
  bool reflect_mode;
  
  bool draw_reflect;
  bool use_stencil;
  bool use_clip;
  bool draw_mirror;
  bool draw_real;
  

  Mirror(std::string texture_file_name);
  ~Mirror(void);

  virtual void Draw(glop::Scene *scene);
  virtual void InitDrawings(glop::Scene* scene);

};

#endif
