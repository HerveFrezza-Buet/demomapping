#ifndef EXAMPLE_7
#define EXAMPLE_7

#include <string>
#include <glop.h>
#include "example05.h"

// The oscillating stuff.

class TexPendulum : public Pendulum, public glop::Texture {
  
protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  

public:
  
  TexPendulum(std::string texture_file_name);
    
};

// The whole stuff

class Example7 : public glop::DrawableSet, public glop::TimeEventSet{
  
private :

  TexPendulum*   pendulum;
  Sheets*        sheets;

public :
    
  Example7(std::string texture_file_name);
  virtual ~Example7(void);
};

// The same using blending and texture.

class Example7bis : public glop::DrawableSet, public glop::TimeEventSet{
  
private :

  TexPendulum*   pendulum;
  Sheets*        sheets;
  glop::Blender* blender;

public :
    
  Example7bis(std::string texture_file_name);
  virtual ~Example7bis(void);
};


#endif
