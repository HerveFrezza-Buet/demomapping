#include <iostream>
#include "example06.h"
#include <math.h>
#include <stdio.h>



#define RADIUS              5
#define AMPLITUDE          15
#define SPEED             .07

void Example6::InitDrawings(glop::Scene* scene)
{
  angle=0;

  // We pe-compile some stuff.
  pendulum=glGenLists(3);

  if(pendulum==0) 
    {
      std::cout << "No more memory space for lists." << std::endl;
      ::exit(0);
    }

  up=pendulum+1;
  down=up+1;

  // We record some commands.
  
  glNewList(pendulum,GL_COMPILE);
  /* */ glBegin(GL_POLYGON); 
  /*   */ glVertex3f(-.75,-.75,0);
  /*   */ glVertex3f( .75,-.75,0);
  /*   */ glVertex3f( .75, .75,0);
  /*   */ glVertex3f(-.75, .75,0);
  /* */ glEnd();  
  glEndList();

  glNewList(up,GL_COMPILE);
  /* */ glBegin(GL_POLYGON); 
  /*   */ glVertex3f(-.5, .5,-.5);
  /*   */ glVertex3f( .5, .5,-.5);
  /*   */ glVertex3f( .5, .5, .5);
  /*   */ glVertex3f(-.5, .5, .5);
  /* */ glEnd();  
  glEndList();

  glNewList(down,GL_COMPILE);
  /* */ glBegin(GL_POLYGON); 
  /*   */ glVertex3f(-.5,-.5,-.5);
  /*   */ glVertex3f( .5,-.5,-.5);
  /*   */ glVertex3f( .5,-.5, .5);
  /*   */ glVertex3f(-.5,-.5, .5);
  /* */ glEnd();  
  glEndList();
  
}

void Example6::Draw(glop::Scene* scene)
{  

  // The polygone drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL); 

  // We draw a green square oscillating between two blue and red
  // squares.

  glPushMatrix();

  glTranslatef(0,RADIUS,0);
  glRotatef(AMPLITUDE*sin(angle),0,0,1);
  glTranslatef(0,-RADIUS,0);

  glEnable(GL_POLYGON_OFFSET_FILL);
  glPolygonOffset(1,1);

  glColor3f(0,1,0);
  glCallList(pendulum);

  glPopMatrix(); // End of this transformation.
  
  glColor3f(1,0,0); 
  glCallList(up);

  glColor3f(0,0,1);
  glCallList(down);

  glDisable(GL_POLYGON_OFFSET_FILL);


  // The offset drawing mode.
  glColor3f(0,0,0);
  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 

  // We draw again.
  glPushMatrix();
  glTranslatef(0,RADIUS,0);
  glRotatef(AMPLITUDE*sin(angle),0,0,1);
  glTranslatef(0,-RADIUS,0);
  glCallList(pendulum);
  glPopMatrix(); 
  glCallList(up);
  glCallList(down);

  // End of offset.

}

void Example6::Time(glop::Scene* scene)
{  
  angle+=SPEED;
  if(angle>M_PI)
    angle-=2*M_PI;
}
