#include <iostream>
#include "example01.h"


void Example1::InitDrawings(glop::Scene* scene)
{
  // Nothing to do.
}

void Example1::Draw(glop::Scene* scene)
{  
  int i,j;



  /* ######## */
  /* #      # */
  /* # Cube # */
  /* #      # */
  /* ######## */
    
  // The polygon drawing mode
  glPolygonMode(GL_FRONT_AND_BACK,
		GL_FILL); 

  glColor3f(1,0,0); // Red, back 
  glBegin(GL_POLYGON);  
  /* */ glVertex3f(-.5, -.5,-.5);
  /* */ glVertex3f( .5, -.5,-.5);
  /* */ glVertex3f( .5,  .5,-.5);
  /* */ glVertex3f(-.5,  .5,-.5);
  glEnd();

  glColor3f(0,1,0); // green, front
  glBegin(GL_POLYGON);
  /* */ glVertex3f(-.5, -.5, .5);
  /* */ glVertex3f( .5, -.5, .5);
  /* */ glVertex3f( .5,  .5, .5);
  /* */ glVertex3f(-.5,  .5, .5);
  glEnd();

  glColor3f(1,1,0); // yellow, top
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5,  .5,-.5);
  /* */ glVertex3f( .5,  .5,-.5);
  /* */ glVertex3f( .5,  .5, .5);
  /* */ glVertex3f(-.5,  .5, .5);
  glEnd();

  glColor3f(1,1,1); // white, bottom
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5, -.5,-.5);
  /* */ glVertex3f( .5, -.5,-.5);
  /* */ glVertex3f( .5, -.5, .5);
  /* */ glVertex3f(-.5, -.5, .5);
  glEnd();

  glColor3f(1,0,1); // purple, left
  glBegin(GL_POLYGON); 
  /* */ glVertex3f(-.5, -.5,-.5);
  /* */ glVertex3f(-.5,  .5,-.5);
  /* */ glVertex3f(-.5,  .5, .5);
  /* */ glVertex3f(-.5, -.5, .5);
  glEnd();

  glColor3f(0,1,1); // cyan, right
  glBegin(GL_POLYGON); 
  /* */ glVertex3f( .5, -.5,-.5);
  /* */ glVertex3f( .5,  .5,-.5);
  /* */ glVertex3f( .5,  .5, .5);
  /* */ glVertex3f( .5, -.5, .5);
  glEnd();




  /* ############# */
  /* #           # */
  /* # The lines # */
  /* #           # */
  /* ############# */

  // The polygone drawing mode is useless here, we draw lines.

  glColor3f(0,0,1); // X axis
  glBegin(GL_LINES);
  /* */glVertex3f(-5,0,0);
  /* */glVertex3f( 5,0,0);
  glEnd();

  glColor3f(0,1,0); // Y axis
  glBegin(GL_LINES);
  /* */glVertex3f(0,-5,0);
  /* */glVertex3f(0, 5,0);
  glEnd();

  glColor3f(1,0,0); // Z axis
  glBegin(GL_LINES);
  /* */glVertex3f(0,0,-5);
  /* */glVertex3f(0,0, 5);
  glEnd();

  glColor3f(.7,.7,.7); // Grid
  glBegin(GL_LINES); 
  for(i=-5;i<6;i++)
    for(j=-5;j<6;j++)
      if(i!=0 || j!=0)
	{
	  glVertex3f( i, j,-5);
	  glVertex3f( i, j, 5);
	  
	  glVertex3f( i,-5, j);
	  glVertex3f( i, 5, j);
	  
	  glVertex3f(-5, i, j);
	  glVertex3f( 5, i, j);
	}
  glEnd();

  

}
