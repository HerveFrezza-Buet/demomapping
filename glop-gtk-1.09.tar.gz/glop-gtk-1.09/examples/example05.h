#ifndef EXAMPLE_5
#define EXAMPLE_5

#include <glop.h>

// The oscillating stuff.

class Pendulum : public glop::Drawable, public glop::TimeEvent {
  
 private:
  
  double angle;
    
protected:

  void Transform(void);
  

  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
  virtual void Time (glop::Scene *scene);
    
};

// The Sheets

class Sheets : public glop::Drawable {

protected:
  
  virtual void InitDrawings(glop::Scene* scene);
  virtual void Draw(glop::Scene* scene);  
};

// The whole stuff

class Example5 : public glop::DrawableSet, public glop::TimeEventSet{
  
private :

  Pendulum*      pendulum;
  Sheets*        sheets;
  glop::Blender* blender;

public :
    
  Example5(void);
  virtual ~Example5(void);
};


#endif
