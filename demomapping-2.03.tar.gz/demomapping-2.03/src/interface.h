#ifndef INTERFACE_H
#define INTERFACE_H

#include <string>
#include <MAPdist.h>
#include <list>

/* ####### */
/* #     # */
/* # VQP # */
/* #     # */
/* ####### */
typedef struct _VQP_Dot {
  double x,y;
  double red,green,blue;
} VQP_Dot;
extern std::list<VQP_Dot> vqp_dots;





void DisplayError(std::string msg);
void MakeInterface(void);
int MustDrawVertices(void);
int MustDrawAxis(void);
int MustDrawPoints(void);

void ChooseRandomPoint(float* x,float* y,float* z);


void SetDistribCallback(void (*cb)(int));
void DeclareDistrib(const char* title,int num);
void SetDistrib(MAPdist::Distrib* d);

void SetDrawingCallback(void (*cb)(MAPdist::Viewer*,void*));

void DeclareAlgo(const char* title,
		 int num,
		 MAPdist::Params* p,MAPdist::Map* m);
int  GetCurrentAlgo(void);
MAPdist::Params*  GetCurrentParams(void);
MAPdist::Map*  GetCurrentMap(void);
MAPdist::Distrib* GetCurrentDistrib(void);


void SetStepsCallbacks(void (*cbrestart)(void),void (*cbstep)(void));


// GNG-like rendering.
#define RED_HOT     1
#define GREEN_HOT   0
#define BLUE_HOT    0

#define RED_COLD     0
#define GREEN_COLD   0
#define BLUE_COLD    1

#define RED_YOUNG     1
#define GREEN_YOUNG   1
#define BLUE_YOUNG    0

#define RED_OLD     0
#define GREEN_OLD   0
#define BLUE_OLD    0

#endif
