#pragma once

#include <MAPdist.h>
#include "None.h"
#include <vq2.h>
#include "vq2Point.h"
#include <algorithm>
#include <string>


namespace som {
  class WinnerTakeMost {
  public:
    double dmax;
    double operator()(double topo_dist) {
      return std::max(1-topo_dist/dmax,0.0);
    }
  };

  typedef vq2::algo::som::Unit<vq::Point>                   Unit;
  typedef vq2::Graph<Unit,char,Unit::copy_constructor>       Graph;
  typedef Graph::vertex_type                                 Vertex;
  typedef Graph::edge_type                                   Edge;
  typedef Graph::ref_vertex_type                             RefVertex;
  typedef vq2::unit::Similarity<Unit,vq::Similarity>        UnitSimilarity;
  typedef vq2::unit::Learn<Unit,vq::Learn>                  UnitLearn;

#define somKOHONEN_LINE 0
#define somKOHONEN_RING 1
#define somKOHONEN_GRID 2
#define somKOHONEN_TORUS 3

  vq::Point init_vertex_line(unsigned int w) {
    return vq::Point();
  }

  char init_edge_line(unsigned int w, unsigned int ww) {
    return ' ';
  }

  vq::Point init_vertex_grid(unsigned int w, unsigned int h) {
    return vq::Point();
  }

  char init_edge_grid(unsigned int w, unsigned int ww, 
		      unsigned int h, unsigned int hh) {
    return ' ';
  }


  class Kohonen : public Algo {
  public:
    Graph som;
    int width,height,size;
    std::string title;
    int param_learning_idf;
    int param_neighbour_idf;
    std::vector<RefVertex> grid;
    std::vector<RefVertex>::iterator grid_iter;
  
    float example_x,example_y,example_z;
  
    vq::Similarity     distance;
    UnitSimilarity    unit_distance;
    vq::Learn          learning_rule;
    UnitLearn         unit_learning_rule;
    WinnerTakeMost    competition;
  
  Kohonen(int type) 
    : Algo(), 
      distance(),
      unit_distance(distance),
      learning_rule(),
      unit_learning_rule(learning_rule),
      competition() {
      switch(type) {
      case somKOHONEN_LINE:
	width=75,height=1;
	grid = vq2::algo::make::line(som,width,init_vertex_line,init_edge_line);
	title = "Kohonen line";
	break;
      case somKOHONEN_RING:
	width=75,height=1;
	grid = vq2::algo::make::ring(som,width,init_vertex_line,init_edge_line);
	title = "Kohonen ring";
	break;
      case somKOHONEN_GRID:
	width=20,height=20;
	grid = vq2::algo::make::grid(som,width,height,init_vertex_grid,init_edge_grid);
	title = "Kohonen grid";
	break;
      case somKOHONEN_TORUS:
	width=30,height=10;
	// Create a grid
	grid = vq2::algo::make::grid(som,width,height,init_vertex_grid,init_edge_grid);
	// And then connect the borders
	for(unsigned int h = 0 ; h < height ; ++h)
	  som.connect(init_edge_grid(0, h, width-1, h), grid[h*width], grid[(h+1)*width - 1]);
	for(unsigned int w = 0 ; w < width ; ++w)
	  som.connect(init_edge_grid(w, 0, w, height-1), grid[w], grid[(height-1)*width + w]);
	title = "Kohonen torus";
	break;
      default:
	grid = vq2::algo::make::grid(som,10,10,init_vertex_grid,init_edge_grid);
	width=10,height=10;
	title = "Kohonen grid";
	break;
      }
      size = width*height;

    }
    virtual ~Kohonen(void) {}

    void UpdateMap(void) {
      int w,h,k;
      for(h=0,k=0;h<height;++h)
	for(w=0;w<width;++w,++k) {
	  vq::Point& p = (*(grid[k])).value.prototype();
	  GetCurrentMap()->SetValue(w,h,p.x,p.y,p.z);
	}
	
    }

    virtual void Declare(int num) {
      MAPdist::Params* params=new MAPdist::Params("Kohonen SOM");
      param_learning_idf = params->Add("Learning rate",
				       .1,
				       0,1,
				       .01,.1,
				       3);
      param_neighbour_idf = params->Add("Neighborhood size",
					3,
					0,15,
					.1,.5,
					3);
      DeclareAlgo(title.c_str(),
		  num,
		  params,
		  new MAPdist::Map(title.c_str(),
				   width,height,
				   20)
		  );
    }

    class DrawEdge {
    public:
      MAPdist::Viewer* view;
    DrawEdge(MAPdist::Viewer* v) : view(v) {}

      bool operator()(Edge& e) { 
	vq::Point& p1 = (*(e.n1)).value.prototype();
	vq::Point& p2 = (*(e.n2)).value.prototype();
	view->DrawLine(p1.x,p1.y,p1.z,
		       p2.x,p2.y,p2.z);
	return false;
      }
    };

    virtual void DrawLines(MAPdist::Viewer* view) {
      DrawEdge draw(view);
      view->SetDrawingColor(0,0,1);
      som.for_each_edge(draw);
    }

    class DrawVertex {
    public:
      MAPdist::Viewer* view;
    DrawVertex(MAPdist::Viewer* v) : view(v) {}

      bool operator()(Vertex& n) { 
	vq::Point& p = n.value.prototype();
	view->DrawPrototype(p.x,p.y,p.z);
	return false;
      }
    };

    virtual void DrawNeurons(MAPdist::Viewer* view) {
      DrawVertex draw(view);
      view->SetDrawingColor(1,1,1);
      som.for_each_vertex(draw);
    }



    class ResetVertex {
    public:
      bool operator()(Vertex& n) { 
	n.value.prototype() = vq::Point();
	return false;
      }
    };

    virtual void Restart(void) {
      ResetVertex reset;
      som.for_each_vertex(reset);
      UpdateMap();
    }

    virtual void Step(void) {
      competition.dmax = GetCurrentParams()->GetValue(param_neighbour_idf);
      ChooseRandomPoint(&example_x,&example_y,&example_z);
      vq2::algo::som::step(som,unit_distance,competition,
			   unit_learning_rule,
			   GetCurrentParams()->GetValue(param_learning_idf),
			   vq::Point(example_x,example_y,example_z));
      UpdateMap();
    }
  
    virtual int NbProto(void) {
      return size;
    }

    virtual void StartIter(void) {
      grid_iter = grid.begin();
    }

    virtual bool HasNext(void) { 
      return grid_iter != grid.end();
    }

    virtual void Next(float& x, float& y, float& z) {
      vq::Point& p = (*(*(grid_iter++))).value.prototype();
      x = p.x;
      y = p.y;
      z = p.z;
    }
  };
}
