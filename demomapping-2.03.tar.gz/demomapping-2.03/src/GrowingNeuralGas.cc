#include "GrowingNeuralGas.h"
#include "interface.h"
#include <stdlib.h>
#include <math.h>



void GrowingNeuralGas::Declare(int num)
{
  MAPdist::Params* params;
  
  params=new MAPdist::Params("Growing Neural Gas");
  lambda_idf=params->Add("Growing Period",
			 300,
			 10,500,
			 1,10,
			 0);
  agemax_idf=params->Add("Cutting Age",
			 88,
			 2,200,
			 1,10,
			 0);
  rate1_idf=params->Add("Learning Rate 1",
			 .05,
			 0,.5,
			 .001,.01,
			 3);
  rate2_idf=params->Add("Learning Rate 2",
			.01,
			 0,.05,
			 .001,.01,
			3);
  error1_idf=params->Add("Split Error Decrease",
			 .5,
			 0,1,
			 .01,.1,
			 2);
  error2_idf=params->Add("Global Error Decrease",
			 .0005,
			 0,0.01,
			 .0001,.001,
			 4);

  DeclareAlgo("Growing Neural Gas",
	      num,
	      params,
	      new MAPdist::Map("Growing Neural Gas",
			       2,1,
			       gngCELL_SIZE));
}

void GrowingNeuralGas::DrawLines(MAPdist::Viewer* view)
{
  int i,j;
  float coef;
  float age_max;
  
  age_max=GetCurrentParams()->GetValue(agemax_idf);

  for(i=0;i<nb;i++)
    for(j=i+1;j<nb;j++)
      if(edge[i][j]>=0)
	{
	  coef=edge[i][j]/age_max;
	  view->SetDrawingColor(RED_OLD  *coef + RED_YOUNG  *(1-coef),
				GREEN_OLD*coef + GREEN_YOUNG*(1-coef),
				BLUE_OLD *coef + BLUE_YOUNG *(1-coef));
	  view->DrawLine(x[i],y[i],z[i],
			 x[j],y[j],z[j]);
	}
}

void GrowingNeuralGas::DrawNeurons(MAPdist::Viewer* view)
{
  int i;
  float coef,norm;

  if(error_max-error_min==0)
    norm=0;
  else
    norm=1/(error_max-error_min);

  for(i=0;i<nb;i++)
    {
      coef=(error[i]-error_min)*norm;
      view->SetDrawingColor(RED_HOT  *coef + RED_COLD  *(1-coef),
			    GREEN_HOT*coef + GREEN_COLD*(1-coef),
			    BLUE_HOT *coef + BLUE_COLD *(1-coef));
      view->DrawPrototype(x[i],y[i],z[i]);
    }

  view->SetDrawingColor(0,1,0);
  view->DrawPrototype(example_x,example_y,example_z);
}

void GrowingNeuralGas::Restart(void)
{
  int i,j;

  step_nb=0;
  error_max=0;
  error_min=0;

  /* Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);

  /* Reset edges */
  for(i=0;i<NB_MAX;i++)
    {
      for(j=0;j<NB_MAX;j++)
	edge[i][j]=-1;
      nb_edges[i]=0;
    }

  /* There is 2 neurons */
  nb=2;
  for(i=0;i<nb;i++)
    {
      error[i]=0;
      x[i]=(rand()%1000)*.001;
      y[i]=(rand()%1000)*.001;
      z[i]=(rand()%1000)*.001;
    }


  // Draw prototypes in a map.
  if(nb<gngMAP_WIDTH)
    GetCurrentMap()->Resize(nb,1);
  else
    GetCurrentMap()->Resize(gngMAP_WIDTH,(nb+gngMAP_WIDTH)/gngMAP_WIDTH);
  for(i=0;i<nb;i++)
    GetCurrentMap()->SetValue(i%gngMAP_WIDTH,i/gngMAP_WIDTH,
			      x[i],y[i],z[i]);
}

void GrowingNeuralGas::Step(void)
{
  int i;
  int i1,i2;
  float d1,d2,dd0,dd1,ddi;
  float alpha;
  float age_max;
  float maximal_error1,maximal_error2;
  
  age_max=GetCurrentParams()->GetValue(agemax_idf);


  /* 2 - Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);

  /* 3 - Find first and second minima */
  dd0=pow(x[0]-example_x,2)+pow(y[0]-example_y,2)+pow(z[0]-example_z,2);
  dd1=pow(x[1]-example_x,2)+pow(y[1]-example_y,2)+pow(z[1]-example_z,2);
  if(dd1<dd0)
    {
      d1=dd1;d2=dd0;i1=1;i2=0;	
    }
  else
    {
      d1=dd0;d2=dd1;i1=0;i2=1;
    }
  for(i=2;i<nb;i++)
    {
      ddi=pow(x[i]-example_x,2)+pow(y[i]-example_y,2)+pow(z[i]-example_z,2);
      if(ddi<d1)
	{
	  d2=d1;i2=i1;d1=ddi;i1=i;
	}
      else if(ddi<d2)
	{
	  d2=ddi;i2=i;
	}
    }

  /* 4 - Refresh edge */
  edge[i1][i2]=0;
  edge[i2][i1]=0;

  /* 5 - Update Error */
  error[i1]+=d1;

  /* 678 - Learn and update age */

  alpha=GetCurrentParams()->GetValue(rate1_idf);
  x[i1]+=alpha*(example_x-x[i1]);
  y[i1]+=alpha*(example_y-y[i1]);
  z[i1]+=alpha*(example_z-z[i1]);
  alpha*=GetCurrentParams()->GetValue(rate2_idf);

  for(i=0;i<nb;i++)
    if(edge[i1][i]>=0)
      {
	x[i]+=alpha*(example_x-x[i]);
	y[i]+=alpha*(example_y-y[i]);
	z[i]+=alpha*(example_z-z[i]);
	edge[i1][i]++;
	edge[i][i1]++;
	if(edge[i1][i]>age_max)
	  {
	    edge[i1][i]=-1;
	    edge[i][i1]=-1;
	    nb_edges[i1]--;
	    nb_edges[i]--;

	    /* Removing i */
	    if(nb_edges[i]==0)
	      {
		RemoveNeuron(i);
		i--; /* because of removing*/
	      }
	  }
      }



  step_nb++;

  /* 9 - Look for incrementation */
  if((step_nb>=GetCurrentParams()->GetValue(agemax_idf))
     &&(nb<NB_MAX))
    {
      step_nb=0;

      /* Find maximum error unit */
      maximal_error1=0;
      i1=0;
      for(i=0;i<nb;i++)
	if(error[i]>=maximal_error1)
	  {
	    i1=i;
	    maximal_error1=error[i];
	  }

      /* Find maximum error unit int neighborhood */
      maximal_error2=0;
      i2=0;
      for(i=0;i<nb;i++)
	if(edge[i1][i]>=0)
	  if(error[i]>=maximal_error2)
	    {
	      i2=i;
	      maximal_error2=error[i];
	    }

      /* Add the unit */
      nb++;

      /* Interpolate prototype */
      x[nb-1]=.5*(x[i1]+x[i2]);
      y[nb-1]=.5*(y[i1]+y[i2]);
      z[nb-1]=.5*(z[i1]+z[i2]);

      /* Remove original edge and insert a some new ones */
      edge[i1][i2]=-1;
      edge[i2][i1]=-1;
      edge[i1][nb-1]=0;
      edge[nb-1][i1]=0;
      edge[i2][nb-1]=0;
      edge[nb-1][i2]=0;

      /* Decrease split errors */
      alpha=GetCurrentParams()->GetValue(error1_idf);
      error[i1]-=alpha*error[i1];
      error[i2]-=alpha*error[i2];

      /* Interpolate error */
      error[nb-1]=.5*(error[i1]+error[i2]);
    }

  /* 10 - Decrease overall error */
  error_max=error[0];
  error_min=error[0];
  alpha=GetCurrentParams()->GetValue(error2_idf);
  for(i=0;i<nb;i++)
    {
      error[i]-=alpha*error[i];
      if(error[i]>error_max)
	error_max=error[i];
      if(error[i]<error_min)
	error_min=error[i];
    }

  // Draw prototypes in a map.
  if(nb<gngMAP_WIDTH)
    GetCurrentMap()->Resize(nb,1);
  else
    GetCurrentMap()->Resize(gngMAP_WIDTH,(nb+gngMAP_WIDTH)/gngMAP_WIDTH);
  for(i=0;i<nb;i++)
    GetCurrentMap()->SetValue(i%gngMAP_WIDTH,i/gngMAP_WIDTH,
			      x[i],y[i],z[i]);
}

void GrowingNeuralGas::RemoveNeuron(int i)
{
  int ii,jj;

  nb--;
  x[i]=x[nb];
  y[i]=y[nb];
  z[i]=z[nb];
  error[i]=error[nb];
  nb_edges[i]=nb_edges[nb];

  for(ii=0;ii<=nb;ii++)
    for(jj=0;jj<=nb;jj++)
      if(edge[ii][jj]==nb)
	edge[ii][jj]=i;

  
  for(ii=0;ii<=nb;ii++)
    {
      edge[ii][nb]=-1;
      edge[nb][ii]=-1;
    }
}


int GrowingNeuralGas::NbProto(void)
{
  return nb;
}

bool GrowingNeuralGas::HasNext(void)
{
  return iter<nb;
}

void GrowingNeuralGas::Next(float& x, float& y, float& z)
{
  x=this->x[iter];
  y=this->y[iter];
  z=this->z[iter];
  iter++;
}
