#ifndef GROWING_NEURAL_GAS_H
#define GROWING_NEURAL_GAS_H

#include <MAPdist.h>
#include <None.h>

class GrowingNeuralGas :  public Algo
{
 public:
  GrowingNeuralGas(void) {}
  virtual void Declare(int num);
  virtual void DrawLines(MAPdist::Viewer* view);
  virtual void DrawNeurons(MAPdist::Viewer* view);
  virtual void Restart(void);
  virtual void Step(void);

  virtual int NbProto(void);
  virtual bool HasNext(void);
  virtual void Next(float& x, float& y, float& z);

  
  void RemoveNeuron(int i);

#define NB_MAX 300


#define gngMAP_WIDTH  20
#define gngCELL_SIZE  20
  
  float example_x,example_y,example_z;
  float x[NB_MAX];
  float y[NB_MAX];
  float z[NB_MAX];
  float error[NB_MAX];
  float error_max;
  float error_min;
  int nb;
  int edge[NB_MAX][NB_MAX]; /* -1 => no edge */
  int nb_edges[NB_MAX]; 
  int lambda_idf;
  int agemax_idf;
  int rate1_idf;
  int rate2_idf;
  int error1_idf;
  int error2_idf;
  int step_nb;
  

};

#endif
