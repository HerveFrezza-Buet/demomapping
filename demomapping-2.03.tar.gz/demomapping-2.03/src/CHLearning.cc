#include "CHLearning.h"
#include "interface.h"
#include <stdlib.h>
#include <math.h>


void CHLearning::Winner(void)
{
  float min1,min2,d;
  int k;


  /* Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);


  /* Search for winners */
  min1=1000;
  min2=1000;
  for(k=0;k<CHL_K;k++)
    if( ( d = pow(chl_proto[k].x-example_x,2)
	  +   pow(chl_proto[k].y-example_y,2)
	  +   pow(chl_proto[k].z-example_z,2) ) 
	< min2)
      {
	if(d<min1)
	  {
	    min2=min1;
	    k_win2=k_win1;
	    min1=d;
	    k_win1=k;
	  }
	else
	  {
	    min2=d;
	    k_win2=k;
	  }
      }
}

void CHLearning::Step(void)
{
  Winner();
  edge[k_win1][k_win2]=true;
  edge[k_win2][k_win1]=true;
}


void CHLearning::Declare(int num)
{
  DeclareAlgo("Competitive Hebian Learning",
	      num,
	      NULL,
	      NULL);
}

void CHLearning::DrawLines(MAPdist::Viewer* view)
{
  int i,j;


  view->SetDrawingColor(0,0,1);
  for(i=0;i<CHL_K;i++)
    for(j=i+1;j<CHL_K;j++)
      if(edge[i][j])
	view->DrawLine(chl_proto[i].x,chl_proto[i].y,chl_proto[i].z,
		       chl_proto[j].x,chl_proto[j].y,chl_proto[j].z);
}

void CHLearning::DrawNeurons(MAPdist::Viewer* view)
{
  int k;

  view->SetDrawingColor(0,1,0);
  view->DrawPrototype(example_x,example_y,example_z);
  for(k=0;k<CHL_K;k++)
    {
      if(k==k_win1)
	view->SetDrawingColor(1,0,0);
      else if(k==k_win2)
	view->SetDrawingColor(1,.5,.5);
      else
	view->SetDrawingColor(1,1,1);
      view->DrawPrototype(chl_proto[k].x,chl_proto[k].y,chl_proto[k].z);
    }
}

void CHLearning::Restart(void)
{
  int k;
  int i,j;
  
  k_win1=-1;
  k_win2=-1;
  
  for(i=0;i<CHL_K;i++)
    for(j=0;j<CHL_K;j++)
      {
	edge[i][j]=false;
	edge[j][i]=false;
      }

  /* Compute random prototype from distribution */
  for(k=0;k<CHL_K;k++)
    ChooseRandomPoint(&(chl_proto[k].x),&(chl_proto[k].y),&(chl_proto[k].z));
    
  /* Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);
}

int CHLearning::NbProto(void)
{
  return CHL_K;
}

bool CHLearning::HasNext(void)
{
  return iter<CHL_K;
}

void CHLearning::Next(float& x, float& y, float& z)
{
  x=chl_proto[iter].x;
  y=chl_proto[iter].y;
  z=chl_proto[iter].z;
  iter++;
}

