#ifndef NONE_H
#define NONE_H

#include <MAPdist.h>

class Algo 
{

 protected:

  int iter;

 public: 
  Algo(void) {}
  virtual ~Algo(void) {}
  virtual void Declare(int num);
  virtual void DrawLines(MAPdist::Viewer* view);
  virtual void DrawNeurons(MAPdist::Viewer* view);
  virtual void Restart(void);
  virtual void Step(void);
  
  virtual int NbProto(void);
  virtual void StartIter(void);
  virtual bool HasNext(void);
  virtual void Next(float& x, float& y, float& z);
  void BestMatch(unsigned char* rgb_pixel);
};

#endif
