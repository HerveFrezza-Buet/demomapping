#include "interface.h"
#include "GrowingGrid.h"
#include <stdlib.h>
#include <math.h>



void GrowingGrid::Declare(int num)
{

  MAPdist::Params* params;
  
  map_width=2;
  map_height=2;
  params=new MAPdist::Params("Growing Grid");
  param_lambda_idf=params->Add("Growing Period",
			       100,
			       0,200,
			       1,10,
			       0);
  param_sigma_idf=params->Add("Maxican Variancy",
			       .7,
			       0.01,10,
			       .01,.1,
			       2);
  param_epsilon_idf=params->Add("Learning Rate",
			       .01,
			       0,.1,
			       .0001,.001,
			       4);


  DeclareAlgo("Growing Grid",
	      num,
	      params,
	      new MAPdist::Map("Growing Grid",
			     map_width,map_height,
			     GrowingGridCELL_SIZE));
}

void GrowingGrid::DrawLines(MAPdist::Viewer* view)
{
  int w,h,k;

  view->SetDrawingColor(1,0,1);
  for(h=0,k=0;h<map_height-1;h++,k++)
    for(w=0;w<map_width-1;w++,k++)
      {
	view->DrawLine(x[k],y[k],z[k],
		       x[k+1],y[k+1],z[k+1]);
	view->DrawLine(x[k],y[k],z[k],
		       x[k+map_width],y[k+map_width],z[k+map_width]);
      }
  for(w=0,k=(map_height-1)*map_width;w<map_width-1;w++,k++)
    view->DrawLine(x[k],y[k],z[k],
		   x[k+1],y[k+1],z[k+1]);
  for(h=0,k=map_width-1;h<map_height-1;h++,k+=map_width)
    view->DrawLine(x[k],y[k],z[k],
		   x[k+map_width],y[k+map_width],z[k+map_width]);
}

void GrowingGrid::DrawNeurons(MAPdist::Viewer* view)
{
  int w,h,k;

  view->SetDrawingColor(0,1,0);
  view->DrawPrototype(example_x,example_y,example_z);
  view->SetDrawingColor(1,1,1);
  for(h=0,k=0;h<map_height;h++)
    for(w=0;w<map_width;w++,k++)
      view->DrawPrototype(x[k],y[k],z[k]);
}

void GrowingGrid::Restart(void)
{
  int w,h,k;

  map_width=2;
  map_height=2;
  t=0;
  

  GetCurrentMap()->Resize(map_width,map_height);
  
  /* initialize local counters */
  for(k=0;k<GrowingGridMAP_SIZE;k++)
    tau[k]=0;

  /* Compute random prototype */
  for(h=0,k=0;h<map_height;h++)
    for(w=0;w<map_width;w++,k++)
      {
	x[k]=(rand()%1000)*.001;
	y[k]=(rand()%1000)*.001;
	z[k]=(rand()%1000)*.001;
      }

  /* Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);

  ComputeMap();
}

void GrowingGrid::Step(void)
{ 
  float sigma,epsilon;
  int lambda;
  int winner_w,winner_h;
  float min;
  int max;
  float max_dist;
  float d;
  int w,h,k,kk;
  float alpha;
  float xx,yy,zz;
  int dh,dw;
  int col,line;

  /* Get current parameters */
  sigma  =GetCurrentParams()->GetValue(param_sigma_idf);
  epsilon=GetCurrentParams()->GetValue(param_epsilon_idf);
  lambda =(int)GetCurrentParams()->GetValue(param_lambda_idf);
  

  /* Compute sigma coef from sigma */
  if(sigma!=0)
    sigma=.5/sigma/sigma;

  /* 2- Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);
  
  /* 3- Find winner */
  min=100000;
  for(h=0,k=0;h<map_height;h++)
    for(w=0;w<map_width;w++,k++)
      {
	d=pow(x[k]-example_x,2)+pow(y[k]-example_y,2)+pow(z[k]-example_z,2);
	if(d<min)
	  {
	    min=d;
	    winner_w=w;
	    winner_h=h;
	  }
      }

  /* 4- Increase local time counter for winner*/
  tau[winner_h*map_width+winner_w]++;

  /* 5- Increase time parameter */
  t++;
  
  /* 6- Adapt each unit */
  for(h=0,k=0;h<map_height;h++)
    for(w=0;w<map_width;w++,k++)
      {
	d=fabs(winner_w-w)+fabs(winner_h-h);
	alpha=epsilon*exp(-d*sigma);
	x[k]+=alpha*(example_x-x[k]);
	y[k]+=alpha*(example_y-y[k]);
	z[k]+=alpha*(example_z-z[k]);
	GetCurrentMap()->SetValue(w,h,
				  x[k],y[k],z[k]);
      }
  
  /* 7- Do we increase size ? */

  if(lambda*map_width*map_height<=t)
    {
      /* 7.1- Find the maximal tau unit */
      max=0;
      for(h=0,k=0;h<map_height;h++)
	for(w=0;w<map_width;w++,k++)
	  if(tau[k]>max)
	    {
	      max=tau[k];
	      winner_w=w;
	      winner_h=h;
	    }
      
      /* 7.2- Find the most distant neigbour */
      kk=winner_h*map_height+winner_w;
      max_dist=0;
      for(dw=0,dh=-1;
	  dh<2;
	  dh+=2)
	if((winner_h+dh>=0)
	   &&(winner_h+dh<map_height)
	   &&(winner_w+dw>=0)
	   &&(winner_w+dw<map_width))
	  {
	    k=(winner_h+dh)*map_width+winner_w+dw;
	    d=pow(x[k]-x[kk],2)+pow(y[k]-y[kk],2)+pow(z[k]-z[kk],2);
	    if(d>=max_dist)
	      {
		line=dh;
		col=dw;
		max_dist=d;
	      }
	  }
      for(dh=0,dw=-1;
	  dw<2;
	  dw+=2)
	if((winner_h+dh>=0)
	   &&(winner_h+dh<map_height)
	   &&(winner_w+dw>=0)
	   &&(winner_w+dw<map_width))
	  {
	    k=(winner_h+dh)*map_width+winner_w+dw;
	    d=pow(x[k]-x[kk],2)+pow(y[k]-y[kk],2)+pow(z[k]-z[kk],2);
	    if(d>=max_dist)
	      {
		line=dh;
		col=dw;
		max_dist=d;
	      }
	  }

      /* 7.3- Add row or column */
      
      if(col<0)
	{
	  if(InsertColumnAfter(winner_w-1))
	    for(k=winner_w,h=0;
		h<map_height;
		h++,k+=map_width)
	      {
		x[k]=.5*(x[k-1]+x[k+1]);
		y[k]=.5*(y[k-1]+y[k+1]);
		z[k]=.5*(z[k-1]+z[k+1]);
	      }
	}

      if(col>0)
	{
	  if(InsertColumnAfter(winner_w))
	    for(k=winner_w+1,h=0;
		h<map_height;
		h++,k+=map_width)
	      {
		x[k]=.5*(x[k-1]+x[k+1]);
		y[k]=.5*(y[k-1]+y[k+1]);
		z[k]=.5*(z[k-1]+z[k+1]);
	      }
	}

      if(line<0)
	{
	  if(InsertRowAfter(winner_h-1))
	    for(k=winner_h*map_width,w=0;
		w<map_width;
		w++,k++)
	      {
		x[k]=.5*(x[k-map_width]+x[k+map_width]);
		y[k]=.5*(y[k-map_width]+y[k+map_width]);
		z[k]=.5*(z[k-map_width]+z[k+map_width]);
	      }
	}

      if(line>0)
	{
	  if(InsertRowAfter(winner_h))
	    for(k=(winner_h+1)*map_width,w=0;
		w<map_width;
		w++,k++)
	      {
		x[k]=.5*(x[k-map_width]+x[k+map_width]);
		y[k]=.5*(y[k-map_width]+y[k+map_width]);
		z[k]=.5*(z[k-map_width]+z[k+map_width]);
	      }
	}
      
      /* 7.4- Reset */
      t=0;
      for(k=0;k<GrowingGridMAP_SIZE;k++)
	tau[k]=0;
    }
  

  ComputeMap();
}

void GrowingGrid::ComputeMap(void)
{
  int w,h,k;
  MAPdist::Map* map;

  map=GetCurrentMap();
  
  for(h=0,k=0;h<map_height;h++)
    for(w=0;w<map_width;w++,k++)
      map->SetValue(w,h,
		    x[k],y[k],z[k]);
}

int GrowingGrid::InsertColumnAfter(int i)
{
  int mw;
  int ko,k,kko,kk,w;

  if((map_width+1)*map_height<=GrowingGridMAP_SIZE)
    {
      mw=map_width;
      map_width++;

      for(ko=map_height*mw-1,kko=map_height*map_width-1;
	  ko>=mw-1;
	  ko-=mw,kko-=map_width)
	{
	  for(k=ko,kk=kko,w=mw-1;
	      w>i;
	      k--,kk--,w--)
	    {
	      x[kk]=x[k];
	      y[kk]=y[k];
	      z[kk]=z[k];
	    }
	  kk--;
	  for(;
	      w>=0;
	      k--,kk--,w--)
	    {
	      x[kk]=x[k];
	      y[kk]=y[k];
	      z[kk]=z[k];
	    }
	}
      GetCurrentMap()->Resize(map_width,map_height);	    
      return 1;
    }
  else
    return 0;
}

int GrowingGrid::InsertRowAfter(int i)
{
  int w,h;
  int k,kk;

  if(map_width*(map_height+1)<=GrowingGridMAP_SIZE)
    {
      map_height++;
      for(h=map_height-1;h>i+1;h--)
	for(w=0,k=(h-1)*map_width,kk=h*map_width;
	    w<map_width;
	    w++,k++,kk++)
	  {
	    x[kk]=x[k];
	    y[kk]=y[k];
	    z[kk]=z[k];
	  }
      GetCurrentMap()->Resize(map_width,map_height);
      return 1;
    }
  else
    return 0;
}

int GrowingGrid::NbProto(void)
{
  return map_width*map_height;
}

bool GrowingGrid::HasNext(void)
{
  return iter<map_width*map_height;
}

void GrowingGrid::Next(float& x, float& y, float& z)
{
  x=this->x[iter];
  y=this->y[iter];
  z=this->z[iter];
  iter++;
}
