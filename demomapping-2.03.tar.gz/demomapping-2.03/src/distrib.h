#ifndef DISTRIB_H
#define DISTRIB_H

#include <MAPdist.h>


#define DistBLOCK_THICK            0
#define DistTORUS                  1
#define DistCYLINDER_THICK         2
#define DistCYLINDER_THIN          3
#define DistBLOCK_THIN             4
#define DistDUAL_DENSITY           5
#define DistTHREE_DIMENSIONS       6
#define DistTWO_TORUS              7
#define DistGAUSS                  8
#define DistFLAT_GAUSS             9
#define DistTWO_GAUSS             10
#define DistFLAT_TORUS            11
#define DistEMPTY_SPHERE          12
#define DistSPHERE                13
#define DistTRIANGLE              14
#define DistGRADIENT_THICK        15
#define DistGRADIENT_THIN         16
#define DistTWO_BLOCKS            17
#define DistPICTURE               18
#define DistDOTS                  19

#define DistBLOCK_FULL            20


void DeclareDistribs(void);
MAPdist::Distrib* GetInitialDistrib(void);

class Triangle : public MAPdist::Distrib {

  public:

  Triangle(void);
  virtual float GetDensity(float x,float y,float z);


};

class Gradient : public MAPdist::Distrib {

  double _thickness;

  public:

  Gradient(double thickness);
  virtual float GetDensity(float x,float y,float z);
};


#endif
