#include "interface.h"
#include "None.h"
#include <MAPdist.h>


void Algo::Declare(int num)
{
  DeclareAlgo("None",
	      num,
	      (MAPdist::Params*)NULL,
	      (MAPdist::Map*)NULL);
}

void Algo::DrawLines(MAPdist::Viewer* view)
{
}

void Algo::DrawNeurons(MAPdist::Viewer* view)
{
}

void Algo::Restart(void)
{
}

void Algo::Step(void)
{
}

int Algo::NbProto(void)
{
  return 0;
}

void Algo::StartIter(void)
{
  iter=0;
}

bool Algo::HasNext(void)
{
  return false;
}

void Algo::Next(float& x, float& y, float& z)
{
}

void Algo::BestMatch(unsigned char* rgb_pixel)
{
  float x,y,z;
  float _x,_y,_z;
  float px,py,pz;
  double min,match,tmp;
  
  StartIter();
  if(!HasNext())
    {
      rgb_pixel[0]=180;
      rgb_pixel[1]=180;
      rgb_pixel[2]=180;
    }
  else
    {
      px=rgb_pixel[0]/(float)255;
      py=rgb_pixel[1]/(float)255;
      pz=rgb_pixel[2]/(float)255;
      Next(x,y,z);
      min = (tmp=px-x)*tmp  
	+   (tmp=py-y)*tmp  
	+   (tmp=pz-z)*tmp;

      while(HasNext())
	{
	  Next(_x,_y,_z);
	  match=(tmp=px-_x)*tmp  +  (tmp=py-_y)*tmp  +  (tmp=pz-_z)*tmp;
	  if(match<min)
	    {
	      min=match;
	      x=_x;y=_y;z=_z;
	    }
	}

      rgb_pixel[0]=(unsigned char)(x*255+.5);
      rgb_pixel[1]=(unsigned char)(y*255+.5);
      rgb_pixel[2]=(unsigned char)(z*255+.5);
      
    }
}
