#pragma once

namespace vq {

  class Point {
  public:
    double x,y,z;
    Point(void) : x(vq2::proba::random::uniform()),
		  y(vq2::proba::random::uniform()),
		  z(vq2::proba::random::uniform()) {}
    Point(double xx, double yy, double zz) 
      : x(xx), y(yy), z(zz) {}
    Point(const Point& p) : x(p.x), y(p.y), z(p.z) {}
    Point& operator=(const Point& p) {
      if(this != &p) {
	x = p.x;
	y = p.y;
	z = p.z;
      }
      return *this;
    }
  };

  class Similarity {
  public:
    typedef Point value_type;
    typedef Point sample_type;
    double operator()(const value_type& arg1,
		      const sample_type& arg2) {
      double dx = arg1.x - arg2.x;
      double dy = arg1.y - arg2.y;
      double dz = arg1.z - arg2.z;
      return dx*dx + dy*dy + dz*dz;
    }
  };

  class Learn {
  public:
    typedef Point sample_type;
    typedef Point weight_type;
    void operator()(double coef,
		    weight_type& prototype,
		    const sample_type& target) {
      prototype.x += coef * (target.x - prototype.x);
      prototype.y += coef * (target.y - prototype.y);
      prototype.z += coef * (target.z - prototype.z);
    }
  };
}
