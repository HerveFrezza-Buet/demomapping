#ifndef CHLEARNING_H
#define CHLEARNING_H

#include <MAPdist.h>
#include <None.h>

class CHLearning : public Algo
{
 public:
  CHLearning(void) {}
  virtual void Declare(int num);
  virtual void DrawLines(MAPdist::Viewer* view);
  virtual void DrawNeurons(MAPdist::Viewer* view);
  virtual void Restart(void);
  virtual void Step(void);

  void Winner(void);

  virtual int NbProto(void);
  virtual bool HasNext(void);
  virtual void Next(float& x, float& y, float& z);

  float example_x,example_y,example_z;
  
#define CHL_K 100

  struct {
    float x,y,z;
  } chl_proto[CHL_K];
  
  int k_win1,k_win2;
  
  bool edge[CHL_K][CHL_K];
};

#endif
