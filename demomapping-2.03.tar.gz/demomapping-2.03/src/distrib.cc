#include "interface.h"
#include "distrib.h"
#include <math.h>
#include <gtk/gtk.h>

extern GtkWidget* name_entry;

MAPdist::Distrib* GetDistrib(int i);
void CBDistrib(int num);


Triangle::Triangle(void)
  :MAPdist::Distrib(1,1,1)
{
}

float Triangle::GetDensity(float x,float y,float z)
{
  if((fabs(z)<.05)
     && (y>-.3+.3*x)
     && (-1.7*x+.5>y)
     && ( 2*x+.5>y))
     return .8;
  else
    return 0;
}


Gradient::Gradient(double thickness)
  :MAPdist::Distrib(1,1,1)
{
  _thickness=thickness;
}

float Gradient::GetDensity(float x,float y,float z)
{
  if(fabs(z)<_thickness/2)
    return .8*(1-(x+.5));
  else
    return 0;
}


MAPdist::Distrib* GetDistrib(int i)
{
  MAPdist::Distrib* res;
  MAPdist::Picture* picture;	
  std::string load_fail;
  switch(i)
    {
    default:
    case DistBLOCK_FULL:
      res=new MAPdist::Block(1.,1.,1.,.1);
      break;
    case DistBLOCK_THICK:
      res=new MAPdist::Block(.8,.8,.5,.1);
      break;
    case DistBLOCK_THIN:
      res=new MAPdist::Block(.8,.8,.1,.5);
      break;
    case DistTORUS:
      res=new MAPdist::Scale(new MAPdist::Torus(.25,.1),
			   .8,.8,.8);
      break;
    case DistCYLINDER_THICK:
      res=new MAPdist::Rotate(new MAPdist::Scale(new MAPdist::Cylinder(.1),
					     .5,.5,1),
			    45,-1,1,0);
      break;
    case DistCYLINDER_THIN:
      res=new MAPdist::Rotate(new MAPdist::Scale(new MAPdist::Cylinder(1),
					     .05,.05,2),
			    45,-1,1,0);
      break;
    case DistDUAL_DENSITY:
      res=new MAPdist::Or(new MAPdist::Block(.5,1,.1,.1),
			.5,0,0,
			new MAPdist::Block(.5,1,.1,.5));
      break;
    case DistTHREE_DIMENSIONS:
      res=new MAPdist::Scale(new MAPdist::Or(new MAPdist::Or(new MAPdist::Or(new MAPdist::Block(.5,1,1,.5),
								     .5,0,0,
								     new MAPdist::Block(.5,1,.1,.5)),
						       .75,0,0,
						       new MAPdist::Rotate(new MAPdist::Scale(new MAPdist::Cylinder(.5),
											  .1,.1,.5),
									 90,0,1,0)),
					 1,0,0,
					 new MAPdist::Rotate(new MAPdist::Scale(new MAPdist::Torus(.1,.5),
									    .5,.5,.5),
							   45,1,0,0)),
			   .7,.7,.7);
      break;

    case DistFLAT_TORUS:
      res=new MAPdist::And(new MAPdist::And(new MAPdist::Cylinder(.3),
					0,0,0,
					new MAPdist::Not(new MAPdist::Or(new MAPdist::Block(1,1,1,0),
								     0,0,0,
								     new MAPdist::Scale(new MAPdist::Cylinder(1),
										      .6,.6,1)))),
			 0,0,0,
			 new MAPdist::Block(1,1,.1,.3));
      break;

    case DistTWO_TORUS:
      res=new MAPdist::Scale(new MAPdist::Or(new MAPdist::Rotate(new MAPdist::Torus(.15,.3),
							   45,1,0,0),
					 .5,0,0,
					 new MAPdist::Rotate(new MAPdist::Torus(.15,.3),
							   -45,1,0,0)),
			   .8,.8,.8);
			
      break;
      
    case DistTWO_BLOCKS:
      res=new MAPdist::Or(new MAPdist::Block(.3,.3,.3,.8),
			  .5,.5,.5,
			  new MAPdist::Block(.3,.3,.3,.8));
      break;
      

    case DistGAUSS:
      res= new MAPdist::Scale(new MAPdist::Gauss(1,.15),
			    1.5,1.5,1.5);
      break;

    case DistFLAT_GAUSS:
      res= new MAPdist::Scale(new MAPdist::Gauss(1,.15),
			    1.5,1.5,.1);
      break;

    case DistTWO_GAUSS:
      res= new MAPdist::Scale(new MAPdist::Or(new MAPdist::Gauss(1,.2),
					  1,1,1,
					  new MAPdist::Gauss(1,.2)),
			    .7,.7,.7);
      break;

    case DistSPHERE:
      res= new MAPdist::Sphere(.1);
      break;

    case DistTRIANGLE:
      res= new Triangle();
      break;

    case DistGRADIENT_THICK:
      res= new Gradient(1);
      break;
    case DistGRADIENT_THIN:
      res= new Gradient(.1);
      break;
      
    case DistEMPTY_SPHERE:
      res=new MAPdist::And(new MAPdist::Sphere(.1),
			 0,0,0,
			 new MAPdist::Not(new MAPdist::Or(new MAPdist::Block(1,1,1,0),
						      0,0,0,
						      new MAPdist::Scale(new MAPdist::Sphere(1),
								       .9,.9,.9))));
      break;
    case DistPICTURE:	

      picture = new MAPdist::Picture(1000);

      if(!picture->Load(gtk_entry_get_text(GTK_ENTRY(name_entry))))
	{
	  load_fail="Cannot load \"";
	  load_fail+=gtk_entry_get_text(GTK_ENTRY(name_entry));
	  load_fail+="\" : No file or not ppm (only P5 and P6 allowed).";
	  DisplayError(load_fail);
	}
      

      res=picture;
      break;
    case DistDOTS:
#define DOT_SIZE .1
#define DOT_DENSITY 1
#define DOT new MAPdist::Scale(new MAPdist::Sphere(DOT_DENSITY),DOT_SIZE,DOT_SIZE,DOT_SIZE)
      res = new MAPdist::Or(new MAPdist::Or(new MAPdist::Or(new MAPdist::Or(DOT,0,.5,0,DOT),
							    .5,0,0,
							    new MAPdist::Or(DOT,.5,.2,0,DOT)),
					    0,0,0,
					    new MAPdist::Or(new MAPdist::Or(DOT,1,.4,0,DOT),
							    -.4,-.8,0,
							    new MAPdist::Or(DOT,.5,.7,0,DOT))),
			    0,0,0,
			    new MAPdist::Or(new MAPdist::Or(DOT,-.5,.2,0,DOT),
					    -.4,.1,0,
					    new MAPdist::Or(DOT,.5,.7,0,DOT)));
    
    
      break;
    }

  res->Translate(.5,.5,.5); 
  res->Build();

  return res;
}

void DeclareDistribs(void)
{
  SetDistribCallback(CBDistrib);

  DeclareDistrib("Full Block",DistBLOCK_FULL);
  DeclareDistrib("Block",DistBLOCK_THICK);
  DeclareDistrib("Flat Block",DistBLOCK_THIN);
  DeclareDistrib("Flat Triangle",DistTRIANGLE);
  DeclareDistrib("Flat Torus",DistFLAT_TORUS);
  DeclareDistrib("Flat 2 Densities",DistDUAL_DENSITY);
  DeclareDistrib("Flat Gradient",DistGRADIENT_THIN);
  DeclareDistrib("Flat Gaussian",DistFLAT_GAUSS);
  DeclareDistrib("Cylinder",DistCYLINDER_THICK);
  DeclareDistrib("Sphere",DistSPHERE);
  DeclareDistrib("Empty Sphere",DistEMPTY_SPHERE);
  DeclareDistrib("Torus",DistTORUS);
  DeclareDistrib("2 Blocks",DistTWO_BLOCKS);  
  DeclareDistrib("2 Torus",DistTWO_TORUS);  
  DeclareDistrib("String",DistCYLINDER_THIN);
  DeclareDistrib("Gradient",DistGRADIENT_THICK);
  DeclareDistrib("3 dimensions",DistTHREE_DIMENSIONS);
  DeclareDistrib("Gaussian",DistGAUSS);
  DeclareDistrib("2 Gaussians",DistTWO_GAUSS);
  DeclareDistrib("Picture",DistPICTURE);
  DeclareDistrib("Dots",DistDOTS);
}

MAPdist::Distrib* GetInitialDistrib(void)
{
  return GetDistrib(DistBLOCK_FULL);
}

void CBDistrib(int num)
{
  SetDistrib(GetDistrib(num));
}
