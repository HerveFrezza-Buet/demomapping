#include "interface.h"
#include "distrib.h"
#include <gtk/gtk.h>
#include <MAPdist.h>
#include <None.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>

static char * Supelec_xpm[] = {
"81 78 5 1",
" 	c None",
".	c #FFFFFF",
"+	c #0039EE",
"@	c #00FF00",
"#	c #FF0018",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++..++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++..++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++..++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++...+++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++....++++++++++++++++++++++.. ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++.....+++++++++++++++++..++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++.......+++++++++....++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++.........+........+++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++................+++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++...............+++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++.............++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++..............+++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++................++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++..................++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++......+++++++.......+++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++....++++++++++++++......+++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++...+++++++++++++++++++++....+++++++++++++++++++++ ",
".++++++++++++++++++++++++++...+++++++++++++++++++++++++....+++++++++++++++++++++ ",
".++++++++++++++++++++++...++++++++++++++++++++++++++++++...+++++++++++++++++++++ ",
".++++++++++++++++++...++++++++++++++++++++++++++++++++++...+++++++++++++++++++++ ",
".+++++++++++++++....+++++++++++++++++++++++++++++++++++++..+++++++++++++++++++++ ",
".+++++++++++...++++++++++++++++++++++++++++++++++++++++++..+++++++++++++++++++++ ",
".+++++++...++++++++++++++++++++++++++++++++++++++++++++++..+++++++++++++++++++++ ",
".+++...+++++++++++++++++++++++++++++++++++++++++++++++++++..++++++++++++++++++++ ",
"...+++++++++++++++++++++++++++++++++++++++++++++++++++++++..++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++ ",
".++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++ ",
".+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ",
"                                                                                 ",
"                                                                                 ",
"                                                        #                        ",
"    #####                                         #  ####                        ",
"   ##  ####                                      ##  ####                        ",
"  ##     ##                                     ###   ###                        ",
" ###     ##                                    ##     ###                        ",
" ##       #                                   ##      ###                        ",
"###                                          #        ###                        ",
" ###                                                  ###                        ",
" ####                         #                       ###                        ",
"  #####      ####    ####    ## ######       #####    ###     ######      ###### ",
"  #######      ##     ###  ############     #    ##   ###    ##   ###    ##   ###",
"    ######     ##      ##   ###     ###    ##    ###  ###   ##     ##   ##    ###",
"     ######    ##      ##    ##      ###   ##    ###  ###   ##     ##  ##        ",
"       #####   ##      ##    ##       ##  ##########  ###  ##########  ##        ",
"        ####   ##      ##    ##       ##  ##          ###  ##          ##        ",
"         ###   ##      ##    ##       ##  ##          ###  ##          ##        ",
"         ###   ##      ##    ##       ##  ##          ###  ###         ##        ",
"##       ###   ##      ##    ##       ##  ###         ###  ###         ###       ",
" #       ###   ##     ###    ##      ##   ####     #  ###   ###     #  ####    ##",
" ##     ###    #### ## ####  ###    ##     ##### ##   ###   ##### ##    ##### ## ",
" #########      ###### ###   ########       ######  #######  #######    #######  ",
"   ####          ###   #     #####           ####              ###         ###   ",
"                             ##                                                  ",
"                             ##                                                  ",
"                             ##                                                  ",
"                             ##                                                  ",
"                             ##                                                  ",
"                           ######                                                "};


#define NB_ALGO_MAX 100


GdkColormap *colormap;
GdkPixmap *gdkpixmap;
GdkBitmap *mask;
GtkWidget *frame_pix;
GtkWidget *pixmap;
GtkWidget *window1;
GtkWidget *hpaned1;
GtkWidget *vbox1;
GtkWidget *vbox_map;
GtkWidget *vbox3;
GtkWidget *algo_frame;
GtkWidget *optionmenu2;
GtkWidget *optionmenu2_menu;
GtkWidget *glade_menuitem;
GtkWidget *distribution_frame;
GtkWidget *vbox2;
GtkWidget *optionmenu1;
GtkWidget *optionmenu1_menu;
GtkWidget *hbox2;
GtkWidget *checkbutton1;
GtkWidget *checkbutton2;
GtkWidget *checkbutton3;
GtkWidget *hbox1;
GtkWidget *name_entry;
GtkWidget *hbox3;
GtkWidget *browse;


GtkWidget *image_selection;
GtkWidget *ok_button1;
GtkWidget *cancel_button1;

GtkWidget *error;
GtkWidget *dialog_vbox1;
GtkWidget *error_msg;
GtkWidget *dialog_action_area1;
GtkWidget *ok_error;

GtkWidget *window2;
GtkWidget *frame1;
GtkWidget *frame2;
GtkWidget *pic;
GtkWidget *src;
GtkWidget *paint;
GtkWidget *hbox4;
GdkGC     *picgc=(GdkGC*)NULL;

GtkWidget *window3;
GtkWidget *frame3;
GtkWidget *frame4;
GtkWidget *vqp;
GtkWidget *vqp_button;
GdkGC     *vqpgc=(GdkGC*)NULL;


MAPdist::Viewer* viewer;
MAPdist::Steps* steps;
MAPdist::Params* algo_param;

void (*distrib_cb)(int)=NULL;
void (*restart_cb)(void)=NULL;
void (*step_cb)(void)=NULL;

int current_algo=-1;
MAPdist::Params* params[NB_ALGO_MAX];
MAPdist::Map* maps[NB_ALGO_MAX];
int full[NB_ALGO_MAX];
int step_idf;
unsigned char* rgb_buf=(unsigned char*)NULL;
int rgb_width,rgb_height;
extern Algo** algos;
std::list<VQP_Dot> vqp_dots;

MAPdist::Params* vqp_params;
int  alpha_vqp_idf;
int  lambda_vqp_idf;




gboolean
on_vqp_expose_event                    (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data);
void
on_vqp_clicked                       (GtkButton       *button,
                                        gpointer         user_data);
gboolean
on_pic_expose_event                    (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data);

void
on_paint_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_src_clicked                       (GtkButton       *button,
				      gpointer         user_data);


gboolean
on_error_delete_event                  (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  gtk_widget_hide(error);
  gtk_main_quit();
  return TRUE;
}


gboolean
on_error_destroy_event                 (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{

  gtk_widget_hide(error);
  gtk_main_quit();
  return TRUE;
}


void
on_ok_error_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_hide(error);
  gtk_main_quit();
}


void
on_browse_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_show(image_selection);
}


void
on_ok_button1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_entry_set_text(GTK_ENTRY(name_entry),
		     gtk_file_selection_get_filename(GTK_FILE_SELECTION(image_selection)));
  gtk_option_menu_set_history(GTK_OPTION_MENU(optionmenu1),DistPICTURE);
  (*distrib_cb)(DistPICTURE);
  gtk_widget_hide(image_selection);
}


void
on_cancel_button1_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_hide(image_selection);
}


gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
void
on_optionmenu1_clicked                 (GtkWidget       *wdgt,
                                        gpointer         user_data);
void
on_optionmenu2_clicked                 (GtkWidget       *wdgt,
                                        gpointer         user_data);
void
on_check_clicked                 (GtkWidget       *wdgt,
				  gpointer         user_data);

void UpdateAlgoVisibility(void);


void CBRestart(MAPdist::Steps* s,void* data)
{
  if(restart_cb!=NULL)
    (*restart_cb)();

  viewer->Redisplay();
  if(maps[current_algo]!=NULL)
    maps[current_algo]->Redisplay();
}

void CBStep(MAPdist::Steps* s,void* data)
{
  int skipped,i;

  if(step_cb!=NULL)
    {
      skipped=(int)(algo_param->GetValue(step_idf));
      for(i=0;i<=skipped;i++)
	(*step_cb)();
    }
  viewer->Redisplay();
  if(maps[current_algo]!=NULL)
    maps[current_algo]->Redisplay();
}



void SetDrawingCallback(void (*cb)(MAPdist::Viewer*,void*))
{
  viewer->SetDrawingCallback(cb,NULL);
}

void SetDistribCallback(void (*cb)(int))
{
  distrib_cb=cb;
}

void SetDistrib(MAPdist::Distrib* d)
{
  viewer->SetDistrib(d);
  viewer->Redisplay();
}

void DeclareDistrib(const char* title,int num)
{
  glade_menuitem = gtk_menu_item_new_with_label (title);
  gtk_widget_show (glade_menuitem);
  gtk_menu_append (GTK_MENU (optionmenu1_menu), glade_menuitem);
  gtk_signal_connect (GTK_OBJECT (glade_menuitem), "activate",
		      GTK_SIGNAL_FUNC (on_optionmenu1_clicked),
		      (gpointer)num);
  gtk_option_menu_set_history(GTK_OPTION_MENU(optionmenu1),0);
}

void MakeInterface(void)
{
  for(int i=0;i<NB_ALGO_MAX;i++)
    {
      full[i]=0;
      maps[i]=(MAPdist::Map*)NULL;
      params[i]=(MAPdist::Params*)NULL;
    }

  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (window1), "window1", window1);
  gtk_window_set_title (GTK_WINDOW (window1), "Unsupervized Learning");
  gtk_widget_show(window1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);

  hpaned1 = gtk_hpaned_new ();
  gtk_widget_ref (hpaned1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hpaned1", hpaned1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hpaned1);
  gtk_container_add (GTK_CONTAINER (window1), hpaned1);

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_paned_pack1 (GTK_PANED (hpaned1), vbox1, FALSE, TRUE);



  /* Pixmap */

  frame_pix = gtk_frame_new ((char*)NULL);
  gtk_widget_ref (frame_pix);
  gtk_object_set_data_full (GTK_OBJECT (window1), "frame_pix", frame_pix,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame_pix);
  gtk_box_pack_start (GTK_BOX (vbox1), frame_pix, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame_pix), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame_pix), GTK_SHADOW_NONE);

  colormap = gtk_widget_get_colormap (vbox1);
  gdkpixmap = gdk_pixmap_colormap_create_from_xpm_d (NULL, colormap, &mask,
						     NULL, Supelec_xpm);
  pixmap = gtk_pixmap_new (gdkpixmap, mask);
  gtk_widget_show(pixmap);
  gdk_pixmap_unref (gdkpixmap);
  gdk_bitmap_unref (mask);
  gtk_container_add (GTK_CONTAINER (frame_pix), pixmap);


  /* Execution */

  steps=new MAPdist::Steps("Execution");
  steps->SetDelay(10);
  steps->SetStepCallback(CBStep,NULL);
  steps->SetRestartCallback(CBRestart,NULL);
  gtk_box_pack_start (GTK_BOX (vbox1), steps->GetWidget(), FALSE, FALSE, 0);


  /* Algo */

  algo_frame = gtk_frame_new ("Algorithm");
  gtk_widget_ref (algo_frame);
  gtk_object_set_data_full (GTK_OBJECT (window1), "algo_frame", algo_frame,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (algo_frame);
  gtk_box_pack_start (GTK_BOX (vbox1), algo_frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (algo_frame), 5);

  vbox3 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox3", vbox3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox3);
  gtk_container_add (GTK_CONTAINER (algo_frame), vbox3);
  gtk_container_set_border_width (GTK_CONTAINER (vbox3), 5);

  optionmenu2 = gtk_option_menu_new ();
  gtk_widget_ref (optionmenu2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "optionmenu2", optionmenu2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (optionmenu2);
  gtk_box_pack_start (GTK_BOX (vbox3), optionmenu2, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (optionmenu2), 0);
  optionmenu2_menu = gtk_menu_new ();
  gtk_option_menu_set_menu (GTK_OPTION_MENU (optionmenu2), optionmenu2_menu);

  algo_param=new MAPdist::Params("Display Period");
  step_idf=algo_param->Add("Skipped steps",
			   0,
			   0,500,
			   1,10,
			   0,
			   GTK_SHADOW_NONE);
  gtk_box_pack_start (GTK_BOX (vbox3),algo_param->GetWidget() , TRUE, TRUE, 0);


  /* Distribution */

  distribution_frame = gtk_frame_new ("Distribution");
  gtk_widget_ref (distribution_frame);
  gtk_object_set_data_full (GTK_OBJECT (window1), "distribution_frame", distribution_frame,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (distribution_frame);
  gtk_box_pack_start (GTK_BOX (vbox1), distribution_frame, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (distribution_frame), 5);

  vbox2 = gtk_vbox_new (FALSE, 5);
  gtk_widget_ref (vbox2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox2", vbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox2);
  gtk_container_add (GTK_CONTAINER (distribution_frame), vbox2);
  gtk_container_set_border_width (GTK_CONTAINER (vbox2), 5);

  optionmenu1 = gtk_option_menu_new ();
  gtk_widget_ref (optionmenu1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "optionmenu1", optionmenu1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (optionmenu1);
  gtk_box_pack_start (GTK_BOX (vbox2), optionmenu1, FALSE, FALSE, 0);
  optionmenu1_menu = gtk_menu_new ();
  gtk_option_menu_set_menu (GTK_OPTION_MENU (optionmenu1), optionmenu1_menu);



  // Image name

  hbox3 = gtk_hbox_new (FALSE, 5);
  gtk_widget_show (hbox3);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox3, FALSE, FALSE, 0);

  name_entry = gtk_entry_new ();
  gtk_widget_show (name_entry);
  gtk_box_pack_start (GTK_BOX (hbox3), name_entry, TRUE, TRUE, 0);
  gtk_entry_set_text (GTK_ENTRY (name_entry), "Image name");

  browse = gtk_button_new_with_mnemonic ("...");
  gtk_widget_show (browse);
  gtk_box_pack_start (GTK_BOX (hbox3), browse, FALSE, FALSE, 0);

  g_signal_connect ((gpointer) browse, "clicked",
                    G_CALLBACK (on_browse_clicked),
                    NULL);

  // Options

  hbox2 = gtk_hbox_new (FALSE, 5);
  gtk_widget_ref (hbox2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox2", hbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox2);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox2, FALSE, FALSE, 0);

  checkbutton1 = gtk_check_button_new_with_label ("Points");
  gtk_widget_ref (checkbutton1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "checkbutton1", checkbutton1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton1);
  gtk_box_pack_start (GTK_BOX (hbox2), checkbutton1, FALSE, FALSE, 0);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton1), TRUE);

  checkbutton2 = gtk_check_button_new_with_label ("Axis");
  gtk_widget_ref (checkbutton2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "checkbutton2", checkbutton2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton2);
  gtk_box_pack_start (GTK_BOX (hbox2), checkbutton2, FALSE, FALSE, 0);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton2), TRUE);

  checkbutton3 = gtk_check_button_new_with_label ("Vertices");
  gtk_widget_ref (checkbutton3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "checkbutton3", checkbutton3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (checkbutton3);
  gtk_box_pack_start (GTK_BOX (hbox2), checkbutton3, FALSE, FALSE, 0);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (checkbutton3), TRUE);


  gtk_signal_connect (GTK_OBJECT (checkbutton1), "clicked",
		      GTK_SIGNAL_FUNC (on_check_clicked),
		      (gpointer)NULL);
  gtk_signal_connect (GTK_OBJECT (checkbutton2), "clicked",
		      GTK_SIGNAL_FUNC (on_check_clicked),
		      (gpointer)NULL);
  gtk_signal_connect (GTK_OBJECT (checkbutton3), "clicked",
		      GTK_SIGNAL_FUNC (on_check_clicked),
		      (gpointer)NULL);

  /* Viewer */

  MAPdist::Distrib::SetResolution(.02);
  viewer=new MAPdist::Viewer("View",1  );
  viewer->SetDistrib(GetInitialDistrib());
  gtk_paned_pack2 (GTK_PANED (hpaned1), viewer->GetWidget(), TRUE, TRUE);



  /* Maps */

  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "Maps");
  gtk_widget_show(window1);

  vbox_map = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox_map);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox_map", vbox_map,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox_map);
  gtk_container_add (GTK_CONTAINER (window1), vbox_map);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);


  /* Parameters */

  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window1), "Parameters");
  gtk_widget_show(window1);

  hbox1 = gtk_hbox_new (TRUE, 0);
  gtk_widget_ref (hbox1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox1", hbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox1);
  gtk_container_add (GTK_CONTAINER (window1), hbox1);

  gtk_signal_connect (GTK_OBJECT (window1), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window1), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);


  /* Image file */


  image_selection = gtk_file_selection_new ("Select ppm image");
  gtk_container_set_border_width (GTK_CONTAINER (image_selection), 5);

  ok_button1 = GTK_FILE_SELECTION (image_selection)->ok_button;
  gtk_widget_show (ok_button1);
  GTK_WIDGET_SET_FLAGS (ok_button1, GTK_CAN_DEFAULT);

  cancel_button1 = GTK_FILE_SELECTION (image_selection)->cancel_button;
  gtk_widget_show (cancel_button1);
  GTK_WIDGET_SET_FLAGS (cancel_button1, GTK_CAN_DEFAULT);

  g_signal_connect ((gpointer) ok_button1, "clicked",
                    G_CALLBACK (on_ok_button1_clicked),
                    NULL);
  g_signal_connect ((gpointer) cancel_button1, "clicked",
                    G_CALLBACK (on_cancel_button1_clicked),
                    NULL);


  // Error dialog

  error = gtk_dialog_new ();
  gtk_container_set_border_width (GTK_CONTAINER (error), 5);
  gtk_window_set_title (GTK_WINDOW (error), "Error");
  gtk_window_set_modal (GTK_WINDOW (error), TRUE);
  gtk_window_set_resizable (GTK_WINDOW (error), FALSE);
  gtk_dialog_set_has_separator (GTK_DIALOG (error), FALSE);

  dialog_vbox1 = GTK_DIALOG (error)->vbox;
  gtk_widget_show (dialog_vbox1);

  error_msg = gtk_label_new ("Error");
  gtk_widget_show (error_msg);
  gtk_box_pack_start (GTK_BOX (dialog_vbox1), error_msg, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (error_msg), GTK_JUSTIFY_LEFT);
  gtk_misc_set_padding (GTK_MISC (error_msg), 0, 10);

  dialog_action_area1 = GTK_DIALOG (error)->action_area;
  gtk_widget_show (dialog_action_area1);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (dialog_action_area1), GTK_BUTTONBOX_SPREAD);

  ok_error = gtk_button_new_from_stock ("gtk-ok");
  gtk_widget_show (ok_error);
  gtk_dialog_add_action_widget (GTK_DIALOG (error), ok_error, GTK_RESPONSE_OK);
  GTK_WIDGET_SET_FLAGS (ok_error, GTK_CAN_DEFAULT);

  g_signal_connect ((gpointer) error, "delete_event",
                    G_CALLBACK (on_error_delete_event),
                    NULL);
  g_signal_connect ((gpointer) error, "destroy_event",
                    G_CALLBACK (on_error_destroy_event),
                    NULL);
  g_signal_connect ((gpointer) ok_error, "clicked",
                    G_CALLBACK (on_ok_error_clicked),
                    NULL);


  // Image

  window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window2), "Image");
  gtk_signal_connect (GTK_OBJECT (window2), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window2), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);

  frame1 = gtk_frame_new (NULL);
  gtk_widget_show (frame1);
  gtk_container_add (GTK_CONTAINER (window2), frame1);
  gtk_container_set_border_width (GTK_CONTAINER (frame1), 5);

  frame2 = gtk_frame_new (NULL);
  gtk_widget_show (frame2);
  gtk_container_add (GTK_CONTAINER (frame1), frame2);
  gtk_container_set_border_width (GTK_CONTAINER (frame2), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame2), GTK_SHADOW_IN);

  pic = gtk_drawing_area_new ();
  gtk_widget_show (pic);
  gtk_container_add (GTK_CONTAINER (frame2), pic);
  gtk_widget_set_events (pic, GDK_EXPOSURE_MASK);

  hbox4 = gtk_hbox_new (FALSE, 5);
  gtk_widget_show (hbox4);
  gtk_frame_set_label_widget (GTK_FRAME (frame1), hbox4);

  src = gtk_button_new_with_mnemonic ("Source");
  gtk_widget_show (src);
  gtk_box_pack_start (GTK_BOX (hbox4), src, FALSE, FALSE, 0);

  paint = gtk_button_new_with_mnemonic ("Build from prototypes");
  gtk_widget_show (paint);
  gtk_box_pack_start (GTK_BOX (hbox4), paint, FALSE, FALSE, 0);

  g_signal_connect ((gpointer) pic, "expose_event",
                    G_CALLBACK (on_pic_expose_event),
                    NULL);
  g_signal_connect ((gpointer) paint, "clicked",
                    G_CALLBACK (on_paint_clicked),
                    NULL);
  g_signal_connect ((gpointer) src, "clicked",
                    G_CALLBACK (on_src_clicked),
                    NULL);
  gtk_widget_show(window2);

  // VQP

  window3 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window3), "V.Q.P");
  gtk_signal_connect (GTK_OBJECT (window3), "destroy_event",
                      GTK_SIGNAL_FUNC (on_window1_destroy_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (window3), "delete_event",
                      GTK_SIGNAL_FUNC (on_window1_delete_event),
                      NULL);

  frame3 = gtk_frame_new (NULL);
  gtk_widget_show (frame3);
  gtk_container_add (GTK_CONTAINER (window3), frame3);
  gtk_container_set_border_width (GTK_CONTAINER (frame3), 5);

  frame4 = gtk_frame_new (NULL);
  gtk_widget_show (frame4);
  gtk_container_add (GTK_CONTAINER (frame3), frame4);
  gtk_container_set_border_width (GTK_CONTAINER (frame4), 5);
  gtk_frame_set_shadow_type (GTK_FRAME (frame4), GTK_SHADOW_IN);

  vqp = gtk_drawing_area_new ();
  gtk_widget_show (vqp);
  gtk_container_add (GTK_CONTAINER (frame4), vqp);
  gtk_widget_set_events (vqp, GDK_EXPOSURE_MASK);


  vqp_params=new MAPdist::Params("VQP");
  alpha_vqp_idf=vqp_params->Add("Mexican width",
				  2.75,
				  .1,10,
				  .1,1,
				  2);
  lambda_vqp_idf =vqp_params->Add("Learning rate",
				  .15,
				  0,1,
				  .01,.1,
				  3);

  vqp_button = gtk_button_new_with_mnemonic ("VQP");
  gtk_widget_show (vqp_button);
  gtk_frame_set_label_widget (GTK_FRAME (frame3), vqp_button);

  g_signal_connect ((gpointer) vqp, "expose_event",
                    G_CALLBACK (on_vqp_expose_event),
                    NULL);
  g_signal_connect ((gpointer) vqp_button, "clicked",
                    G_CALLBACK (on_vqp_clicked),
                    NULL);
  gtk_widget_show(window3);


}


gboolean
on_window1_destroy_event               (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

gboolean
on_window1_delete_event                (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  exit(0);
}

void
on_optionmenu1_clicked                 (GtkWidget       *wdgt,
                                        gpointer         user_data)
{
  if(distrib_cb!=NULL)
    (*distrib_cb)((int)((long)user_data));
}

int MustDrawVertices(void)
{
  return gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton3))==TRUE;
}

int MustDrawAxis(void)
{
  return gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton2))==TRUE;
}

int MustDrawPoints(void)
{
  return gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkbutton1))==TRUE;
}


void
on_check_clicked                 (GtkWidget       *wdgt,
				  gpointer         user_data)
{
  viewer->Redisplay();
}

void DeclareAlgo(const char* title,
		 int num,
		 MAPdist::Params* p,MAPdist::Map* m)
{
  if((num>=0)&&(num<NB_ALGO_MAX))
    {
      if(full[num])
	std::cerr << "Error : cannot create algo number " << num << ". Already exists." << std::endl;
      else
	{
	  params[num]=p;
	  maps[num]=m;

	  glade_menuitem = gtk_menu_item_new_with_label (title);
	  gtk_widget_show (glade_menuitem);
	  gtk_menu_append (GTK_MENU (optionmenu2_menu), glade_menuitem);
	  gtk_signal_connect (GTK_OBJECT (glade_menuitem), "activate",
			      GTK_SIGNAL_FUNC (on_optionmenu2_clicked),
			      (gpointer)num);

	  if(m!=NULL)
	    gtk_box_pack_start (GTK_BOX (vbox_map), m->GetWidget(), FALSE, FALSE, 0);
	  if(p!=NULL)
	    gtk_box_pack_start (GTK_BOX (hbox1), p->GetWidget(), FALSE, FALSE, 0);

	  if(current_algo<0)
	    {
	      current_algo=num;
	      gtk_option_menu_set_history(GTK_OPTION_MENU(optionmenu2),num);
	      CBRestart(steps,NULL);
	    }

	  UpdateAlgoVisibility();
	}
    }
  else
    std::cerr << "Error : cannot create algo number " << num << ". Change NB_ALGO_MAX in \"interface.cc\"" << std::endl;
}

int  GetCurrentAlgo(void)
{
  return current_algo;
}

MAPdist::Params*  GetCurrentParams(void)
{
  return params[current_algo];
}

MAPdist::Map*  GetCurrentMap(void)
{
  return maps[current_algo];
}

MAPdist::Distrib* GetCurrentDistrib(void) {
  return viewer-> GetDistrib();
}

void
on_optionmenu2_clicked                 (GtkWidget       *wdgt,
                                        gpointer         user_data)
{
  current_algo=(int)((long)user_data);

  CBRestart(steps,NULL);
  viewer->Redisplay();
  UpdateAlgoVisibility();
  if(maps[current_algo]!=NULL)
    maps[current_algo]->Redisplay();
}

void ChooseRandomPoint(float* x,float* y,float* z)
{
  viewer->ChooseRandomPoint(x,y,z);
}

void SetStepsCallbacks(void (*cbrestart)(void),void (*cbstep)(void))
{
  restart_cb=cbrestart;
  step_cb=cbstep;
}


void UpdateAlgoVisibility(void)
{
  int i;

  for(i=0;i<NB_ALGO_MAX;i++)
    {
      if(i==current_algo)
	{
	  if(params[i]!=NULL)
	    gtk_widget_show(params[i]->GetWidget());
	  if(maps[i]!=NULL)
	    gtk_widget_show(maps[i]->GetWidget());
	}
      else
	{
	  if(params[i]!=NULL)
	    gtk_widget_hide(params[i]->GetWidget());
	  if(maps[i]!=NULL)
	    gtk_widget_hide(maps[i]->GetWidget());
	}
    }
}

void DisplayError(std::string msg)
{
  gtk_label_set_text(GTK_LABEL(error_msg),msg.c_str());
  gtk_widget_show(error);
  gtk_main();
}


gboolean
on_vqp_expose_event                    (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data)
{
  GdkColor color;
  VQP_Dot pt;

  std::list<VQP_Dot>::iterator iter;

  if(vqp->window!=NULL)
    {
      if(vqpgc==NULL)
	vqpgc = gdk_gc_new(vqp->window);

      gdk_window_clear(vqp->window);
      for(iter  = vqp_dots.begin();
	  iter != vqp_dots.end();
	  iter++)
	{
	  pt=*iter;

	  color.red=(guint16)(65535*pt.red);
	  color.green=(guint16)(65535*pt.green);
	  color.blue=(guint16)(65535*pt.blue);
	  gdk_colormap_alloc_color(gdk_colormap_get_system(),
				   &color,
				   FALSE,TRUE);
	  gdk_gc_set_foreground(vqpgc,&color);
	  gdk_draw_arc(vqp->window,vqpgc,
		       TRUE,
		       (int)(pt.x+.5)-3,(int)(pt.y+.5) -3,
		       6,6,
		       0,360*64);
	}

    }

  return FALSE;
}

void *draw_thread(void * arg){

	gtk_widget_queue_draw(vqp);
//sleep (2);
pthread_exit(0);

}

/*************************
	Global Vars
*************************/

float *x, *y, *z;
float *x_vqp, *y_vqp;
float Xij,Yij, G, Fij, alpha, alpha_f,alpha_i,lambda, lambda_i, lambda_f,
	mean_x=0, mean_y=0, var_x=0,var_y=0, P, P0, nb_steps;
VQP_Dot pt;
int rnd;
int n;



gboolean step_vqp(gpointer data){

int i,j;


//printf("2 alpha= %f lambda=%f n=%d \n ",(::alpha),(::lambda),(::n));

rnd = (int)(rand()%(::n));


lambda=lambda_i*(pow((lambda_f/lambda_i),(P/P0)));
alpha=alpha_i*(pow((alpha_f/alpha_i),(P/P0)));
P+=(P0/nb_steps);

	for (int j=0;j<n;j++){
		if(rnd != j){
		Xij=sqrt(pow(*(x+rnd)-*(x+j),2)+pow(*(y+rnd)-*(y+j),2)+pow(*(z+rnd)-*(z+j),2));
		Yij=sqrt(pow(*(x_vqp+rnd)-*(x_vqp+j),2)+pow(*(y_vqp+rnd)-*(y_vqp+j),2));
		if ((lambda-Yij)<0)
			Fij=0;
		else
			Fij=1;
		G=alpha*(Xij-Yij)/Yij*2*Fij;
		*(x_vqp+j)+=G*(*(x_vqp+j)-*(x_vqp+rnd));
		*(y_vqp+j)+=G*(*(y_vqp+j)-*(y_vqp+rnd));
		}


}

for(int k=0;k<n;k++){
(mean_x)+=*(x_vqp+k);
(mean_y)+=*(y_vqp+k);
}


(mean_x)/=n;
(mean_y)/=n;


for(int k=0;k<n;k++){
(var_x)+=pow((*(x_vqp+k)-(mean_x)),2);
(var_y)+=pow((*(y_vqp+k)-(mean_y)),2);
}

(var_x)/=n;
(var_y)/=n;



if ((alpha>alpha_f)&&(lambda>lambda_f))
return TRUE;
else
return FALSE;

}

gboolean draw_vqp(gpointer data){
vqp_dots.clear();
for(int k=0;k<n;k++){
		pt.x =((x_vqp[k]-mean_x)/var_x)*20+250;
		pt.y = ((y_vqp[k]-mean_y)/var_y)*20+250;
		pt.red = x[k];
		pt.green = y[k];
		pt.blue = z[k];
		vqp_dots.push_back(pt);
	}
gtk_widget_queue_draw(vqp);

return TRUE;
}



void
on_vqp_clicked                       (GtkButton       *button,
				      gpointer         user_data)
{

pthread_t th1;
void *ret;
int i;
int  a, b;
Algo* algo;


algo=algos[GetCurrentAlgo()];

algo->StartIter();
n = algo->NbProto();
x= new float[n+1];
y= new float[n+1];
z= new float[n+1];
x_vqp= new float[n+1];
y_vqp= new float[n+1];
nb_steps=250;


for(i=0; i <n;i++){
	algo->Next(x[i], y[i], z[i]);
	//x_vqp[i]=0.5+i*0.01/n;
	//y_vqp[i]=0.5+i*0.1/n;
	x_vqp[i]=(rand()%1000000000)/1000000000.0;
	y_vqp[i]=(rand()%1000000000)/1000000000.0;


}


alpha_i=0.8;
alpha_f=0.01;
alpha=0.8;
lambda=1.5;
lambda_i=30;
lambda_f=1;
P=0.1;
P0=0.7;


// printf("1 alpha= %f lambda=%f n=%d \n ",alpha,lambda,n);

gtk_timeout_add(25,(GtkFunction)step_vqp,0);

gtk_timeout_add(25,(GtkFunction)draw_vqp,0);


}

gboolean
on_pic_expose_event                    (GtkWidget       *widget,
                                        GdkEventExpose  *event,
                                        gpointer         user_data)
{

  if(rgb_buf==NULL)
    gdk_window_clear(pic->window);
  else if(pic->window!=NULL)
    {
      if(picgc==NULL)
	picgc = gdk_gc_new(pic->window);

      gdk_draw_rgb_image (pic->window,
			  picgc,
			  0,0,rgb_width,rgb_height,
			  GDK_RGB_DITHER_NONE,
			  (guchar*)rgb_buf,
			  rgb_width*3);
    }

  return FALSE;
}


void
on_paint_clicked                       (GtkButton       *button,
					gpointer         user_data)
{
  MAPdist::Picture* picdist;
  Algo* algo;
  int w,h,k;

  if( (gtk_option_menu_get_history(GTK_OPTION_MENU(optionmenu1))!=DistPICTURE)
      || (viewer->GetDistrib()==NULL))
    {
      delete [] rgb_buf;
      rgb_buf=(unsigned char*)NULL;
      gtk_widget_queue_draw(pic);
    }
  else
    {
      picdist=(MAPdist::Picture*)(viewer->GetDistrib());
      delete [] rgb_buf;
      rgb_buf=new unsigned char[picdist->width*picdist->height*3];
      rgb_width=picdist->width;
      rgb_height=picdist->height;
      algo=algos[GetCurrentAlgo()];

      for(h=0,k=0;h<rgb_height;h++)
	for(w=0;w<rgb_width;w++,k+=3)
	  {
	    rgb_buf[k]=picdist->img[k];
	    rgb_buf[k+1]=picdist->img[k+1];
	    rgb_buf[k+2]=picdist->img[k+2];
	    algo->BestMatch(rgb_buf+k);
	  }

      gtk_widget_set_size_request(pic,rgb_width,rgb_height);
    }

}

void
on_src_clicked                       (GtkButton       *button,
				      gpointer         user_data)
{
  MAPdist::Picture* picdist;
  int w,h,k;

  if( (gtk_option_menu_get_history(GTK_OPTION_MENU(optionmenu1))!=DistPICTURE)
      || (viewer->GetDistrib()==NULL))
    {
      delete [] rgb_buf;
      rgb_buf=(unsigned char*)NULL;
      gtk_widget_queue_draw(pic);
    }
  else
    {
      picdist=(MAPdist::Picture*)(viewer->GetDistrib());
      delete [] rgb_buf;
      rgb_buf=new unsigned char[picdist->width*picdist->height*3];
      rgb_width=picdist->width;
      rgb_height=picdist->height;

      for(h=0,k=0;h<rgb_height;h++)
	for(w=0;w<rgb_width;w++,k+=3)
	  {
	    rgb_buf[k]=picdist->img[k];
	    rgb_buf[k+1]=picdist->img[k+1];
	    rgb_buf[k+2]=picdist->img[k+2];
	  }

      gtk_widget_set_size_request(pic,rgb_width,rgb_height);
    }

}
