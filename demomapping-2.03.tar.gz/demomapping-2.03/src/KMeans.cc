#include "KMeans.h"
#include "interface.h"
#include <stdlib.h>
#include <math.h>


void KMeans::Winner(void)
{
  float min,d;
  int k;


  /* Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);


  /* Search for winner */
  min=1000;
  for(k=0;k<KMEANS_K;k++)
    if( ( d = pow(mean[k].x-example_x,2)
	  +   pow(mean[k].y-example_y,2)
	  +   pow(mean[k].z-example_z,2) ) 
	< min)
      {
	min=d;
	k_means_winner=k;
      }

  mean[k_means_winner].count++;
}

void KMeans::Update(double alpha)
{
  int j;

  mean[k_means_winner].x += alpha*(example_x - mean[k_means_winner].x);
  mean[k_means_winner].y += alpha*(example_y - mean[k_means_winner].y);
  mean[k_means_winner].z += alpha*(example_z - mean[k_means_winner].z);

  for(j=0;j<KMEANS_K;j++)
    GetCurrentMap()->SetValue(j%5,j/5,
			      mean[j].x,mean[j].y,mean[j].z);
    
}


void KMeans::Declare(int num)
{
  DeclareAlgo("K-Means",
	      num,
	      NULL,
	      new MAPdist::Map("KMeans",
			       KMeansMAP_WIDTH,KMeansMAP_HEIGHT,
			       KMeansCELL_SIZE));
}

void KMeans::DrawLines(MAPdist::Viewer* view)
{
}

void KMeans::DrawNeurons(MAPdist::Viewer* view)
{
  int k;

  view->SetDrawingColor(0,1,0);
  view->DrawPrototype(example_x,example_y,example_z);
  for(k=0;k<KMEANS_K;k++)
    {
      if(k!=k_means_winner)
	view->SetDrawingColor(1,1,1);
      else
	view->SetDrawingColor(1,0,0);
      view->DrawPrototype(mean[k].x,mean[k].y,mean[k].z);
    }
      
}

void KMeans::Restart(void)
{
  int k;
  
  k_means_winner=-1;

  /* Compute random prototype from distribution */
  for(k=0;k<KMEANS_K;k++)
    {
      ChooseRandomPoint(&(mean[k].x),&(mean[k].y),&(mean[k].z));
      mean[k].count=0;
    }
    
  /* Get an example from distribution */
  ChooseRandomPoint(&example_x,&example_y,&example_z);

  int j;
  for(j=0;j<KMEANS_K;j++)
    GetCurrentMap()->SetValue(j%5,j/5,
			      mean[j].x,mean[j].y,mean[j].z);
}

void KMeans::Step(void)
{
  Winner();
  Update(1/mean[k_means_winner].count);
}


int KMeans::NbProto(void)
{
  return KMEANS_K;
}

bool KMeans::HasNext(void)
{
  return iter<KMEANS_K;
}

void KMeans::Next(float& x, float& y, float& z)
{
  x=mean[iter].x;
  y=mean[iter].y;
  z=mean[iter].z;
  iter++;
}


void KMeansConstant::Declare(int num)
{
  MAPdist::Params* params;
  
  params=new MAPdist::Params("K Means (stationnary)");
  param_learning_idf =params->Add("Learning rate",
				  .2,
				  0,1,
				  .01,.1,
				  3);
  
  DeclareAlgo("K-Means (stationary)",
	      num,
	      params,
	      new MAPdist::Map("KMeans",
			       KMeansMAP_WIDTH,KMeansMAP_HEIGHT,
			       KMeansCELL_SIZE));
}


void KMeansConstant::Step(void)
{

  Winner();
  Update(GetCurrentParams()->GetValue(param_learning_idf));
}
