#ifndef GNGT_H
#define GNGT_H

#include <algorithm>
#include <vector>
#include <MAPdist.h>
#include <None.h>
#include <vq2.h>

namespace gngt {

  typedef vq2::algo::gngt::Unit<vq::Point>                  Unit;
  typedef vq2::Graph<Unit,char,Unit::copy_constructor>      Graph;
  typedef Graph::vertex_type                                Vertex;
  typedef Graph::edge_type                                  Edge;
  typedef Graph::ref_vertex_type                            RefVertex;
  typedef vq2::unit::Similarity<Unit,vq::Similarity>        UnitSimilarity;
  typedef vq2::unit::Learn<Unit,vq::Learn>                  UnitLearn;

  class Params {
  public:
    int    _ageMax;
    double _learningRate;
    double _learningRate2;
    double _NT;

    int ageMax(void) {return _ageMax;}
    double learningRate(void) {return _learningRate;}
    double learningRatio(void) {return _learningRate2;}
    double lambda(void) {return .001;}
    
    double target(void) {return _NT;}
    int nbSamples(void) {return 1;} // target returns NT
    double lowPassCoef(void) {return .4;}
    double delta(void) {return .75;}
    double margin() {return .2;}
  }; 


  
  class GNGT : public Algo {
  public:

    int age_idf;
    int learning_idf;
    int learning2_idf;
    int target_idf;
    
    Params params;
    vq::Similarity distance;
    UnitSimilarity unit_distance;
    vq::Learn learn;
    UnitLearn unit_learn;
    vq2::by_default::gngt::Evolution<Params> evolution;
    Graph g;
    std::vector<int> shuffle;

    GNGT(void) 
    : Algo(),
      unit_distance(distance),
      unit_learn(learn),
      evolution(params){
    }
    
    virtual ~GNGT(void) {}
    virtual void Declare(int num) {
      MAPdist::Params* params=new MAPdist::Params("GNG-T");
      learning_idf = params->Add("Main learning rate",
				 .02,
				 0,.2,
				 .001,.01,
				 3);
      learning2_idf = params->Add("Neighbour rate coef",
				  .2,
				  0,1,
				  .01,.1,
				  3);
      age_idf = params->Add("Age max",
			    20,
			    5,100,
			    1,10,
			    0);
      target_idf = params->Add("Target",
			    .5,
			    .001,3,
			    .001,.1,
			    3);

      DeclareAlgo("GNG-T",num,params,(MAPdist::Map*)0);
    }

    class DrawEdge {
    public:
      MAPdist::Viewer* view;
    DrawEdge(MAPdist::Viewer* v) : view(v) {}

      bool operator()(Edge& e) { 
	vq::Point& p1 = (*(e.n1)).value.prototype();
	vq::Point& p2 = (*(e.n2)).value.prototype();
	view->DrawLine(p1.x,p1.y,p1.z,
		       p2.x,p2.y,p2.z);
	return false;
      }
    };

    virtual void DrawLines(MAPdist::Viewer* view) {
      DrawEdge draw(view);
      view->SetDrawingColor(0,0,1);
      g.for_each_edge(draw);
    }

    class DrawVertex {
    public:
      MAPdist::Viewer* view;
    DrawVertex(MAPdist::Viewer* v) : view(v) {}

      bool operator()(Vertex& n) { 
	vq::Point& p = n.value.prototype();
	view->DrawPrototype(p.x,p.y,p.z);
	return false;
      }
    };

    
    std::vector<vq::Point> vertices;
    std::vector<vq::Point>::iterator vertex_it;

    class RegisterVertex {
    public:
      
      std::vector<vq::Point>& vertices;
      RegisterVertex(std::vector<vq::Point>& vertices) : vertices(vertices) {
	vertices.clear();
      }

      bool operator()(Vertex& n) { 
	vertices.push_back(n.value.prototype());
	return false;
      }
    };

    
    virtual void StartIter(void) {
      RegisterVertex rv(vertices);
      g.for_each_vertex(rv);
      vertex_it = vertices.begin();
    }
    
    virtual bool HasNext(void) {
      return vertex_it != vertices.end();
    }
    
    virtual void Next(float& x, float& y, float& z) {
      auto& p = *(vertex_it++);
      x = p.x;
      y = p.y;
      z = p.z;
    }

    virtual void DrawNeurons(MAPdist::Viewer* view) {
      DrawVertex draw(view);
      view->SetDrawingColor(1,1,1);
      g.for_each_vertex(draw);
    }

    
    virtual void Restart(void) {
      g.clear();
    }

    
    virtual void Step(void) {
      params._ageMax = GetCurrentParams()->GetValue(age_idf);
      params._learningRate = GetCurrentParams()->GetValue(learning_idf);
      params._learningRate2 = GetCurrentParams()->GetValue(learning2_idf);
      params._NT = GetCurrentParams()->GetValue(target_idf);

      MAPdist::Distrib* distrib = GetCurrentDistrib();
      if(distrib != 0) {
	int size = distrib->GetNbPoints();
	if(shuffle.size() != (std::vector<int>::size_type)size) {
	  shuffle.resize(size);
	  for(int i=0;i<size;++i)
	    shuffle[i] = i;
	}
	std::random_shuffle(shuffle.begin(),shuffle.end());
	vq2::algo::gngt::open_epoch(g,evolution);
	float x,y,z;
	for(int i=0; i<size;++i) {
	  distrib->GetPoint(shuffle[i],&x,&y,&z);
	  vq2::algo::gngt::submit(params,g,unit_distance,unit_learn,vq::Point(x,y,z),true);
	}
	vq2::algo::gngt::close_epoch(params,g,unit_learn,evolution,true);
      
      }
    }
    
  };
}

#endif
