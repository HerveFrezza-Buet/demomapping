#include <MAPdist.h>
#include "interface.h"
#include "distrib.h"
#include <iostream>

#include "None.h"
#include "KMeans.h"
#include "SOM.h"
#include "CHLearning.h"
#include "GrowingNeuralGas.h"
#include "GrowingGrid.h"
#include "GNGT.h"

#define NONE                   0
#define K_MEANS_CONSTANT       1
#define K_MEANS                2
#define KOHONEN_GRID           3
#define KOHONEN_LINE           4
#define KOHONEN_RING           5
#define KOHONEN_TORUS          6
#define CH_LEARNING            7
#define GROWING_NEURAL_GAS     8
#define GROWING_GRID           9
#define GNG_T                 10
#define NB_ALGOS              11

Algo** algos;




void Draw(MAPdist::Viewer* view,gpointer data)
{
  if(MustDrawAxis())
    view->DrawAxis();
  if(MustDrawPoints())
    view->DrawDistrib();

  algos[GetCurrentAlgo()]->DrawLines(view);
  if(MustDrawVertices())
    algos[GetCurrentAlgo()]->DrawNeurons(view);
}

void Step(void)
{
  algos[GetCurrentAlgo()]->Step();
}

void Restart(void)
{
  algos[GetCurrentAlgo()]->Restart();
}

int main (int argc, char *argv[])
{
  /* gtk usual initializations */
  gtk_set_locale ();
  gtk_init (&argc, &argv);
  vq2::proba::random::init();
  int alg;
  
  algos = new Algo*[NB_ALGOS];
  algos[NONE                   ] = new Algo(); 
  algos[K_MEANS_CONSTANT       ] = new KMeansConstant();
  algos[K_MEANS                ] = new KMeans();
  algos[KOHONEN_GRID           ] = new som::Kohonen(somKOHONEN_GRID);
  algos[KOHONEN_LINE           ] = new som::Kohonen(somKOHONEN_LINE);
  algos[KOHONEN_RING           ] = new som::Kohonen(somKOHONEN_RING);
  algos[KOHONEN_TORUS          ] = new som::Kohonen(somKOHONEN_TORUS);
  algos[CH_LEARNING            ] = new CHLearning();
  algos[GROWING_NEURAL_GAS     ] = new GrowingNeuralGas();
  algos[GROWING_GRID           ] = new GrowingGrid();
  algos[GNG_T                  ] = new gngt::GNGT();

  MakeInterface();
  DeclareDistribs();
  SetDrawingCallback(Draw); 
  SetStepsCallbacks(Restart,Step);

  for(alg=0;alg<NB_ALGOS;alg++)
    algos[alg]->Declare(alg);

  gtk_main ();


  return 0;
}
