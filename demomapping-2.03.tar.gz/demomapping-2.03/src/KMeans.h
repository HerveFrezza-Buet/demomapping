#ifndef KMEANS_H
#define KMEANS_H

#include <MAPdist.h>
#include <None.h>

class KMeans : public Algo
{
 public: 
  KMeans(void) {}

  virtual void Declare(int num);
  virtual void DrawLines(MAPdist::Viewer* view);
  virtual void DrawNeurons(MAPdist::Viewer* view);
  virtual void Restart(void);
  virtual void Step(void);
  
  virtual int NbProto(void);
  virtual bool HasNext(void);
  virtual void Next(float& x, float& y, float& z);

  void Winner(void);
  void Update(double alpha);

#define KMEANS_K 20
#define KMeansMAP_WIDTH  5
#define KMeansMAP_HEIGHT 4
#define KMeansCELL_SIZE  20

  float example_x,example_y,example_z;
  
  struct {
    float x,y,z;
    float count;
  } mean[KMEANS_K];
  
  int k_means_winner;
  int param_learning_idf;
  
};

class KMeansConstant: public KMeans
{
 public: 
  KMeansConstant(void) {}

  virtual void Declare(int num);
  virtual void Step(void);
};
#endif
