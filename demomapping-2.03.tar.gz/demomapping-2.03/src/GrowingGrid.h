#ifndef GROWINGGRID_H
#define GROWINGGRID_H

#include <MAPdist.h>
#include <None.h>

class GrowingGrid : public Algo
{
 public:
  GrowingGrid(void) {};
  virtual void Declare(int num);
  virtual void DrawLines(MAPdist::Viewer* view);
  virtual void DrawNeurons(MAPdist::Viewer* view);
  virtual void Restart(void);
  virtual void Step(void);

  virtual int NbProto(void);
  virtual bool HasNext(void);
  virtual void Next(float& x, float& y, float& z);

  
  void ComputeMap(void);
  int InsertColumnAfter(int i);
  int InsertRowAfter(int i);

#define GrowingGridMAP_SIZE 500
#define GrowingGridCELL_SIZE  20
  
  int map_width;
  int map_height;
  int param_lambda_idf;
  int param_epsilon_idf;
  int param_sigma_idf;
  int t;
  float example_x,example_y,example_z;
  float x[GrowingGridMAP_SIZE];
  float y[GrowingGridMAP_SIZE];
  float z[GrowingGridMAP_SIZE];
  int tau[GrowingGridMAP_SIZE];

};

#endif
