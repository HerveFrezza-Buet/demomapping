var searchData=
[
  ['scale',['Scale',['../a00085.html',1,'vq2::proba']]],
  ['set',['Set',['../a00054.html',1,'vq2::concept']]],
  ['similarity',['Similarity',['../a00055.html',1,'vq2::concept']]],
  ['similarity',['Similarity',['../a00100.html',1,'vq2::unit']]],
  ['sort',['Sort',['../a00069.html',1,'vq2::functor']]],
  ['speeds',['Speeds',['../a00095.html',1,'vq2::temporal::xfig::functor']]],
  ['split',['Split',['../a00056.html',1,'vq2::concept']]]
];
