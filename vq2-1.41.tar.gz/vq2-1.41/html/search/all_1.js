var searchData=
[
  ['b',['b',['../a00082.html#adaca8938827a3014c4fb6bfd65f56ebf',1,'vq2::proba::Min::b()'],['../a00081.html#a7d4629eb480bae37cc0bb7e6cfcced8a',1,'vq2::proba::Max::b()']]],
  ['backward_5farrow',['backward_arrow',['../a00102.html#a09c7e8ea55ba05229e7969569da76311',1,'vq2::xfig::GC']]],
  ['base',['Base',['../a00097.html#ac3829e47ba4e9f0bafd9b2de1c5f489f',1,'vq2::unit::Base::Base(void)'],['../a00097.html#adc4c0150b1802de5d9b9710691744367',1,'vq2::unit::Base::Base(const Base &amp;copy)'],['../a00097.html#aa37a87ae14c9d70882c987123e6bcfb1',1,'vq2::unit::Base::Base(const prototype_type &amp;proto)']]],
  ['base',['Base',['../a00097.html',1,'vq2::unit']]],
  ['begin',['begin',['../a00067.html#a7a2f8498f058c98b23abb565eec2e280',1,'vq2::functor::LBGInit::begin()'],['../a00051.html#adb32ae251707d7abe583df0d3541cc17',1,'vq2::concept::GNGTSampling::begin()']]]
];
