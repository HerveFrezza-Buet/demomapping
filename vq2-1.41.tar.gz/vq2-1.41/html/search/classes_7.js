var searchData=
[
  ['iteration',['Iteration',['../a00052.html',1,'vq2::concept']]]
];
