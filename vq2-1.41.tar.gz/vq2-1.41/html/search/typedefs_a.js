var searchData=
[
  ['sample_5ftype',['sample_type',['../a00055.html#a2a98162cdc4b08e87909d803a9c1df60',1,'vq2::concept::Similarity::sample_type()'],['../a00053.html#a20dbe75a178ce160ac4ac9dc8b75025e',1,'vq2::concept::Learn::sample_type()'],['../a00100.html#ad8be6e26193a7fa168960216d73dc2a5',1,'vq2::unit::Similarity::sample_type()'],['../a00099.html#a742d51058e6f91947337175ab1f7b92a',1,'vq2::unit::Learn::sample_type()']]],
  ['status',['Status',['../a00132.html#afcccd55673f2e04ec4a78f9a6ba747b4',1,'vq2::temporal']]],
  ['super_5ftype',['super_type',['../a00092.html#a2f3511ee2a1c0c17d8dc03b0c8264e0f',1,'vq2::temporal::Unit::super_type()'],['../a00094.html#a4ee83b4bc193152426bcb85b79df7269',1,'vq2::temporal::xfig::functor::FigVertex::super_type()']]]
];
