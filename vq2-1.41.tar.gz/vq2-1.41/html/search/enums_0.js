var searchData=
[
  ['mode',['Mode',['../a00102.html#af1dab049e132403ddd41ee25a57f6f31',1,'vq2::xfig::GC']]]
];
