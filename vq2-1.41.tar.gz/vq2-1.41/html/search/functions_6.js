var searchData=
[
  ['gc',['GC',['../a00102.html#af3e85d920cdf4e819a1e492807d521a3',1,'vq2::xfig::GC']]],
  ['get',['get',['../a00090.html#aae18edd1e51df9ff29081dd27bf00d16',1,'vq2::temporal::NeighborsMeanSpeed']]],
  ['getstatus',['getStatus',['../a00092.html#a6a45548dbd52f3829824114cf23ad323',1,'vq2::temporal::Unit']]],
  ['gettime',['getTime',['../a00096.html#a21ce7ad045c7848b56302c146d6a0208',1,'vq2::Time']]],
  ['graph',['Graph',['../a00073.html#a223a062d37debae65fa30b3df4b480ed',1,'vq2::Graph::Graph()'],['../a00136.html#a1681a1b464cedba34efdadae4e1aa59b',1,'vq2::xfig::graph()'],['../a00133.html#a51212ba99ede37eb75e64001e95d7f45',1,'vq2::temporal::xfig::graph()']]],
  ['graphsimilarityfunctor',['GraphSimilarityFunctor',['../a00066.html#ab4e0458a87191ec7f4f442f208b23776',1,'vq2::functor::GraphSimilarityFunctor']]],
  ['graphstuff',['GraphStuff',['../a00077.html#a7543ef0804ef6aca247d6e84916504d3',1,'vq2::GraphStuff::GraphStuff(void)'],['../a00077.html#a61e412b830b47f025dc5ae08a6112a99',1,'vq2::GraphStuff::GraphStuff(const GraphStuff &amp;copy)']]],
  ['grid',['grid',['../a00125.html#a674e667fac9b54f04f13259d7691fe7e',1,'vq2::algo::make']]]
];
