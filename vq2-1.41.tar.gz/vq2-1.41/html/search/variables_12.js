var searchData=
[
  ['xi',['xi',['../a00068.html#a3554581bc3c6fa366cfb0e362d5c1be3',1,'vq2::functor::Learn::xi()'],['../a00038.html#a80f4b2ef9a06c3d058f0b7343e2253d4',1,'vq2::algo::gngt::internal::UpdateNeighbour::xi()']]]
];
