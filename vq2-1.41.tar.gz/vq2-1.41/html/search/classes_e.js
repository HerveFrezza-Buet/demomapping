var searchData=
[
  ['unefficientedge',['UnefficientEdge',['../a00072.html',1,'vq2::functor']]],
  ['uniform',['Uniform',['../a00087.html',1,'vq2::proba']]],
  ['unit',['Unit',['../a00092.html',1,'vq2::temporal']]],
  ['unit',['Unit',['../a00057.html',1,'vq2::concept']]],
  ['unit',['Unit',['../a00041.html',1,'vq2::algo::kmeans']]],
  ['unit',['Unit',['../a00043.html',1,'vq2::algo::som']]],
  ['unit',['Unit',['../a00039.html',1,'vq2::algo::gngt']]],
  ['updateage',['UpdateAge',['../a00037.html',1,'vq2::algo::gngt::internal']]],
  ['updateneighbour',['UpdateNeighbour',['../a00038.html',1,'vq2::algo::gngt::internal']]]
];
