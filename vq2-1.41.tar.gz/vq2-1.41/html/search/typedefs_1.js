var searchData=
[
  ['chunk_5ftype',['chunk_type',['../a00033.html#a868acc61c2df448e33aaa3ec2c6f175a',1,'vq2::Ref']]]
];
