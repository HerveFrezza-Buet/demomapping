var searchData=
[
  ['v',['v',['../a00063.html#a5c9318146e67e7cf081a44aff037f5a9',1,'vq2::functor::ClosestFunctor::v()'],['../a00071.html#aa8f93307e927c64200e2d9910fab082e',1,'vq2::functor::TwoClosestFunctor::v()']]],
  ['value',['value',['../a00076.html#a8dcf9d5d874fca35b329796fc394c2b9',1,'vq2::Graph::Vertex::value()'],['../a00075.html#ad77941bbd20660438b6b390b178024fb',1,'vq2::Graph::Edge::value()']]],
  ['vr',['vr',['../a00065.html#a2d88eacb6a04a6d3e3cd69dbc6f65ba5',1,'vq2::functor::FigVertex']]]
];
