var searchData=
[
  ['g',['g',['../a00066.html#a883ac6ebb12ca6204b3d78b99287bb32',1,'vq2::functor::GraphSimilarityFunctor']]],
  ['gc',['gc',['../a00065.html#aa47f24fc09eb44a15247f7c18afac0cc',1,'vq2::functor::FigVertex']]]
];
