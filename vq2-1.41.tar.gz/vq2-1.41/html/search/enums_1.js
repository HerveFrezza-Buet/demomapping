var searchData=
[
  ['status',['Status',['../a00132.html#adb65570da64bd45c79060dc388a17811',1,'vq2::temporal']]]
];
