var searchData=
[
  ['delta',['delta',['../a00048.html#a417b50708f586660c7552a58f32e0bd1',1,'vq2::concept::EvolutionParams']]],
  ['displaymemory',['displayMemory',['../a00073.html#a5590fb15fe1484838f82c4dc75a2924e',1,'vq2::Graph']]],
  ['distance',['distance',['../a00120.html#a553dbe0f0e9b2ae9f3f2d334f9fdc88d',1,'vq2::algo']]],
  ['distortion',['distortion',['../a00120.html#ac241d7547e2a502dcdb8043d76128920',1,'vq2::algo']]],
  ['div',['div',['../a00046.html#a06630d7cfbdef763411827664cfa63d5',1,'vq2::by_default::VectorOp::div()'],['../a00058.html#ada7d223c0b2aceedf782425e9821e238',1,'vq2::concept::VectorOp::div()']]]
];
