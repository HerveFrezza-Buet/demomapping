var searchData=
[
  ['label',['label',['../a00077.html#a5ba3fcf37b6ad29e1883c933180a2c1c',1,'vq2::GraphStuff']]],
  ['learn',['learn',['../a00068.html#a7bd3be7a866332b450b4ffd579d27c9d',1,'vq2::functor::Learn::learn()'],['../a00038.html#a3d8bff1171997d363557797e2f0b08f7',1,'vq2::algo::gngt::internal::UpdateNeighbour::learn()']]],
  ['line_5fstyle',['line_style',['../a00102.html#a436c757d7a9a0e90649b8291663464c6',1,'vq2::xfig::GC']]],
  ['lr',['lr',['../a00038.html#a9ceae4d0c7e248b0256d56663f81d96a',1,'vq2::algo::gngt::internal::UpdateNeighbour']]]
];
