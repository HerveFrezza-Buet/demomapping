var searchData=
[
  ['join_5fstyle',['join_style',['../a00102.html#a6c852ce1acb623960e9f1b096a487b08',1,'vq2::xfig::GC']]]
];
