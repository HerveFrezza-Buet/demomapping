var searchData=
[
  ['point',['point',['../a00136.html#aabd6fe96c7db763a59dc1b766458c317',1,'vq2::xfig']]],
  ['process',['process',['../a00124.html#a1f7f3d71ff35c0ccccc58626be42da4f',1,'vq2::algo::kmeans']]],
  ['prototype',['prototype',['../a00057.html#aa34b8dfcd42b99a38ee5d17fb701cd4f',1,'vq2::concept::Unit::prototype()'],['../a00097.html#ab9f829a17fa9b9d5ad74901469399bbf',1,'vq2::unit::Base::prototype(void)'],['../a00097.html#ae606e9d1e43e46dcfece45ac45be6c37',1,'vq2::unit::Base::prototype(void) const ']]]
];
