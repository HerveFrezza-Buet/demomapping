var searchData=
[
  ['radius',['radius',['../a00102.html#a7bb5030f14f3a9cafc332b6b9309414a',1,'vq2::xfig::GC']]],
  ['ref',['ref',['../a00047.html#a842bd765a1146070cab874e33d9facb0',1,'vq2::Chunk']]]
];
