var searchData=
[
  ['data_5ftype',['data_type',['../a00047.html#a01e92042c67b6ad55c6b9de264850831',1,'vq2::Chunk::data_type()'],['../a00030.html#aadc34e56396efe1cfc7318d202132f17',1,'vq2::Free::data_type()'],['../a00033.html#aa6fdcc910f4b011678e86e81a58192cb',1,'vq2::Ref::data_type()'],['../a00031.html#a5176967159be1b72c8308f2df59ec2fb',1,'vq2::Heap::data_type()'],['../a00032.html#a67c280765cdec44d03867f4ce2301cd6',1,'vq2::List::data_type()'],['../a00079.html#a312ad56967642b5c769a748197bbf71a',1,'vq2::List::Link::data_type()'],['../a00052.html#aab96f96fd4eec1a04e6e39f3a4df39ff',1,'vq2::concept::Iteration::data_type()']]]
];
