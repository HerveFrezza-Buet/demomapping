var searchData=
[
  ['onalloc',['onAlloc',['../a00031.html#a1f7f9a13dadf00d448c7750b8efd74f5',1,'vq2::Heap']]],
  ['onfree',['onFree',['../a00047.html#a2533245873ad9c8cac5965d998cb95cb',1,'vq2::Chunk::onFree()'],['../a00031.html#a0f87794a1b96e33e5f6a3faeba054cec',1,'vq2::Heap::onFree()']]],
  ['op',['op',['../a00085.html#a93966dbbc20e2bd7c057f8bb221fa9d8',1,'vq2::proba::Scale::op()'],['../a00086.html#ab90235aeda06a449cab357af620ebc07',1,'vq2::proba::Translate::op()']]]
];
