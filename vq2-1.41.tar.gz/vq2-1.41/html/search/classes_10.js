var searchData=
[
  ['wtm',['WTM',['../a00059.html',1,'vq2::concept']]]
];
