var searchData=
[
  ['sim',['sim',['../a00066.html#a6043137cae09b0ef99cc8074fa099edf',1,'vq2::functor::GraphSimilarityFunctor::sim()'],['../a00063.html#a4a061f490ddc48f5140724cdcb7b35c0',1,'vq2::functor::ClosestFunctor::sim()'],['../a00071.html#ae03c76913d41058f5e13a233a59ceb86',1,'vq2::functor::TwoClosestFunctor::sim()']]],
  ['size',['size',['../a00067.html#a8a7724485d4ba6175b9b34dba603b349',1,'vq2::functor::LBGInit']]],
  ['stats',['stats',['../a00036.html#a7cd7855c8c7597610117fe492374ce09',1,'vq2::algo::gngt::internal::MakeNeuronStat']]],
  ['stuff',['stuff',['../a00076.html#a46dbfa60ba212cc32e1a6ff7e0fb1433',1,'vq2::Graph::Vertex::stuff()'],['../a00075.html#a2feb6f8be3aeca14104833686d184026',1,'vq2::Graph::Edge::stuff()']]],
  ['style_5fval',['style_val',['../a00102.html#a763cc72494ab169c0a2852bc59c2e177',1,'vq2::xfig::GC']]]
];
