var searchData=
[
  ['unefficientedge',['UnefficientEdge',['../a00072.html',1,'vq2::functor']]],
  ['uniform',['Uniform',['../a00087.html',1,'vq2::proba']]],
  ['uniform',['Uniform',['../a00087.html#a30be26db35e8b41a7a26c2d9e5ced773',1,'vq2::proba::Uniform::Uniform()'],['../a00084.html#ac0931246535889658d507a1054ab1065',1,'vq2::proba::random::uniform(double min, double max)'],['../a00084.html#af91f2679f667178e1efc58f2b7a4d792',1,'vq2::proba::random::uniform(void)'],['../a00131.html#a383a1bdbf66b363eace653139e5f9e4c',1,'vq2::proba::uniform()']]],
  ['unit',['Unit',['../a00041.html',1,'vq2::algo::kmeans']]],
  ['unit',['Unit',['../a00039.html#ae5773523e4182e82aa0243114bd73315',1,'vq2::algo::gngt::Unit::Unit(void)'],['../a00039.html#a0895f7cab45c5563a3e3e0f3fe7dca52',1,'vq2::algo::gngt::Unit::Unit(const Unit&lt; PROTOTYPE &gt; &amp;copy)'],['../a00039.html#adf1be7241874214851f89075ca7000b5',1,'vq2::algo::gngt::Unit::Unit(const prototype_type &amp;proto)'],['../a00041.html#a575a7815df2b3e07055342efe6de6885',1,'vq2::algo::kmeans::Unit::Unit(void)'],['../a00041.html#abd5194fd3c7820420ea3958bd6b08581',1,'vq2::algo::kmeans::Unit::Unit(const Unit&lt; PROTOTYPE &gt; &amp;copy)'],['../a00041.html#a2aba380829713975254c6e80f622a0cf',1,'vq2::algo::kmeans::Unit::Unit(const prototype_type &amp;proto)'],['../a00043.html#aa70fcf88299e07895f89fe359c414f30',1,'vq2::algo::som::Unit::Unit(void)'],['../a00043.html#a1c5ed6940a5337388527428881344ab4',1,'vq2::algo::som::Unit::Unit(const Unit&lt; PROTOTYPE &gt; &amp;copy)'],['../a00043.html#a1efb2410e54a0a561e628a4a772ca7e5',1,'vq2::algo::som::Unit::Unit(const prototype_type &amp;proto)'],['../a00092.html#aa56bf9c78c181bcd8ff443cea1a177a7',1,'vq2::temporal::Unit::Unit(void)'],['../a00092.html#ac74850f94a8ebf84b08a2e816a1dad67',1,'vq2::temporal::Unit::Unit(const Unit&lt; UNIT &gt; &amp;copy)'],['../a00092.html#ad4441abf7f2f4b4b2734ca4d2ba43e94',1,'vq2::temporal::Unit::Unit(const prototype_type &amp;proto)']]],
  ['unit',['Unit',['../a00092.html',1,'vq2::temporal']]],
  ['unit',['Unit',['../a00043.html',1,'vq2::algo::som']]],
  ['unit',['Unit',['../a00039.html',1,'vq2::algo::gngt']]],
  ['unit',['Unit',['../a00057.html',1,'vq2::concept']]],
  ['unit_5fof',['unit_of',['../a00124.html#aab7415646fd747b821f83b707e687522',1,'vq2::algo::kmeans']]],
  ['updateage',['UpdateAge',['../a00037.html#af504e72c47141e6b4beb3e11d7d3083c',1,'vq2::algo::gngt::internal::UpdateAge']]],
  ['updateage',['UpdateAge',['../a00037.html',1,'vq2::algo::gngt::internal']]],
  ['updateneighbour',['UpdateNeighbour',['../a00038.html',1,'vq2::algo::gngt::internal']]],
  ['updateneighbour',['UpdateNeighbour',['../a00038.html#ac84103dca40bc5e2fbec5d82818c4f03',1,'vq2::algo::gngt::internal::UpdateNeighbour']]]
];
