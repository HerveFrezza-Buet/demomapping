var searchData=
[
  ['chunk_5fsize',['chunk_size',['../a00031.html#a00f46b1f560a4455778a4abb441efd1ea57a0234e7b2b11d7f1e86ee0a0163949',1,'vq2::Heap']]]
];
