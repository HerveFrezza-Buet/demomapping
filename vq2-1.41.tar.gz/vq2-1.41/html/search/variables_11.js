var searchData=
[
  ['w',['w',['../a00097.html#aba0afaaaf20f7586eef388e8cd5d935c',1,'vq2::unit::Base']]],
  ['wtm',['wtm',['../a00068.html#a599276ce337fca0dd39aa6520c0102e8',1,'vq2::functor::Learn']]]
];
