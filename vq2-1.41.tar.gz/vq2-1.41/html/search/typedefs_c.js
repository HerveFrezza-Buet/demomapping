var searchData=
[
  ['weight_5ftype',['weight_type',['../a00053.html#a46afbd95a2cbe934e156682371e7d9eb',1,'vq2::concept::Learn::weight_type()'],['../a00099.html#a60d935b46e792eddfb28ddb9420fcc33',1,'vq2::unit::Learn::weight_type()']]]
];
