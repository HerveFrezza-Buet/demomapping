var searchData=
[
  ['xfigconverter',['XfigConverter',['../a00060.html',1,'vq2::concept']]],
  ['xfigconverter',['XfigConverter',['../a00101.html',1,'vq2::unit']]],
  ['xfigconverter',['XfigConverter',['../a00101.html#a96af95653f6c99cc994855481784ceb0',1,'vq2::unit::XfigConverter']]],
  ['xi',['xi',['../a00068.html#a3554581bc3c6fa366cfb0e362d5c1be3',1,'vq2::functor::Learn::xi()'],['../a00038.html#a80f4b2ef9a06c3d058f0b7343e2253d4',1,'vq2::algo::gngt::internal::UpdateNeighbour::xi()']]]
];
