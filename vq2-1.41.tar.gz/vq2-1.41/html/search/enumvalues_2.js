var searchData=
[
  ['statusnew',['statusNew',['../a00132.html#adb65570da64bd45c79060dc388a17811a280c61c0c774718cc37b785c7bbbf7f6',1,'vq2::temporal']]],
  ['statusnopreviousproto',['statusNoPreviousProto',['../a00132.html#adb65570da64bd45c79060dc388a17811af95a9e5f1772c8f90faa5c950cc41b90',1,'vq2::temporal']]],
  ['statusok',['statusOk',['../a00132.html#adb65570da64bd45c79060dc388a17811ac382c74e168fd75ed594a5bf20f068b0',1,'vq2::temporal']]]
];
