var searchData=
[
  ['position_5ftype',['position_type',['../a00060.html#a0ebb6136321a0e7ac2336d3c491cfc5a',1,'vq2::concept::XfigConverter::position_type()'],['../a00101.html#a96e1735addcd29c424aa969b974ef1d8',1,'vq2::unit::XfigConverter::position_type()']]],
  ['prototype_5ftype',['prototype_type',['../a00057.html#aa8580445e826a538c4298f5e17a7ae15',1,'vq2::concept::Unit::prototype_type()'],['../a00039.html#a055e2bb92ca50c386083a6d21fc60797',1,'vq2::algo::gngt::Unit::prototype_type()'],['../a00041.html#ac6953a99b9450124cc1d67094a590be6',1,'vq2::algo::kmeans::Unit::prototype_type()'],['../a00043.html#a4ee38af7e89bf51ff2e2cf115d64c368',1,'vq2::algo::som::Unit::prototype_type()'],['../a00092.html#a1c47fc672ea6aa917d4e5310e277458e',1,'vq2::temporal::Unit::prototype_type()'],['../a00097.html#ad406dbf083cef87d3a682d8c30dd0b9b',1,'vq2::unit::Base::prototype_type()']]]
];
