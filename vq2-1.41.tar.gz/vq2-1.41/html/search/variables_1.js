var searchData=
[
  ['b',['b',['../a00082.html#adaca8938827a3014c4fb6bfd65f56ebf',1,'vq2::proba::Min::b()'],['../a00081.html#a7d4629eb480bae37cc0bb7e6cfcced8a',1,'vq2::proba::Max::b()']]],
  ['backward_5farrow',['backward_arrow',['../a00102.html#a09c7e8ea55ba05229e7969569da76311',1,'vq2::xfig::GC']]],
  ['begin',['begin',['../a00067.html#a7a2f8498f058c98b23abb565eec2e280',1,'vq2::functor::LBGInit']]]
];
