var searchData=
[
  ['scale',['Scale',['../a00085.html#a5a09c9c3fc03e6191134c3527867e2d5',1,'vq2::proba::Scale::Scale()'],['../a00131.html#aed14be5dbff53464f50edb6b195865b8',1,'vq2::proba::scale()']]],
  ['shortest_5fconfidence_5finterval',['shortest_confidence_interval',['../a00131.html#ac51adddd537a0129ccbed0f739c8dd07',1,'vq2::proba']]],
  ['similarity',['Similarity',['../a00100.html#a63f806d79807037545f1ab95a51f09a1',1,'vq2::unit::Similarity::Similarity()'],['../a00120.html#aebbdc77547fc59b30ebb4bf387656ba6',1,'vq2::algo::similarity()']]],
  ['sort',['Sort',['../a00069.html#ad6cd773b03e9bc2ef6ca1ef79055e706',1,'vq2::functor::Sort::Sort()'],['../a00130.html#acd0afa463d052a19b9a3ff2dfde9beb3',1,'vq2::functor::sort()']]],
  ['speed',['speed',['../a00092.html#a8a673bb3b214c40e796de1bfc5b5bc53',1,'vq2::temporal::Unit']]],
  ['speeds',['Speeds',['../a00095.html#ab50645e84f6491cf7aef3f832bf6c781',1,'vq2::temporal::xfig::functor::Speeds::Speeds()'],['../a00133.html#a84dfe90960c1a4f37f18cc64c7c4133e',1,'vq2::temporal::xfig::speeds()']]],
  ['start',['start',['../a00096.html#a7e273de4cbec99779667d64ec374ea8e',1,'vq2::Time']]],
  ['step',['step',['../a00126.html#aef6be1740529e8c279c04d5725cb8202',1,'vq2::algo::som']]],
  ['stop',['stop',['../a00096.html#adf401a33cbfd195ab2d42cf661cf05d2',1,'vq2::Time']]],
  ['submit',['submit',['../a00121.html#ac9d97275c2d4c67c169582056f09fd02',1,'vq2::algo::gngt']]]
];
