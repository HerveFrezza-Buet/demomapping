#ifndef glop_MATERIAL
#define glop_MATERIAL

#include <GL/gl.h>

namespace glop {

  /**
   * @short This class defines object material.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Material {

  private :

    GLfloat front_color[4];
    GLfloat back_color[4];
    GLfloat front_specular[4];
    GLfloat back_specular[4];
    int front_shininess;
    int back_shininess;
    bool two_side;

  public:

    Material(void);
    virtual ~Material(void);

    /**
     * Sets front and back color.
     */
    void Color(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha=1);

    /**
     * Sets back color.
     */
    void BackColor(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha=1);

    /**
     * Sets specular front and back color.
     */
    void Specular(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha=1);

    /**
     * Sets specular back color.
     */
    void BackSpecular(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha=1);

    /**
     * Sets front and back shininess. 0 is wide, 1 is sharp.
     */
    void Shininess(GLfloat shininess);

    /**
     * Sets back shininess. 0 is wide, 1 is sharp.
     */
    void BackShininess(GLfloat shininess);

    /**
     * Start applying material
     */
    void BeginMaterial(void);

    /**
     * End applying material
     */
    void EndMaterial(void);

    /**
     * Sets two sided light model (default)
     */
    void TwoSide(void);

    /**
     * Sets one sided light model (default)
     */
    void OneSide(void);
  };
}

#endif
