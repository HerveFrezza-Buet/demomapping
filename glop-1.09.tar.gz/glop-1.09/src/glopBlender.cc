#include <glopBlender.h>
#include <GL/gl.h>


/* ######### */
/* #       # */
/* # Start # */
/* #       # */
/* ######### */

void glop::Blender::Start::InitDrawings(glop::Scene* scene)
{
}

void glop::Blender::Start::Draw(glop::Scene* scene)
{  

  if(!write_z)
    glDepthMask(GL_FALSE); /* z-buffer is write protected. */
  glEnable(GL_BLEND);    /* Frame buffer is written using blending. */


  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA); 
  /* Blending operates on source pixels (the ones that you draw),
     noted (Rs,Gs,Bs,As), and current frame buffer pixels
     (Rf,Gf,Bf,Af).

     The glBlendFunc function defines the result that is finally set
     in the frame buffer, by setting two sets of coefficients :
     
     (Sr,Sg,Sb,Sa) (Fr,Fg,Fb,Fa)

     such as final pixel is

     ( Rs*Sr+Rf*Fr , Gs*Sg+Gf*Fg , Bs*Sb+Bf*Fb , As*Sa+Af*Fa ).
     

     We use 

     GL_SRC_ALPHA => (Sr,Sg,Sb,Sa)=(As,As,As,As)
     GL_ONE => (Fr,Fg,Fb,Fa)=(1,1,1,1)

     to get the following blending : As*source + (1-As)*old_framebuffer_color. 
  */


}  


/* ######## */
/* #      # */
/* # Stop # */
/* #      # */
/* ######## */

void glop::Blender::Stop::InitDrawings(glop::Scene* scene)
{
}

void glop::Blender::Stop::Draw(glop::Scene* scene)
{
  // We disable blending...
  glDisable(GL_BLEND);

  // And make Z-buffer writable again.
  glDepthMask(GL_TRUE);
}  


/* ########### */
/* #         # */
/* # Blender # */
/* #         # */
/* ########### */


glop::Blender::Blender(void)
{
  start=new Start;
  start->write_z=false;

  stop=new Stop;

}

glop::Blender::~Blender(void) 
{
  delete start;
  delete stop;
}

glop::Drawable* glop::Blender::Begin(bool write_z)
{
  start->write_z=write_z;
  return start;
}

glop::Drawable* glop::Blender::End(void)
{
  return stop;
}
