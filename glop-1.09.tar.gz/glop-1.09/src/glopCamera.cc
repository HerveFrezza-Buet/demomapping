#include "glopCamera.h"


glop::Camera::Camera(void)
{
}


glop::Camera::~Camera(void)
{
}
