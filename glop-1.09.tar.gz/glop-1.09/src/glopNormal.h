#ifndef glop_NORMAL
#define glop_NORMAL

#include <GL/gl.h>

namespace glop {

  typedef unsigned int NormalMask;


  typedef void (*NormalFunction)(const GLfloat* x,
				 const GLfloat* y, 
				 const GLfloat* z,
				 GLfloat& nx, 
				 GLfloat& ny, 
				 GLfloat& nz);

  void Nop(const GLfloat* x,
	   const GLfloat* y,
	   const GLfloat* z,
	   GLfloat& nx,
	   GLfloat& ny,
	   GLfloat& nz);


  void Normal0000(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0001(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0010(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0011(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0100(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0101(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0110(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal0111(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1000(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1001(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1010(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1011(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1100(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1101(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1110(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);


  void Normal1111(const GLfloat* x,
		  const GLfloat* y,
		  const GLfloat* z,
		  GLfloat& nx,
		  GLfloat& ny,
		  GLfloat& nz);
}
#endif
