#include "glopClip.h"
#include <GL/gl.h>
#include <iostream>


/* ######### */
/* #       # */
/* # Start # */
/* #       # */
/* ######### */

void glop::Clip::Start::InitDrawings(glop::Scene* scene)
{
}

void glop::Clip::Start::Draw(glop::Scene* scene)
{  
  // we set this plane equation to openGL device.
  glClipPlane(channel,equation);

  // We enable clipping plane...
  glEnable(channel);
}  


/* ######## */
/* #      # */
/* # Stop # */
/* #      # */
/* ######## */

void glop::Clip::Stop::InitDrawings(glop::Scene* scene)
{
}

void glop::Clip::Stop::Draw(glop::Scene* scene)
{
  // We disable clipping plane...
  glDisable(channel);
}  


/* ######## */
/* #      # */
/* # Clip # */
/* #      # */
/* ######## */


glop::Clip::Clip(GLuint device_channel)
{
  start=new Start;
  stop=new Stop;
  
  start->channel=device_channel;
  stop->channel=device_channel;

  start->equation[0]=0;
  start->equation[1]=0;
  start->equation[2]=1;
  start->equation[3]=0;
}

glop::Clip::~Clip(void) 
{
  delete start;
  delete stop;
}

glop::Drawable* glop::Clip::Begin(void)
{
  return start;
}

glop::Drawable* glop::Clip::End(void)
{
  return stop;
}

void glop::Clip::Set(GLdouble a,GLdouble b,GLdouble c,GLdouble d)
{
  start->equation[0]=a;
  start->equation[1]=b;
  start->equation[2]=c;
  start->equation[3]=d;
}

void glop::Clip::Get(GLdouble& a,GLdouble& b,GLdouble& c,GLdouble& d)
{
  a=start->equation[0];
  b=start->equation[1];
  c=start->equation[2];
  d=start->equation[3];
}
