#include "glopTimeEvent.h"


void glop::TimeEventSet::Time(glop::Scene* scene)
{
  std::list<TimeEvent*>::iterator iter;
  
  for(iter=time_events.begin();
      iter!=time_events.end();
      ++iter)
    (*iter)->Time(scene);
}

void glop::TimeEventSet::AddTimeEvent(glop::TimeEvent* event)
{
  time_events.push_back(event);
}
