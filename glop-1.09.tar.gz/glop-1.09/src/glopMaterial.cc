#include "glopMaterial.h"


glop::Material::Material(void)
{
  // Set default values

  Color(1,1,1);
  Specular(1,1,1);
  Shininess(.9);
  TwoSide();
}

glop::Material::~Material(void)
{
}

void glop::Material::Color(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha)
{
  front_color[0]=r;
  front_color[1]=g;
  front_color[2]=b;
  front_color[3]=alpha;

  BackColor(r,g,b,alpha);
}

void glop::Material::BackColor(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha)
{
  back_color[0]=r;
  back_color[1]=g;
  back_color[2]=b;
  back_color[3]=alpha;
}

void glop::Material::Specular(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha)
{
  front_specular[0]=r;
  front_specular[1]=g;
  front_specular[2]=b;
  front_specular[3]=alpha;

  BackSpecular(r,g,b,alpha);
}

void glop::Material::BackSpecular(GLfloat r,GLfloat g,GLfloat b, GLfloat alpha)
{
  back_specular[0]=r;
  back_specular[1]=g;
  back_specular[2]=b;
  back_specular[3]=alpha;
}

void glop::Material::Shininess(GLfloat shininess)
{
  front_shininess=(int)(shininess*128+.5);
  BackShininess(shininess);
}

void glop::Material::BackShininess(GLfloat shininess)
{
  back_shininess=(int)(shininess*128+.5);
}

void glop::Material::BeginMaterial(void)
{
  if(two_side)
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);
  else
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,GL_FALSE);

  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE, front_color);
  glMaterialfv(GL_BACK ,GL_AMBIENT_AND_DIFFUSE, back_color);

  glMaterialfv(GL_FRONT,GL_SPECULAR, front_specular);
  glMaterialfv(GL_BACK ,GL_SPECULAR, back_specular);

  glMateriali(GL_FRONT,GL_SHININESS, front_shininess);
  glMateriali(GL_BACK, GL_SHININESS, back_shininess);
}

void glop::Material::EndMaterial(void)
{
}

void glop::Material::TwoSide(void)
{
  two_side=true;
}

void glop::Material::OneSide(void)
{
  two_side=false;
}
