#ifndef glop_TIME_EVENT
#define glop_TIME_EVENT

#include <glopCommon.h>
#include <list>

namespace glop {

  class Scene;
  class TimeEventSet;

  /** 
   * @short This class is an interface for stuff dealing with Time. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class TimeEvent {

  protected: 
    
    /**
     * This method will be called periodically, to emulate time
     * evolution.  */
    virtual void Time(Scene* scene)=0;
    
    friend class TimeEventSet;

  public:
    
    TimeEvent(void) {}
    virtual ~TimeEvent(void) {}
  };

  /**
   * @short A TimeEvent composed from other ones.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class TimeEventSet : public TimeEvent {


  protected:

    std::list<TimeEvent*> time_events;

    virtual void Time(Scene* scene);
    
  public:
    
    TimeEventSet(void) {}
    virtual ~TimeEventSet(void) {}
    
    /**
     * Add a TimeEvent in the set. All added TimeEvents will be managed
     * together, in the order they have been added. 
     */
    void AddTimeEvent(TimeEvent* event); 
  };
}

#endif
