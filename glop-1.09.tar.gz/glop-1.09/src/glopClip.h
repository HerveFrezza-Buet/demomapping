#ifndef glop_CLIP
#define glop_CLIP

#include <glopDrawable.h>
#include <map>
#include <GL/gl.h>

namespace glop {

  /**
   * @short This class manages clipping planes. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   */
  class Clip { 
    
  protected:


    /**
     * @short This starts clipping. For system use mainly.
     * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
     */
    class Start  : public Drawable {

    protected:  
      
      /**
       * This is one of the openGL device clipping planes : GL_CLIP_PLANE0, GL_CLIP_PLANE1, ...
       */
      GLuint channel;
      
      /**
       * Plane equation : a,b,c,d such as plane is ax+by+cz+d=0
       */
      GLdouble equation[4];
      
      virtual void InitDrawings(glop::Scene* scene);
      virtual void Draw(glop::Scene* scene);  

      friend class Clip;
    };
    
    /**
     * @short This stops clipping. For system use mainly.
     * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
     */
    class Stop  : public Drawable {
    protected:  
      
      /**
       * This is one of the openGL device clipping planes : GL_CLIP_PLANE0, GL_CLIP_PLANE1, ...
       */
      GLuint channel;

      virtual void InitDrawings(glop::Scene* scene);
      virtual void Draw(glop::Scene* scene);  

      friend class Clip;
    };

    /**
     * The starter object.
     */
    Start* start;

    /**
     * The stopper object.
     */
    Stop* stop;

  public:
    
    /**
     * Each clip is given one of the openGL device clip channel
     * (GL_CLIP_PLANE0, GL_CLIP_PLANE1, ...). You can associate many clips to a
     * single channel, but only one of them should be active.
     */
    Clip(GLuint device_channel);
    virtual ~Clip(void);

    /**
     * This provides an object (not copied) that trigger the start of
     * drawings that will be clipped.
     */
    Drawable* Begin(void);

    /**
     * This provides an object (not copied) that trigger the stop of
     * this clipping.
     */
    Drawable* End(void);

    /**
     * This sets The plane equation.
     * @params a,b,c,d Defines equation : ax+by+cz+d=0.
     */
    void Set(GLdouble a,GLdouble b,GLdouble c,GLdouble d);

    /**
     * This gets The plane equation.
     * @params a,b,c,d Defines equation : ax+by+cz+d=0.
     */
    void Get(GLdouble& a,GLdouble& b,GLdouble& c,GLdouble& d);
    
  };

}

#endif
