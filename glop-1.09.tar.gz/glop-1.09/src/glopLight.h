#ifndef glop_LIGHT
#define glop_LIGHT

#include <glopDrawable.h>
#include <map>
#include <GL/gl.h>

namespace glop {
  
  /**
   * @short This class manages the light environment (shade model,etc...). 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   * It is only a drawable that performs inits.
   */
  class LightModel : public Drawable { 

  protected :
    
    /**
     * Ambiant light color.
     */
    GLfloat ambient[4];

    /**
     * Shading. Can be GL_SMOOTH (default) or GL_FLAT.
     */
    GLuint shade;

    /** 
     * Status of each openGL light source.
     */
    std::map<GLuint,bool> light_enabled;

    virtual void InitDrawings(glop::Scene* scene);
    virtual void Draw(glop::Scene* scene);  

  public:

    LightModel(void);
    virtual ~LightModel(void);

    /**
     * Sets ambiant light color. It is an initializing method you can
     * use outside openGL context.
     * @param r,g,b The color...  
     * @param a ... and its alpha component.
     */
    void Ambient(GLfloat r,GLfloat g,GLfloat b,GLfloat a);

    /**
     * Sets shading. It is an initializing method you can
     * use outside openGL context.
     * @param shading Can be GL_SMOOTH (default) or GL_FLAT.
     */
    void Shading(GLuint shading);

    /**
     * Enables an openGL light source. It is an initializing method you can
     * use outside openGL context.
     * @param source Can be GL_LIGHT0 for example.
     */
    void Enable(GLuint source);

    /**
     * Disables an openGL light source. It is an initializing method you can
     * use outside openGL context.
     * @param source Can be GL_LIGHT0 for example.
     */
    void Disable(GLuint source);
  };

  /**
   * @short This class manages lights. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   */
  class Light : public Drawable { 
    
  protected:

    /**
     * This is one of the openGL device light : GL_LIGHT0, GL_LIGHT1, ...
     */
    GLuint channel;

    /**
     * This is true (default) if light is on.
     */
    bool power;

    /**
     * Color (rgba)
     */
    GLfloat diffuse[4];

    /**
     * Specular color (rgba)
     */
    GLfloat specular[4];

    /**
     * Ambient light color (rgba)
     */
    GLfloat ambient[4];

    /**
     * Position (x,y,z,w). w=0 means infinity (actual position is x/w,y/w,z/w).
     */
    GLfloat position[4];

    /**
     * Spot direction (x,y,z,w). w=0 means infinity (actual position
     * is x/w,y/w,z/w). This is a normal vector.
     */
    GLfloat direction[4];

    /**
     * Spot cut off
     */
    GLfloat spot_cutoff;

    /**
     * Spot exponent
     */
    GLfloat spot_exponent;

    /**
     * Spot attenuation
     */
    GLuint spot_attenuation;

    /**
     * This calls glop::LightSetup. When you averride Draw, be sure
     * to call glop::LightSetup.
     */
    virtual void Draw (Scene *scene);
    virtual void InitDrawings (Scene *scene);

    /**
     * If power is on, this sets up light. Use this in some Draw method. 
     */
    void LightSetup(void);

    
  public:
    
    /**
     * Each light is given one of the openGL device light channel
     * (GL_LIGHT0, GL_LIGHT1, ...). You can associate many lights to a
     * single channel, but only one of them should be ON.
     */
    Light(GLuint device_channel);
    virtual ~Light(void);

    /**
     * Switch the light on. Only one light per openGL light channel
     * (GL_LIGHT0, GL_LIGHT1, ...) should be On.
     */
    void SwitchOn(void);

    /**
     * Switch the light off
     */
    void SwitchOff(void);
    
  };

}

#endif
