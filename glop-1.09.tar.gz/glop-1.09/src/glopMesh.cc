#include "glopMesh.h"
#include <math.h>

glop::AbstractHueComputer::AbstractHueComputer(unsigned vector_size, GLfloat min_value, GLfloat max_value):
  _vector_size(vector_size), 
  _min_value(min_value), 
  _max_value( max_value),
  _div_delta_min_max(1.0/(max_value-min_value)){
  // preconditions
  assert(min_value<max_value);
  assert(_vector_size>0);
}

glop::AbstractHueComputer::~AbstractHueComputer(void){
}


glop::HueComputer::HueComputer(unsigned vector_size, GLfloat min_value, GLfloat max_value):
  AbstractHueComputer(vector_size, min_value, max_value){
}

void glop::HueComputer::CalcVertexColors(Vertex* v, GLfloat* colors){
  unsigned i;
  unsigned offset;

  for (i=0,offset=0;
       i<_vector_size;
       ++i,offset+=4)
    CalcHue(CalcIntensity((v[i]._z-_min_value>0.0)?v[i]._z-_min_value:0.0),
	    colors+offset);
}



glop::Mesh::Mesh(unsigned max_i, unsigned max_j):
  _max_i(max_i),
  _max_j(max_j),
  _size(_max_i*_max_j),
  _is_prepared(false),
  _is_material(true),
  _is_hue_mode_set(false),
  _is_normal_mode_set(true),
  _are_normal_values_kept(false),
  _selector(NULL),
  _grid_computer(new glop::FullGridComputer(max_i,max_j)){
  unsigned i;

  _function_map = new DrawFunction[_size];
  _normal_map   = new NormalFunction[_size];
  for (i=0;i<_size;i++){
    _function_map[i]=NULL;
    _normal_map[i]=NULL;
  }
  
  _x_normal_map = new GLfloat[_size];
  _y_normal_map = new GLfloat[_size];
  _z_normal_map = new GLfloat[_size];  
}


void glop::Mesh::MapDrawingFunc(bool* empty_cell_map){
  unsigned int u,v,inboundu,inboundv;
  DrawMask mask;
  unsigned a,b,c,d,e,f,g,h,i;

  //  a...b---c
  //  .   |   |
  //  .   |   |
  //  d...e---f
  //  .   .   .
  //  .   .   .
  //  g...h...i

  inboundu = _max_i-1;
  inboundv = _max_j-1;
  
  // e = (0,0)

  e=0;
  b=GetOffset(0,1);
  f=e+1;
  c=b+1;
  mask = vertexNone
    | (empty_cell_map[e]?vertexNone:vertexV0)
    | (empty_cell_map[f]?vertexNone:vertexV1)
    | (empty_cell_map[c]?vertexNone:vertexV2)
    | (empty_cell_map[b]?vertexNone:vertexV3);
  _function_map[e] = _selector->GetDraw(mask,
					_grid_computer->DisplayU(0),
					_grid_computer->DisplayV(0),
					true,true,true,true,true);

  // e = ([1..inboundu[,0)
  
  for(u=1,
	e=GetOffset(1,0),
	b=GetOffset(1,1),
	a=b-1,
	c=b+1,
	d=e-1,
	f=e+1;
      u<inboundu;
      ++u,
	++a,++b,++c,++d,++e,++f) { 
    mask = vertexNone
      | (empty_cell_map[e]?vertexNone:vertexV0)
      | (empty_cell_map[f]?vertexNone:vertexV1)
      | (empty_cell_map[c]?vertexNone:vertexV2)
      | (empty_cell_map[b]?vertexNone:vertexV3);
    _function_map[e] = _selector->GetDraw(mask,
					  _grid_computer->DisplayU(u),
					  _grid_computer->DisplayV(0),
					  empty_cell_map[a],
					  empty_cell_map[d],
					  true,true,true);
  }
  
  // e = (inboundu,0)

  mask = vertexNone
      | (empty_cell_map[e]?vertexNone:vertexV0)
      | (empty_cell_map[b]?vertexNone:vertexV3);
  _function_map[e] = _selector->GetDraw(mask,
					_grid_computer->DisplayU(inboundu),
					_grid_computer->DisplayV(0),
					empty_cell_map[a],
					empty_cell_map[d],
					true,true,true);

  // e = ([1..inboundu[,[1..inboundv[)
  
  for(v=1;v<inboundv;++v) {
    
    // e = (0,v)
    
    e = GetOffset(0,v);
    b = GetOffset(0,v+1);
    h = GetOffset(0,v-1);
    f = e+1;
    c = b+1;
    i = h+1;
    mask = vertexNone
      | (empty_cell_map[e]?vertexNone:vertexV0)
      | (empty_cell_map[f]?vertexNone:vertexV1)
      | (empty_cell_map[c]?vertexNone:vertexV2)
      | (empty_cell_map[b]?vertexNone:vertexV3);
    _function_map[e] = _selector->GetDraw(mask,
					  _grid_computer->DisplayU(0),
					  _grid_computer->DisplayV(v),
					  true,true,true,
					  empty_cell_map[h],
					  empty_cell_map[i]);

    // e = ([1..inboundu[,v)
    for(u=1,
	  e=GetOffset(u,v),
	  b=GetOffset(u,v+1),
	  h=GetOffset(u,v-1),
	  a=b-1,
	  c=b+1,
	  d=e-1,
	  f=e+1,
	  g=h-1,
	  i=h+1;
	u<inboundu;
	++u,
	  ++a,++b,++c,++d,++e,++f,++g,++h,++i) {
      mask = vertexNone
	| (empty_cell_map[e]?vertexNone:vertexV0)
	| (empty_cell_map[f]?vertexNone:vertexV1)
	| (empty_cell_map[c]?vertexNone:vertexV2)
	| (empty_cell_map[b]?vertexNone:vertexV3);
      _function_map[e] = _selector->GetDraw(mask,
					    _grid_computer->DisplayU(u),
					    _grid_computer->DisplayV(v),
					    empty_cell_map[a],
					    empty_cell_map[d],
					    empty_cell_map[g],
					    empty_cell_map[h],
					    empty_cell_map[i]);
    }
    
    // e = (inboundu,v)
    mask = vertexNone
      | (empty_cell_map[e]?vertexNone:vertexV0)
      | (empty_cell_map[b]?vertexNone:vertexV3);
    _function_map[e] = _selector->GetDraw(mask,
					  _grid_computer->DisplayU(inboundu),
					  _grid_computer->DisplayV(v),
					  empty_cell_map[a],
					  empty_cell_map[d],
					  empty_cell_map[g],
					  empty_cell_map[h],
					  true);
  }
  
  // e = (0,inboundv)
  
  e = GetOffset(0,inboundv);
  h = GetOffset(0,inboundv-1);
  f = e+1;
  i = h+1;
  mask = vertexNone
    | (empty_cell_map[e]?vertexNone:vertexV0)
    | (empty_cell_map[f]?vertexNone:vertexV1);
  _function_map[e] = _selector->GetDraw(mask,
					_grid_computer->DisplayU(0),
					_grid_computer->DisplayV(inboundv),
					true,true,true,
					empty_cell_map[h],
					empty_cell_map[i]);
  
  // e = ([1..inboundu[,inboundv)
  
  for(u=1,
	e = GetOffset(1,inboundv),
	h = GetOffset(1,inboundv-1),
	d = e-1,
	f = e+1,
	g = h-1,
	i = h+1;
      u<inboundu;
      ++u,
	++d,++e,++f,++g,++h,++i) {
    mask = vertexNone
      | (empty_cell_map[e]?vertexNone:vertexV0)
      | (empty_cell_map[f]?vertexNone:vertexV1);
    _function_map[e] = _selector->GetDraw(mask,
					  _grid_computer->DisplayU(u),
					  _grid_computer->DisplayV(inboundv),
					  true,
					  empty_cell_map[d],
					  empty_cell_map[g],
					  empty_cell_map[h],
					  empty_cell_map[i]);
  }
  
  // e = (inboundu,inboundv)
  mask = vertexNone
    | (empty_cell_map[e]?vertexNone:vertexV0);
  _function_map[e] = _selector->GetDraw(mask,
					_grid_computer->DisplayU(inboundu),
					_grid_computer->DisplayV(inboundv),
					true,
					empty_cell_map[d],
					empty_cell_map[g],
					empty_cell_map[h],
					true);
  
  
}


void glop::Mesh::MapNormalFunc1x1Map(bool* empty_cell_map){
  //precondition
  assert(1==_max_i&&1==_max_j);

  if(!empty_cell_map[0]){
    // alone in the univers
    _normal_map[0] = _selector->GetNormal(0);
  }
  else
    // a map with just an hole!
    _normal_map[0] = Nop;

  //postcondition
  assert(_normal_map[0]==Normal0000||_normal_map[0]==Nop);
}


void glop::Mesh::MapNormalFuncLeftBottomCorner(bool* empty_cell_map){
  //precondition
  assert(0<_max_i);
  assert(0<_max_j);

  NormalMask mask;

  if(!empty_cell_map[0]){
    mask=(empty_cell_map[_max_i]?0:vertexV0)
      |(empty_cell_map[1]?0:vertexV1);
    _normal_map[0] = _selector->GetNormal(mask);
  }
  else
    _normal_map[0] = Nop;


  //postcondition
  assert(_normal_map[0]==Normal0000||
	 _normal_map[0]==Nop||
	 _normal_map[0]==Normal0011||
	 _normal_map[0]==Normal0010||
	 _normal_map[0]==Normal0001);
}


void glop::Mesh::MapNormalFuncLeftTopCorner(bool* empty_cell_map){
  //precondition
  assert(0<_max_i);
  assert(1<_max_j);

  NormalMask mask;
  unsigned offset;

  offset = _max_i*(_max_j-1);
  if(!empty_cell_map[offset]){
    mask=(empty_cell_map[offset+1]?0:vertexV1)
      |(empty_cell_map[offset-_max_i]?0:vertexV2);
    _normal_map[offset] = _selector->GetNormal(mask);
  }
  else
    _normal_map[offset] = Nop;

  //postcondition
  assert(_normal_map[offset]==Normal0000||
	 _normal_map[offset]==Nop||
	 _normal_map[offset]==Normal0110||
	 _normal_map[offset]==Normal0100||
	 _normal_map[offset]==Normal0010);
}


void glop::Mesh::MapNormalFuncRightBottomCorner(bool* empty_cell_map){
  //precondition
  assert(1<_max_i);
  assert(1<_max_j);

  NormalMask mask;
  unsigned offset;

  offset = _max_i-1;

  //bottom right corner
  if(!empty_cell_map[offset]){
    mask=(empty_cell_map[offset+_max_i]?0:vertexV0)
      |(empty_cell_map[offset-1]?0:vertexV3);

      _normal_map[offset] = _selector->GetNormal(mask);
  }
  else
    _normal_map[offset] = Nop;

  //postcondition
  assert(_normal_map[offset]==Normal0000||
	 _normal_map[offset]==Nop||
	 _normal_map[offset]==Normal1001||
	 _normal_map[offset]==Normal1000||
	 _normal_map[offset]==Normal0001);
}


void glop::Mesh::MapNormalFuncRightTopCorner(bool* empty_cell_map){
  //precondition
  assert(1<_max_i);
  assert(1<_max_j);

  NormalMask mask;
  unsigned offset;

  offset = _max_i*_max_j-1;
  //top rigth corner
  if(!empty_cell_map[offset]){
    mask=(empty_cell_map[offset-_max_i]?0:vertexV2)
      |(empty_cell_map[offset-1]?0:vertexV3);
    _normal_map[offset] = _selector->GetNormal(mask);
  }
  else
    _normal_map[offset] = Nop;

  //postcondition
  assert(_normal_map[offset]==Normal0000||
	 _normal_map[offset]==Nop||
	 _normal_map[offset]==Normal1100||
	 _normal_map[offset]==Normal1000||
	 _normal_map[offset]==Normal0100);
}


void glop::Mesh::MapNormalFuncFirstColumn(bool* empty_cell_map){
  //precondition
  assert(0<_max_i);
  assert(2<_max_j);

  NormalMask mask;
  unsigned offset;

  //bottom row
  for(offset=_max_i;offset<_max_i*(_max_j-1);offset+=_max_i){
    if(!empty_cell_map[offset]){
      mask=(empty_cell_map[offset+_max_i]?0:vertexV0)
	|(empty_cell_map[offset+1]?0:vertexV1)
	|(empty_cell_map[offset+1]?0:vertexV2);
      _normal_map[offset] = _selector->GetNormal(mask);
    }
    else
      _normal_map[offset] = Nop;
  }

  //postcondition
}


void glop::Mesh::MapNormalFuncLastColumn(bool* empty_cell_map){
  //precondition
  assert(1<_max_i);
  assert(2<_max_j);

  NormalMask mask;
  unsigned offset;

  for(offset=_max_i-1;offset<_max_i*(_max_j-1);offset+=_max_i){
    if(!empty_cell_map[offset]){
      mask=(empty_cell_map[offset+_max_i]?0:vertexV0)
	|(empty_cell_map[offset-1]?0:vertexV2)
	|(empty_cell_map[offset-1]?0:vertexV3);
      _normal_map[offset] = _selector->GetNormal(mask);
    }
    else
      _normal_map[offset] = Nop;
  }

  //postcondition
}


void glop::Mesh::MapNormalFuncFirstRow(bool* empty_cell_map){
  //precondition
  assert(0<_max_i);
  assert(2<_max_j);

  NormalMask mask;
  unsigned i;

  //left first colomn
  for(i=1;i<_max_i-1;++i){
    if(!empty_cell_map[i]){
      mask=(empty_cell_map[i+_max_i]?0:vertexV0)
	|(empty_cell_map[i+1]?0:vertexV1)
	|(empty_cell_map[i+1]?0:vertexV3);
      _normal_map[i] = _selector->GetNormal(mask);
    }
    else
      _normal_map[i] = Nop;
  }

  //postcondition
}


void glop::Mesh::MapNormalFuncLastRow(bool* empty_cell_map){
  //precondition
  assert(1<_max_i);
  assert(2<_max_j);

  NormalMask mask;
  unsigned i;
  unsigned offset;

  //right last colomn
  offset = _size-_max_i;
  for(i=1;i<_max_i-1;++i){
    if(!empty_cell_map[offset+i]){
      mask=(empty_cell_map[offset+i+1]?0:vertexV1)
	|(empty_cell_map[offset+i-_max_i]?0:vertexV2)
	|(empty_cell_map[offset+i-_max_i]?0:vertexV3);
      _normal_map[offset+i] = _selector->GetNormal(mask);
    }
    else
      _normal_map[offset+i] = Nop;
  }

  //postcondition
}


void glop::Mesh::MapNormalFuncInnerCell(bool* empty_cell_map){
  //precondition
  assert(2<_max_i);
  assert(2<_max_j);

  NormalMask mask;
  unsigned i;
  unsigned j;
  unsigned offset;
  unsigned offset_plus_i;

  // inner vertex
  for(j=1;j<_max_j-1;++j){
    offset = GetOffset(0,j);
    for(i=1;i<_max_i-1;++i){
      offset_plus_i=offset+i;
      if(!empty_cell_map[offset_plus_i]){
	mask=(empty_cell_map[offset_plus_i+_max_i]?0:vertexV0)
	  |(empty_cell_map[offset_plus_i+1]?0:vertexV1)
	  |(empty_cell_map[offset_plus_i-_max_i]?0:vertexV2)
	  |(empty_cell_map[offset_plus_i-1]?0:vertexV3);
       	_normal_map[offset_plus_i] = _selector->GetNormal(mask);
      }
      else
	_normal_map[offset_plus_i] = Nop;
    }
  }
  
  //postcondition
}


void glop::Mesh::MapNormalFunc(bool* empty_cell_map){
  // stop here if there is just one point.
  if (1==_max_i&&1==_max_j){
    MapNormalFunc1x1Map(empty_cell_map);
    return;
  }

  //bottom left corner
  if (0<_max_i&&0<_max_j)  
    MapNormalFuncLeftBottomCorner(empty_cell_map);

  //top left corner
  if (0<_max_i&&1<_max_j)
    MapNormalFuncLeftTopCorner(empty_cell_map);

  //bottom right corner
  if (1<_max_i&&0<_max_j)
    MapNormalFuncRightBottomCorner(empty_cell_map);

  //top right corner
  if (1<_max_i&&1<_max_j)
    MapNormalFuncRightTopCorner(empty_cell_map);

  // Useful only if the map isn't one row thin. Otherwise this case was treated by a previous for
  if (2<_max_i&&1<_max_j)
    MapNormalFuncLastRow(empty_cell_map);
  
  
  // Useful only if the map isn't one row thin. Otherwise this case was treated by a previous for
  if (2<_max_i&&0<_max_j)
    MapNormalFuncFirstRow(empty_cell_map);

  // Useful only if the map isn't one row thin. Otherwise this case was treated by a previous for
  if (1<_max_i&&2<_max_j)
    MapNormalFuncLastColumn(empty_cell_map);
 
  // Useful only if the map isn't one row thin. Otherwise this case was treated by a previous for
  if (0<_max_i&&2<_max_j)
    MapNormalFuncFirstColumn(empty_cell_map);
 
  // don't do this evaluation if map have just one row or one column.
  // this case was already treated by a previsous for
  if (2<_max_i&&2<_max_j)
    MapNormalFuncInnerCell(empty_cell_map);
  
  assert(_max_i>1||_max_j>1);
}  

  
// Has to be called just one time. High time consumming procedure
void  glop::Mesh::Prepare(bool* empty_cell_map){
  // preconditions
  assert(!_is_prepared);

  unsigned i;

  MapDrawingFunc(empty_cell_map);
  MapNormalFunc(empty_cell_map);

  _is_prepared=true;

  // postconditions
  assert(_is_prepared);
  for (i=0;i<_size;i++){
    assert(_function_map[i]);
    assert(_normal_map[i]);
  }
}


void glop::Mesh::CalcNormals(glop::Vertex* vertexes){
  unsigned i;
  unsigned j;
  unsigned offset;
  unsigned offset_i_j;
  GLfloat nx[5];
  GLfloat ny[5];
  GLfloat nz[5];

  //
  //         1
  //
  //   4     0     2
  //
  //         3
  //


  for(j=0;j<_max_j;++j){
    offset = j*_max_i;
    assert(offset<(_size));
    for(i=0;i<_max_i;++i){
      offset_i_j=offset+i;
      assert(offset_i_j<(_size));

      nx[0]=vertexes[offset_i_j]._x;
      ny[0]=vertexes[offset_i_j]._y;
      nz[0]=vertexes[offset_i_j]._z;
      
      // normal
      if ((offset_i_j+_max_i)<_size){
	assert((offset_i_j+_max_i)<_size);
	nx[1]=vertexes[offset_i_j+_max_i]._x;
	ny[1]=vertexes[offset_i_j+_max_i]._y;
	nz[1]=vertexes[offset_i_j+_max_i]._z;
      }

      if ((offset_i_j+1)<_size){ 
	assert((offset_i_j+1)<_size);
	nx[2]=vertexes[offset_i_j+1]._x;
	ny[2]=vertexes[offset_i_j+1]._y;
	nz[2]=vertexes[offset_i_j+1]._z;
      }

      if ((offset_i_j)>=_max_i){ 
	assert((offset_i_j-_max_i)<_size);
	assert(offset_i_j>=_max_i);
	nx[3]=vertexes[offset_i_j-_max_i]._x;
	ny[3]=vertexes[offset_i_j-_max_i]._y;
	nz[3]=vertexes[offset_i_j-_max_i]._z;
      }
      
      if (offset_i_j>=1){
	assert((offset_i_j-1)<_size);
	assert(offset_i_j>=1);
	nx[4]=vertexes[offset_i_j-1]._x;
	ny[4]=vertexes[offset_i_j-1]._y;
	nz[4]=vertexes[offset_i_j-1]._z;
      }

      // normal vector computing
      assert(offset_i_j>=0);
      assert(offset_i_j<_size);
      _normal_map[offset_i_j](nx,ny,nz,
			      _x_normal_map[offset_i_j],
			      _y_normal_map[offset_i_j],
			      _z_normal_map[offset_i_j]);
    }
  }
}


void glop::Mesh::DrawVertexes(glop::Vertex* vertexes, GLfloat* colors){
  unsigned i;
  unsigned j;
  unsigned offset;
  unsigned offset_i_j;
  unsigned color_offset_i_j;

  DrawInfo draw_info(4,_is_normal_mode_set,_is_hue_mode_set);

  // Vertex drawing
  //         
  //   4 <- 3
  //
  //        ^
  //        |
  //        
  //   1 -> 2
  //   


  for(j=0;j<_max_j;++j){
    offset = j*_max_i;
    for(i=0;i<_max_i;++i){

      // offset_i_j = j*_max_i + i
      // vertex
      offset_i_j=offset+i;
      if (offset_i_j<_size){
	assert(offset_i_j<_size);

	draw_info.x[0] = vertexes[offset_i_j]._x;
	draw_info.y[0] = vertexes[offset_i_j]._y;
	draw_info.z[0] = vertexes[offset_i_j]._z;

	// normal
	if (_is_normal_mode_set){
	  draw_info.nx[0]= _x_normal_map[offset_i_j];
	  draw_info.ny[0]= _y_normal_map[offset_i_j];
	  draw_info.nz[0]= _z_normal_map[offset_i_j];
	}
	// color
	if (_is_hue_mode_set){
	  color_offset_i_j = offset_i_j*4;

	  draw_info.r[0]= colors[color_offset_i_j];
	  draw_info.g[0]= colors[color_offset_i_j+1];
	  draw_info.b[0]= colors[color_offset_i_j+2];
	  draw_info.a[0]= colors[color_offset_i_j+3];
	}

      }
      // offset_i_j = j*_max_i + i + 1
      offset_i_j++;
      if (offset_i_j<_size){
	assert(offset_i_j<_size);

	// vertex
	draw_info.x[1] = vertexes[offset_i_j]._x;
	draw_info.y[1] = vertexes[offset_i_j]._y;
	draw_info.z[1] = vertexes[offset_i_j]._z;

	// normal
	if (_is_normal_mode_set){
	  draw_info.nx[1]= _x_normal_map[offset_i_j];
	  draw_info.ny[1]= _y_normal_map[offset_i_j];
	  draw_info.nz[1]= _z_normal_map[offset_i_j];
	}
	// color
	if (_is_hue_mode_set){
	  color_offset_i_j = offset_i_j*4;

	  draw_info.r[1]= colors[color_offset_i_j];
	  draw_info.g[1]= colors[color_offset_i_j+1];
	  draw_info.b[1]= colors[color_offset_i_j+2];
	  draw_info.a[1]= colors[color_offset_i_j+3];
	}
      }
      // offset_i_j = (j+1)*_max_i + i + 1
      offset_i_j+=_max_i;
      if (offset_i_j<_size){
	assert(offset_i_j<_size);


	// vertex
	draw_info.x[2] = vertexes[offset_i_j]._x;
	draw_info.y[2] = vertexes[offset_i_j]._y;
	draw_info.z[2] = vertexes[offset_i_j]._z;
	// normal
	if (_is_normal_mode_set){
	  draw_info.nx[2]= _x_normal_map[offset_i_j];
	  draw_info.ny[2]= _y_normal_map[offset_i_j];
	  draw_info.nz[2]= _z_normal_map[offset_i_j];
	}
	// color
	if (_is_hue_mode_set){
	  color_offset_i_j = offset_i_j*4;

	  draw_info.r[2]= colors[color_offset_i_j];
	  draw_info.g[2]= colors[color_offset_i_j+1];
	  draw_info.b[2]= colors[color_offset_i_j+2];
	  draw_info.a[2]= colors[color_offset_i_j+3];
	}
      }
      // offset_i_j = (j+1)*_max_i + i
      if (offset_i_j>0){
	--offset_i_j;
	if (offset_i_j<_size){
	  assert(offset_i_j<_size);
	  // vertex
	  draw_info.x[3] = vertexes[offset_i_j]._x;
	  draw_info.y[3] = vertexes[offset_i_j]._y;
	  draw_info.z[3] = vertexes[offset_i_j]._z;
	  // normal
	  if (_is_normal_mode_set){
	    draw_info.nx[3]= _x_normal_map[offset_i_j];
	    draw_info.ny[3]= _y_normal_map[offset_i_j];
	    draw_info.nz[3]= _z_normal_map[offset_i_j];
	  }
	  // color
	  if (_is_hue_mode_set){
	    color_offset_i_j = offset_i_j*4;
	    
	    draw_info.r[3]= colors[color_offset_i_j];
	    draw_info.g[3]= colors[color_offset_i_j+1];
	    draw_info.b[3]= colors[color_offset_i_j+2];
	    draw_info.a[3]= colors[color_offset_i_j+3];
	  }
	}
      }

      // vertex drawing
      assert((offset+i)<(_max_i*_max_j));
      assert(_function_map[offset+i]);
      _function_map[offset+i](draw_info);
    }    
  }
}




void glop::Mesh::Render(glop::Vertex* vertexes, GLfloat* colors){
  //precondition 
  assert(_selector);
  assert((colors&&_is_hue_mode_set)||!_is_hue_mode_set);

  GLboolean old_material;
  glGetBooleanv(GL_COLOR_MATERIAL, &old_material);

  glPolygonMode(GL_FRONT_AND_BACK, _selector->GetPolygonMode());

  // The polygone drawing mode
  if (_is_normal_mode_set&&!_are_normal_values_kept){
//std::cout<<"### calc normal ###"<<std::endl;
    CalcNormals(vertexes);
  }
  else
    // you have to say explicitely that you want to keep normal unchanged
    _are_normal_values_kept = false;

  // if !_is_hue_mode_set material mode not managed
  // if old_material is true there are no needs to enable color material
  if(_is_hue_mode_set&&!old_material)
    glEnable(GL_COLOR_MATERIAL);

  DrawVertexes(vertexes,colors);

  // if !_is_hue_mode_set material mode not managed
  // if old_material is true the material mode must not be changed!
  if(_is_hue_mode_set&&!old_material)
    glDisable(GL_COLOR_MATERIAL);
}
