#ifndef glop_BLENDER
#define glop_BLENDER

#include <glopDrawable.h>

namespace glop {

  /**
   * @short This provides blending.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Blender {


  protected :

    /**
     * @short This starts blending. For system use mainly.
     * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
     */
    class Start  : public Drawable {
    
    public:

    bool write_z;

    protected:
      virtual void InitDrawings(glop::Scene* scene);
      virtual void Draw(glop::Scene* scene);  
    };

    /**
     * @short This stops blending. For system use mainly.
     * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
     */
    class Stop  : public Drawable {
    protected:
      virtual void InitDrawings(glop::Scene* scene);
      virtual void Draw(glop::Scene* scene);  
    };

    /**
     * The starter object.
     */
    Start* start;


    /**
     * The stopper object.
     */
    Stop* stop;

  public:
    
    Blender(void);
    virtual ~Blender(void);
    
    /**
     * This provides an object (not copied) that trigger the start of
     * blending mode drawings.
     * @param z_writable Tells if z-buffer will be written during blending. Default is false.
     */
    Drawable* Begin(bool write_z=false);

    /**
     * This provides an object (not copied) that trigger the stop of
     * blending mode drawings.
     */
    Drawable* End(void);

  };

}


#endif
