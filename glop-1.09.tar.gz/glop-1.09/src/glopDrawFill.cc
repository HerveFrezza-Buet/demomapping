#include "glopDrawFill.h"

#include<iostream>

////////////////////////////////////////////////////////////////
//
// function pointer
//
////////////////////////////////////////////////////////////////

// # : not defined out of bound
// x : empty cell
// O : set cell

//
//  x....x      #....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  x....x      #....#
//
void glop::DrawFill0000(const glop::DrawInfo& draw_info){
  // no operations here
}


//
//  x....x      #....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  O....x      O....#
//
void glop::DrawFill0001(const glop::DrawInfo& draw_info){
  // just one point
  glBegin(GL_POINT);
  DrawVertex(draw_info, 0);
  glEnd();
}


//
//  x....x      #....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  x....O      #....O
//
void glop::DrawFill0010(const glop::DrawInfo& draw_info){
  // no operations here
}

//  
//  #....#
//  .    .
//  .    .
//  .    .
//  .    .
//  O----O
//
void glop::DrawFill0011(const glop::DrawInfo& draw_info){
  glBegin(GL_LINES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  glEnd();
}


//
//  #....O
//  .    .
//  .    .
//  .    .
//  .    .
//  #....#
//
void glop::DrawFill0100(const glop::DrawInfo& draw_info){
  // no operations here
	
}

//  0101 no x1x1 possible because of square map
//  x....O
//  .    .
//  .    .
//  .    .
//  .    .
//  O....x
//
void glop::DrawFill0101(const glop::DrawInfo& draw_info){
  glBegin(GL_POINT);
  DrawVertex(draw_info, 0);
  glEnd();
}

//  0110,  x11x doesn't exists the drawing begin at (0,0) not (-1,-1)!
//  x....O
//  .    .
//  .    .
//  .    . 
//  .    .
//  x....O
//
void glop::DrawFill0110(const glop::DrawInfo& draw_info){  
  // no operations here
}

//
//  x....O
//  .   /|
//  .  / |
//  . /  |
//  ./   |
//  O----O
//
void glop::DrawFill0111(const glop::DrawInfo& draw_info){
  glBegin(GL_TRIANGLES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  DrawVertex(draw_info, 2);
  glEnd();
}

//
//  O....x      O....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  x....x      #....#
//
void glop::DrawFill1000(const glop::DrawInfo& draw_info){
  // no operations here
}

//
//  O....x      O....#
//  |    .      |    .
//  |    .  or  |    .
//  |    .      |    .
//  |    .      |    .
//  O....x      O....#
//
void glop::DrawFill1001(const glop::DrawInfo& draw_info){
  glBegin(GL_LINES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 3);
  glEnd();
}

//
//  O....x
//  .    .
//  .    .
//  .    .
//  .    .
//  x....O
//
void glop::DrawFill1010(const glop::DrawInfo& draw_info){
  // no operations here
}

//
//  O....x
//  |\   .
//  | \  .
//  |  \ .
//  |   \.
//  O----O
//
void glop::DrawFill1011(const glop::DrawInfo& draw_info){
  glBegin(GL_TRIANGLES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  DrawVertex(draw_info, 3);
  glEnd();
}

//
//  O....O
//  .    . 
//  .    .
//  .    .
//  .    .
//  #....#
//
void glop::DrawFill1100(const glop::DrawInfo& draw_info){
  // Nothing
}

//
//  O----O
//  |   /.
//  |  / .
//  | /  .
//  |/   .
//  O....x
//
void glop::DrawFill1101(const glop::DrawInfo& draw_info){
  glBegin(GL_TRIANGLES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 2);
  DrawVertex(draw_info, 3);
  glEnd();
}


//
//  O----O
//  .\   |
//  . \  |
//  .  \ |
//  .   \|
//  x....O
//
void glop::DrawFill1110(const glop::DrawInfo& draw_info){
  glBegin(GL_TRIANGLES);
  DrawVertex(draw_info, 2);
  DrawVertex(draw_info, 3);
  DrawVertex(draw_info, 1);
  glEnd();
}


//
//  O----O
//  |\   |
//  | \  |
//  |  \ |
//  |   \|
//  O----O
//
void glop::DrawFill1111(const glop::DrawInfo& draw_info){
  glBegin(GL_TRIANGLES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  DrawVertex(draw_info, 3);
  glEnd();

  glBegin(GL_TRIANGLES);
  DrawVertex(draw_info, 2);
  DrawVertex(draw_info, 3);
  DrawVertex(draw_info, 1);
  glEnd();
}



glop::FillFunctionSelector::~FillFunctionSelector(void){}

glop::FillFunctionSelector::FillFunctionSelector(void){
  _polygon_mode = GL_FILL;

  _draw[0]  = DrawFill0000;
  _draw[1]  = DrawFill0001;
  _draw[2]  = DrawFill0010;
  _draw[3]  = DrawFill0011;

  _draw[4]  = DrawFill0100;
  _draw[5]  = DrawFill0101;
  _draw[6]  = DrawFill0110;
  _draw[7]  = DrawFill0111;

  _draw[8]  = DrawFill1000;
  _draw[9]  = DrawFill1001;
  _draw[10] = DrawFill1010;
  _draw[11] = DrawFill1011;

  _draw[12] = DrawFill1100;
  _draw[13] = DrawFill1101;
  _draw[14] = DrawFill1110;
  _draw[15] = DrawFill1111;

  _normal[0]  = Normal0000;
  _normal[1]  = Normal0001;
  _normal[2]  = Normal0010;
  _normal[3]  = Normal0011;

  _normal[4]  = Normal0100;
  _normal[5]  = Normal0101;
  _normal[6]  = Normal0110;
  _normal[7]  = Normal0111;

  _normal[8]  = Normal1000;
  _normal[9]  = Normal1001;
  _normal[10] = Normal1010;
  _normal[11] = Normal1011;

  _normal[12] = Normal1100;
  _normal[13] = Normal1101;
  _normal[14] = Normal1110;
  _normal[15] = Normal1111;
}
