#ifndef glop_MOUSE_EVENT
#define glop_MOUSE_EVENT

#include <glopCommon.h>
#include <list>

namespace glop {

  class Scene;
  class MouseEventSet;

  /**
   * @short This class is an interface for stuff dealing with mouse. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class MouseEvent {

  public: 


    /**
     * This manages mouse clicks. Override it and system will call it for you, but you can also call it by yourself to simulate a click.
     * @param scene The scene.
     * @param b The button that is actually clicked.  
     * @param x,y Position of the mouse pointer in the window. (0,0) is upper-left corner.
     */
    virtual void Click(Scene* scene,
		       Button b,
		       int x,int y)=0;

    /**
     * This manages mouse motion. Override it and system will call it
     * for you, but you can also call it by yourself to simulate a
     * motion.
     * 
     * @param scene The scene.
     * @param b The button that is actually pressed (if previously pressed in the window). It may be glop::buttonNone if no button is pressed.
     * @param x,y Position of the mouse pointer in the window. (0,0) is upper-left corner.
     * @param dx,dy If button is actually pressed, the relative position from last click.
     * @param ddx,ddy If button is actually pressed, the relative position from last call of this method.
     */
    virtual void Motion(Scene* scene,
			Button b,
			int x,int y,
			int dx,int dy,
			int ddx,int ddy)=0;

  public:
    
    MouseEvent(void) {}
    virtual ~MouseEvent(void) {}
  };

  /**
   * @short A mouseEvent composed from other ones.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class MouseEventSet : public MouseEvent {


  protected:
    
    std::list<MouseEvent*> mouse_events;

    virtual void Click(Scene* scene,
		       Button b,
		       int x,int y);
    virtual void Motion(Scene* scene,
			Button b,
			int x,int y,
			int dx,int dy,
			int ddx,int ddy);
  public:
    
    MouseEventSet(void) {}
    virtual ~MouseEventSet(void) {}
    
    /**
     * Add a mouseEvent in the set. All added mouseEvents will be managed
     * together, in the order they have been added. 
     */
    void AddMouseEvent(MouseEvent* event); 
  };
}

#endif
