#ifndef glop_PRISM
#define glop_PRISM

#include <GL/gl.h>
#include <list>

namespace glop {

  /**
   * @short This builds a prism from a polygon.
   * Inherit this class to build your prism object
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Prism {

  private:

    std::list<GLfloat> _points;

  public: 
    
    Prism(void);
    virtual ~Prism(void);

    /**
     * @param xy The (x,y) list must form a conter-clock enumeration
     * (when sees from positive Zs) <b>convex</b> polygon.
     */
    void AddVertex(GLfloat x, GLfloat y);
    
  protected:

    /**
     * This method draws the prism corresponding to the sweeping of
     * the polygon drawn in the xy plane from z=0 to z=1. Normals are
     * not normalized, but the scene manages it correctly.
     */
    void DrawPrism(void);

  };

}


#endif
