#include "glopDrawable.h"
#include "glopLight.h"
#include <GL/gl.h>

/* ############ */
/* #          # */
/* # Drawable # */
/* #          # */
/* ############ */

GLuint glop::Drawable::name_counter=0;

glop::Drawable::Drawable(void)
{
  is_init=false;
  is_selectable=false;

  // We ensure that each drawable name is different and > 0.
  name_counter++;
  name=name_counter;
}

glop::Drawable::~Drawable(void)
{
}

void glop::Drawable::SystemDraw(Scene* scene,GLuint parent_last_name)
{
  // Before drawing, we have to set the name at the top of the name
  // stack. This will be efficient only in openGL selection mode. A
  // non selectable object has its parent name.


  if(is_selectable)
    {
      glPushName(name);
      last_name=name;
    }
  else
    last_name=parent_last_name;

  Draw(scene);

  if(is_selectable)
    glPopName();
  
}

void glop::Drawable::SystemInitDrawings(Scene* scene)
{
  InitDrawings(scene);
}

void glop::Drawable::Selectable(bool status)
{
  is_selectable=status;
}

void glop::Drawable::ProcessSelection(std::map<GLuint,int>& name_rank)
{
  if(name_rank.find(last_name)==name_rank.end())
    SelectionNotify(-1);// Object is not selected.
  else
    SelectionNotify(name_rank[last_name]);

}

void glop::Drawable::SelectionNotify(int rank)
{
}



/* ################ */
/* #              # */
/* # Drawable Set # */
/* #              # */
/* ################ */

void glop::DrawableSet::DrawContents(Scene* scene)
{
  std::list< std::pair<glop::Drawable*,void (*) (glop::Drawable*)> >::iterator iter;
  Drawable* that;

  for(iter=drawables.begin();
      iter!=drawables.end();
      ++iter)
    {
      that=(*iter).first;
      if((*iter).second!=NULL)
	{
	  glPushMatrix();                    // Push matrix
	  // Call of the move                //
	  (*((*iter).second))(that);         // Translate, rotate, etc...
	  that->SystemDraw(scene,last_name); // Draw
	  glPopMatrix();                     // Pop matrix.
	}
      else
	that->SystemDraw(scene,last_name);
    }
}

void glop::DrawableSet::Draw(glop::Scene* scene)
{
  DrawContents(scene);
}

void glop::DrawableSet::InitDrawings(glop::Scene* scene)
{
  std::list< std::pair<glop::Drawable*,void (*) (glop::Drawable*)> >::iterator iter;

  is_init=true;
  for(iter=drawables.begin();
      iter!=drawables.end();
      ++iter)
    if(!(*iter).first->is_init)
      {
	(*iter).first->is_init=true;
	(*iter).first->SystemInitDrawings(scene);
      }
}

void glop::DrawableSet::AddDrawable(glop::Drawable* drawable,
				    void (*move)(glop::Drawable*))
{
  std::pair<glop::Drawable*,void (*) (glop::Drawable*)> info;
  
  info.first=drawable;
  info.second=move;
  drawables.push_back(info);
}

void glop::DrawableSet::AddLight(Light* light,void(*move)(glop::Drawable*))
{
  std::pair<glop::Drawable*,void (*) (glop::Drawable*)> info;
  
  // lights have to be set up before other objects. That's why they
  // are put in the front of the drawable list.
  info.first=light;
  info.second=move;
  drawables.push_front(info);
}

void glop::DrawableSet::ProcessSelection(std::map<GLuint,int>& name_rank)
{
  std::list< std::pair<glop::Drawable*,void (*) (glop::Drawable*)> >::iterator iter;

  for(iter=drawables.begin();
      iter!=drawables.end();
      ++iter)
    (*iter).first->ProcessSelection(name_rank);

  glop::Drawable::ProcessSelection(name_rank);
}
