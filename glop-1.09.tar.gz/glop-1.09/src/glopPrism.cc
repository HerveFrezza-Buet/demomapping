#include "glopPrism.h"
#include <iostream>

glop::Prism::Prism(void)
{
}

glop::Prism::~Prism(void) {
}

void glop::Prism::AddVertex(GLfloat x, GLfloat y)
{
  _points.push_back(x);
  _points.push_back(y);
}

void glop::Prism::DrawPrism(void) {
  std::list<GLfloat>::iterator iter;
  GLfloat x1,y1,x2,y2,x0,y0;

  if(_points.size()<4)
    {
      std::cerr << "Error : prism must be given at least two vertexes."
		<< std::endl;
      return;
    }

  glBegin(GL_POLYGON);
  glNormal3f(0,0,1);
  for(iter=_points.begin();iter!=_points.end();)
    {
      x1 = *iter; iter++;
      y1 = *iter; iter++;
      glVertex3f(x1,y1,0);
    }
  glEnd();

  glBegin(GL_POLYGON);
  glNormal3f(0,0,1);
  for(iter=_points.begin();iter!=_points.end();)
    {
      x1 = *iter; iter++;
      y1 = *iter; iter++;
      glVertex3f(x1,y1,1);
    }
  glEnd();

  iter = _points.begin();
  x1 = *iter; iter++;
  y1 = *iter; iter++;
  x0=x1;
  y0=y1;
  glBegin(GL_QUADS);
  for(;iter!=_points.end();
      x1 = x2,y1 = y2)
    {
      x2 = *iter; iter++;
      y2 = *iter; iter++;
      glNormal3f(y2-y1,x1-x2,0);
      glVertex3f(x1,y1,0);
      glVertex3f(x2,y2,0);
      glVertex3f(x2,y2,1);
      glVertex3f(x1,y1,1);
    }
  glNormal3f(y0-y1,x1-x0,0);
  glVertex3f(x1,y1,0);
  glVertex3f(x0,y0,0);
  glVertex3f(x0,y0,1);
  glVertex3f(x1,y1,1);
  
  glEnd();
}




