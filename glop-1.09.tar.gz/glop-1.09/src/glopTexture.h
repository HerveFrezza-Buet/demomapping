#ifndef glop_TEXTURE
#define glop_TEXTURE

#include <string>
#include <map>
#include <GL/gl.h>

namespace glop {

  /**
   * @short This class encapsulates management of a basic texture.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Texture {

  protected :
    
    /**
     * Texture identifier returned by openGL device.
     */
    GLuint texture_idf;

    /**
     * @short This gathers texture info.
     * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
     */
    class TexInfo {
    public:
      char* data; //!< The RGBA array of bytes.
      int size;   //!< The texture size.
    };

    /**
     * texture scale <=> info.
     */
    std::map<int,TexInfo> textures;

  public:

    Texture(void);
    virtual ~Texture(void);

    /**
     * This loads a texture. It can be done outside openGL context.
     * @param file_name A color ppm file (RGB).
     * @param size The size of the texture (128, 64, 32,...). Input image may be truncated or added with black areas to fit this size.
     * @param scale This is used is several resolution are defined for the texture. 0 is the most precise (big texture) one. Perform several loads to define different texture scales and improve rendering efficiency.
     */
    virtual void LoadTexturePPM(std::string file_name,
				int size,
				int scale=0);

    /**
     * Transfers previously loaded textures into openGL device. Use it
     * in some kind of glop::Drawable::InitDrawings method.
     */
    virtual void InitTexturing(void);
    
    /**
     * Starts the drawing of an object with the texture.
     */
    virtual void BeginTexturing(void);

    /**
     * Sops the drawing of an object with the texture.
     */
    virtual void EndTexturing(void);

    /**
     * Tells if the texture with scale number "scale" has been defined.
     */
    bool Exists(int scale);
    
    /**
     * Get texture size.
     * @param scale The number of an <b>existing</b> texture, see glop::Texture::Exists.
     */
    int Size(int scale);

    /**
     * Get texture image.  
     * @param scale The number of an <b>existing</b> texture, see glop::Texture::Exists.  
     * @return size*size*4 chars, 4 bytes for each pixels (r,g,b,a). This is the internal data.
     */
    char* Image(int scale);
  };

  /**
   * @short This class encapsulates management of a texture modulating existing color.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class TextureModulate : public Texture {
  public:
    virtual void BeginTexturing(void);
  };

  /**
   * @short This class manages openGL generated mappings. Default is spherical.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class TextureMap : public Texture {

  protected:

    /**
     * This is the kind of texture mapping, default is GL_SPHERE_MAP.
     */
    GLuint texture_mapping;

  public:
    
    TextureMap(GLuint mapping=GL_SPHERE_MAP);
    virtual void BeginTexturing(void);
    virtual void EndTexturing(void);
  };
}

#endif
