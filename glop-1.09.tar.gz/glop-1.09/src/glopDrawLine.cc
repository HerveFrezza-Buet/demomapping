#include "glopDrawLine.h"
#include <iostream>

////////////////////////////////////////////////////////////////
//
// function pointer
//
////////////////////////////////////////////////////////////////

// # : not defined out of bound
// x : empty cell
// O : set cell

//
//  x....x      #....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  x....x      #....#
//
void glop::DrawLine0000(const glop::DrawInfo& draw_info){
  // no operations here
}


//
//  x....x      #....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  O....x      O....#
//
void glop::DrawLine0001(const glop::DrawInfo& draw_info){
  // just one point
  glBegin(GL_POINT);
  DrawVertex(draw_info, 0);
  glEnd();
}


//
//  x....x      #....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  x....O      #....O
//
void glop::DrawLine0010(const glop::DrawInfo& draw_info){
  // no operations here
}

//  
//  #....#
//  .    .
//  .    .
//  .    .
//  .    .
//  O----O
//
void glop::DrawLine0011(const glop::DrawInfo& draw_info){
  glBegin(GL_LINES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  glEnd();
}


//
//  #....O
//  .    .
//  .    .
//  .    .
//  .    .
//  #....#
//
void glop::DrawLine0100(const glop::DrawInfo& draw_info){
  // no operations here
	
}

//  0101 no x1x1 possible because of square map
//  x....O
//  .    .
//  .    .
//  .    .
//  .    .
//  O....x
//
void glop::DrawLine0101(const glop::DrawInfo& draw_info){
  glBegin(GL_POINT);
  DrawVertex(draw_info, 0);
  glEnd();
}

//  0110,  x11x doesn't exists the drawing begin at (0,0) not (-1,-1)!
//  x....O
//  .    .
//  .    .
//  .    . 
//  .    .
//  x....O
//
void glop::DrawLine0110(const glop::DrawInfo& draw_info){
  // no operations here
}

//
//  x....O
//  .   /.
//  .  / .
//  . /  .
//  ./   .
//  O----O
//
void glop::DrawLine0111(const glop::DrawInfo& draw_info){
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 2);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  glEnd();
}

//
//  O....x      O....#
//  .    .      .    .
//  .    .  or  .    .
//  .    .      .    .
//  .    .      .    .
//  x....x      #....#
//
void glop::DrawLine1000(const glop::DrawInfo& draw_info){
  // no operations here
}

//
//  O....x      O....#
//  |    .      |    .
//  |    .  or  |    .
//  |    .      |    .
//  |    .      |    .
//  O....x      O....#
//
void glop::DrawLine1001(const glop::DrawInfo& draw_info){
  glBegin(GL_LINES);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 3);
  glEnd();
}

//
//  O....x
//  .    .
//  .    .
//  .    .
//  .    .
//  x....O
//
void glop::DrawLine1010(const glop::DrawInfo& draw_info){
  // no operations here
}

//
//  O....x
//  |\   .
//  | \  .
//  |  \ .
//  |   \.
//  O----O
//
void glop::DrawLine1011(const glop::DrawInfo& draw_info){
  glBegin(GL_LINE_LOOP);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  DrawVertex(draw_info, 3);
  glEnd();
}

//
//  O....O
//  .    . 
//  .    .
//  .    .
//  .    .
//  #....#
//
void glop::DrawLine1100(const glop::DrawInfo& draw_info){
  // no operations here
}

//
//  O....O
//  |   /.
//  |  / .
//  | /  .
//  |/   .
//  O....x
//
void glop::DrawLine1101(const glop::DrawInfo& draw_info){
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 3);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 2);
  glEnd();
}


//
//  O....O
//  .\   .
//  . \  .
//  .  \ .
//  .   \.
//  x....O
//
void glop::DrawLine1110(const glop::DrawInfo& draw_info){
  glBegin(GL_LINES);
  DrawVertex(draw_info, 3);
  DrawVertex(draw_info, 1);
  glEnd();
}


//
//  O....O
//  |    .
//  |    .
//  |    .
//  |    .
//  O----O
//
void glop::DrawLine1111(const glop::DrawInfo& draw_info){
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 3);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  glEnd();
}

//  10101 no x1x1 possible because of square map
//  x....O
//  .   /.
//  .  / .
//  . /  .
//  ./   .
//  O....x
//
void glop::DrawLineSpecial01(const glop::DrawInfo& draw_info){
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 2);
  glEnd();
}

//
//  O....x
//  .\   .
//  . \  .
//  .  \ .
//  .   \.
//  x....O
//
void glop::DrawLineSpecial02(const DrawInfo& draw_info) {
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 1);
  DrawVertex(draw_info, 3);
  glEnd();
}

//
//  O....x
//  |\   .
//  | \  .
//  |  \ .
//  |   \.
//  x....O
//
void glop::DrawLineSpecial03(const DrawInfo& draw_info) {
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 3);
  DrawVertex(draw_info, 1);
  glEnd();
}

//
//  O....x
//  .\   .
//  . \  .
//  .  \ .
//  .   \.
//  x----O
//
void glop::DrawLineSpecial04(const DrawInfo& draw_info){
  glBegin(GL_LINE_STRIP);
  DrawVertex(draw_info, 0);
  DrawVertex(draw_info, 1);
  DrawVertex(draw_info, 3);
  glEnd();
}

glop::LineFunctionSelector::~LineFunctionSelector(void){}

glop::LineFunctionSelector::LineFunctionSelector(void){
  _polygon_mode = GL_LINE;

  _draw[0]  = DrawLine0000;
  _draw[1]  = DrawLine0001;
  _draw[2]  = DrawLine0010;
  _draw[3]  = DrawLine0011;

  _draw[4]  = DrawLine0100;
  _draw[5]  = DrawLine0101;
  _draw[6]  = DrawLine0110;
  _draw[7]  = DrawLine0111;

  _draw[8]  = DrawLine1000;
  _draw[9]  = DrawLine1001;
  _draw[10] = DrawLine1010;
  _draw[11] = DrawLine1011;

  _draw[12] = DrawLine1100;
  _draw[13] = DrawLine1101;
  _draw[14] = DrawLine1110;
  _draw[15] = DrawLine1111;

  _draw[16] = DrawLineSpecial01;
  _draw[17] = DrawLineSpecial02;
  _draw[18] = DrawLineSpecial03;
  _draw[19] = DrawLineSpecial04;

  _normal[0]  = Normal0000;
  _normal[1]  = Normal0001;
  _normal[2]  = Normal0010;
  _normal[3]  = Normal0011;

  _normal[4]  = Normal0100;
  _normal[5]  = Normal0101;
  _normal[6]  = Normal0110;
  _normal[7]  = Normal0111;

  _normal[8]  = Normal1000;
  _normal[9]  = Normal1001;
  _normal[10] = Normal1010;
  _normal[11] = Normal1011;

  _normal[12] = Normal1100;
  _normal[13] = Normal1101;
  _normal[14] = Normal1110;
  _normal[15] = Normal1111;

}

glop::DrawFunction glop::LineFunctionSelector::GetDraw(glop::DrawMask mask,
						       bool left_side,
						       bool down_side,
						       bool hole_left_up,
						       bool hole_left_down,
						       bool hole_corner,
						       bool hole_down_left,
						       bool hole_down_right) {
  
  DrawMask corrected_mask;

  // we have to change the mask, checking if an edge has actually to
  // be done, since grid isn't drawn systematically where it could
  // exist.

  // # : not defined out of bound
  // x : empty cell
  // O : set cell
  
  corrected_mask=mask;

  switch(mask) {
  case  0:
    //
    //  x....x      #....#
    //  .    .      .    .
    //  .    .  or  .    .
    //  .    .      .    .
    //  .    .      .    .
    //  x....x      #....#
    //
    break;
  case  1:
    //
    //  x....x      #....#
    //  .    .      .    .
    //  .    .  or  .    .
    //  .    .      .    .
    //  .    .      .    .
    //  O....x      O....#
    //
    break;
  case  2:
    //
    //  x....x      #....#
    //  .    .      .    .
    //  .    .  or  .    .
    //  .    .      .    .
    //  .    .      .    .
    //  x....O      #....O
    //
    break;
  case  3:
    //  
    //  #....#
    //  .    .
    //  .    .
    //  .    .
    //  .    .
    //  O----O
    //
  case  4:
    //
    //  #....O
    //  .    .
    //  .    .
    //  .    .
    //  .    .
    //  #....#
    //
    break;
  case  5:
    //  0101 no x1x1 possible because of square map
    //  x....O
    //  .    .
    //  .    .
    //  .    .
    //  .    .
    //  O....x
    //
    break;
  case  6:
    //  0110,  x11x doesn't exists the drawing begin at (0,0) not (-1,-1)!
    //  x....O
    //  .    .
    //  .    .
    //  .    . 
    //  .    .
    //  x....O
    //
    break;
  case  7:
    //
    //  x....O
    //  .   /.
    //  .  / .
    //  . /  .
    //  ./   .
    //  O----O
    //
    if(!down_side)
      corrected_mask=glop::special01;
    break;
  case  8:
    //
    //  O....x      O....#
    //  .    .      .    .
    //  .    .  or  .    .
    //  .    .      .    .
    //  .    .      .    .
    //  x....x      #....#
    //
    break;
  case  9:
    //
    //  O....x      O....#
    //  |    .      |    .
    //  |    .  or  |    .
    //  |    .      |    .
    //  |    .      |    .
    //  O....x      O....#
    //
    break;
  case 10:
    //
    //  O....x
    //  .    .
    //  .    .
    //  .    .
    //  .    .
    //  x....O
    //
    break;
  case 11:
    //
    //  O....x
    //  |\   .
    //  | \  .
    //  |  \ .
    //  |   \.
    //  O----O
    //
    if(left_side) 
      if(down_side) 
	{}
      else
	corrected_mask = glop::special03;
    else
      if(down_side) 
	corrected_mask = glop::special04;
      else
	corrected_mask = glop::special02;
    break;
  case 12:
    break;
  case 13:
    //
    //  O....O
    //  |   /.
    //  |  / .
    //  | /  .
    //  |/   .
    //  O....x
    //
    if(!left_side) 
      corrected_mask = glop::special01;
    break;
  case 14:
    //
    //  O....O
    //  .\   .
    //  . \  .
    //  .  \ .
    //  .   \.
    //  x....O
    //
    break;
  case 15:
    //
    //  O....O
    //  |    .
    //  |    .
    //  |    .
    //  |    .
    //  O----O
    //
    if(left_side) 
      if(down_side) 
	{}
      else {
	if(!(hole_down_left && hole_down_right))
	  corrected_mask = glop::vertexNone
	    | glop::vertexV0
	    | glop::vertexV3;
      }
    else
      if(down_side) {
	if(!(hole_left_up && hole_left_down))
	  corrected_mask = glop::vertexNone
	    | glop::vertexV0
	    | glop::vertexV1;
      }
      else {
	corrected_mask = glop::vertexNone;
 	if(hole_down_left && hole_down_right)
 	  corrected_mask |= glop::vertexV0 | glop::vertexV1;
	if(hole_left_up && hole_left_down)
	  corrected_mask |= glop::vertexV0 | glop::vertexV3;
	if(hole_down_left && hole_down_right && hole_left_up && hole_left_down)
	  corrected_mask |= glop::vertexV2;
      }

    break;
  default:
    break;
  }
  
  return glop::FunctionSelectorSquareEval::GetDraw(corrected_mask,
						   true,true,true,true,true,true,true); // useless booleans.
  
}
