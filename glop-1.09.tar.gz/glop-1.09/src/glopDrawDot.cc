#include "glopDrawDot.h"


////////////////////////////////////////////////////////////////
//
// function pointer
//
////////////////////////////////////////////////////////////////

// ? : this cell doesn't play any role in pattern computation
// x : empty cell
// O : set cell

//
//  ?....?
//  .    .
//  .    .
//  .    .
//  .    .
//  x....?
//
void glop::DrawDot0000(const glop::DrawInfo& draw_info){
  // no operations here
}


//
//  ?....?
//  .    .
//  .    .
//  .    .
//  .    .
//  O....?
//
void glop::DrawDot0001(const glop::DrawInfo& draw_info){
  // just one point
  glBegin(GL_POINT);
  DrawVertex(draw_info, 0);
  glEnd();
}





glop::DotFunctionSelector::~DotFunctionSelector(void){}

glop::DotFunctionSelector::DotFunctionSelector(void){
  _polygon_mode = GL_FILL;

  _draw[0]  = DrawDot0000;
  _draw[1]  = DrawDot0001;
  _draw[2]  = DrawDot0000;
  _draw[3]  = DrawDot0001;

  _draw[4]  = DrawDot0000;
  _draw[5]  = DrawDot0001;
  _draw[6]  = DrawDot0000;
  _draw[7]  = DrawDot0001;

  _draw[8]  = DrawDot0000;
  _draw[9]  = DrawDot0001;
  _draw[10] = DrawDot0000;
  _draw[11] = DrawDot0001;

  _draw[12] = DrawDot0000;
  _draw[13] = DrawDot0001;
  _draw[14] = DrawDot0000;
  _draw[15] = DrawDot0001;

  _normal[0]  = Normal0000;
  _normal[1]  = Normal0001;
  _normal[2]  = Normal0010;
  _normal[3]  = Normal0011;

  _normal[4]  = Normal0100;
  _normal[5]  = Normal0101;
  _normal[6]  = Normal0110;
  _normal[7]  = Normal0111;

  _normal[8]  = Normal1000;
  _normal[9]  = Normal1001;
  _normal[10] = Normal1010;
  _normal[11] = Normal1011;

  _normal[12] = Normal1100;
  _normal[13] = Normal1101;
  _normal[14] = Normal1110;
  _normal[15] = Normal1111;
}
