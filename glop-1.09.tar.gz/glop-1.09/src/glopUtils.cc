#include "glopUtils.h"
#include "glopScene.h"
#include <math.h>
#include <stdlib.h>


/* ################## */
/* #                # */
/* # Default camera # */
/* #                # */
/* ################## */

#define glop_DefaultCamera_WIDTH .1
#define glop_DefaultCamera_FOCAL .15
void glop::DefaultCamera::SetProjection(int width,int height)
{  
  Coord w,h; // Image size in 3D world units.
  
  w=glop_DefaultCamera_WIDTH;
  h=height*glop_DefaultCamera_WIDTH/(Coord)width;

  /*
    This places the camera at 0,0,0, looking toward negative Z. The
    center of the window is at (0,0,0).

    glFrustum(l,r,b,t,n,f) makes 3D point (l,b,-n) be on the left
    bottom point of the view, and r,t,-n be on right top. 
  
  */

  glFrustum(-w*.5,w*.5,                      // camera window left and right bounds.
	    -h*.5,h*.5,                      // camera window bottom and up bounds.
	    glop_DefaultCamera_FOCAL,        // distance of the focal point to the camera window.
	    100.0);                          // Limit of "far" clipping plane.
}

void glop::DefaultCamera::MoveToOrigin(void)
{
  // Nothing to do.
}

glop::Coord glop::DefaultCamera::Focal(void)
{
  return glop_DefaultCamera_FOCAL;
}




/* ############### */
/* #             # */
/* # Direct view # */
/* #             # */
/* ############### */


glop::DirectInteractiveView::DirectInteractiveView(void)
  :MouseEvent()
{
}

void glop::DirectInteractiveView::Click(glop::Scene* scene,
					glop::Button b,
					int w,int h)
{
  scene->GetView(x,y,z,rx,ry,rz);
}

#define glopDIRECT_IV_DIST_COEF .005
#define glopDIRECT_IV_ROT_COEF  .05

void glop::DirectInteractiveView::Motion(glop::Scene* scene,
					 glop::Button b,
					 int w,int h,
					 int dw,int dh,
					 int ddw,int ddh)
{
  switch(b)
    {
    case buttonLeft:
      scene->SetView(x,
		     y,
		     z,
		     rx+dw*glopDIRECT_IV_ROT_COEF,
		     ry+(-dh)*glopDIRECT_IV_ROT_COEF,
		     rz);
      break;
    case buttonMiddle:
      scene->SetView(x,
			 y,
			 z+(-dh)*glopDIRECT_IV_DIST_COEF,
			 rx,
			 ry,
			 rz+dw*glopDIRECT_IV_ROT_COEF);
      break;
    case buttonRight:
      scene->SetView(x+dw*glopDIRECT_IV_DIST_COEF,
			 y+(-dh)*glopDIRECT_IV_DIST_COEF,
			 z,
			 rx,
			 ry,
			 rz);
      break;
    default:
      break;
    }
}
      



/* ############## */
/* #            # */
/* # Orbit view # */
/* #            # */
/* ############## */

glop::OrbitInteractiveView::OrbitInteractiveView(void)
  :MouseEvent()
{
}

void glop::OrbitInteractiveView::Click(glop::Scene* scene,
				       glop::Button b,
				       int w,int h)
{
  Coord x,y,z,dummy;

  switch(b)
    {
    case buttonLeft:
      // We save initial values.
      scene->GetView(x,y,z,dummy,dummy,dummy);
      radius=sqrt(x*x+y*y+z*z);
      break;
    case buttonRight:
      break;
    case buttonMiddle:
      break;
    default:
      break;
    }  
  
}

#define glop_ORBIT_IV_ZOOM_COEF 1.05
#define glop_ORBIT_IV_ROT_COEF  .1

void glop::OrbitInteractiveView::Motion(glop::Scene* scene,
					glop::Button b,
					int w,int h,
					int dw,int dh,
					int ddw,int ddh)
{
  Coord
    Wx,Wy,Wz,
    Hx,Hy,Hz,
    Kx,Ky,Kz,
    x,y,z,
    rx,ry,rz;

  double coef;
  double zoom_factor;

  scene->GetView(x,y,z,
		 rx,ry,rz);
  scene->GetLocalAxes(Wx,Wy,Wz,
		      Hx,Hy,Hz,
		      Kx,Ky,Kz);
  switch(b)
    {
    case buttonLeft:

      x += (-ddw*Wx + ddh*Hx)*glop_ORBIT_IV_ROT_COEF;
      y += (-ddw*Wy + ddh*Hy)*glop_ORBIT_IV_ROT_COEF;
      z += (-ddw*Wz + ddh*Hz)*glop_ORBIT_IV_ROT_COEF;
      
      coef=sqrt(x*x+y*y+z*z);
      if(coef==0)
	coef=.0000001;
      coef=radius/coef;
      x*=coef;
      y*=coef;
      z*=coef;
      
      scene->SetView(x,y,z,
		     0,0,0);
      scene->LookAt(0,0,0,
		    Hx,Hy,Hz);
      

      break;

    case buttonRight:

      if(ddw>0)
	zoom_factor=glop_ORBIT_IV_ZOOM_COEF;
      else if(ddw<0)
	zoom_factor=1/glop_ORBIT_IV_ZOOM_COEF;
      else
	zoom_factor=1;

      scene->SetView(x*zoom_factor,
		     y*zoom_factor,
		     z*zoom_factor,
		     0,0,0);
      scene->LookAt(0,0,0,
		    Hx,Hy,Hz);
      break;

    case buttonMiddle:

      scene->SetView(x,y,z,
		     rx,ry,rz
		     +(ddw-ddh)*glop_ORBIT_IV_ROT_COEF);

      // Useless, but updates last look at
      scene->GetLocalAxes(Wx,Wy,Wz,
			  Hx,Hy,Hz,
			  Kx,Ky,Kz);
      scene->LookAt(0,0,0,
		    Hx,Hy,Hz);
      break;

    default:
      break;
    }
  
}



/* ############### */
/* #             # */
/* # Flight view # */
/* #             # */
/* ############### */


glop::FlightInteractiveView::FlightInteractiveView(void)
  :glop::MouseEvent(),glop::TimeEvent()
{
  SetNbSamples(10);
  SetSpeed(.5);
  SetAcceleration(.01);
}

void glop::FlightInteractiveView::SetNbSamples(int nb)
{
  nb_samples=nb;
}

void glop::FlightInteractiveView::SetSpeed(double s)
{
  speed=s;
}

void glop::FlightInteractiveView::SetAcceleration(double a)
{
  accel=a;
}

void glop::FlightInteractiveView::Click(glop::Scene* scene,	
					glop::Button b,
					int x,int y)
{
  int w,h;
  double max;

  scene->GetImageSize(w,h);
  if(w>h)
    max=w;
  else
    max=h;

  dw=2*accel*(x-w/2)/max/nb_samples;
  dh=2*accel*(h/2-y)/max/nb_samples;
  dk=speed/(double)nb_samples;

  
  switch(b)
    {
    default:
    case glop::buttonNone:
    case glop::buttonRight:
      fly=false;
      break;
      
    case glop::buttonMiddle:
      fly=true;
      use_accel=false;
      break;
      
    case glop::buttonLeft:
      fly=true;
      use_accel=true;
      break;
    }
}

void glop::FlightInteractiveView::Motion(glop::Scene* scene,
					 glop::Button b,
					 int x,int y,
					 int dx,int dy,
					 int ddx,int ddy)
{
}

void glop::FlightInteractiveView::Time(glop::Scene* scene)
{
  Coord xi,yi,zi,
    xf,yf,zf,
    Wx,Wy,Wz,
    Hx,Hy,Hz,
    Kx,Ky,Kz,
    dummy;

  Coord rx,ry,rz;
    
  if(fly)
    {
      
      scene->GetView(xi,yi,zi,
		     rx,ry,rz);
      
      scene->GetLocalAxes(Wx,Wy,Wz,
			  Hx,Hy,Hz,
			  Kx,Ky,Kz);

      if(use_accel)
	{
	  xf = xi + dw*Wx + dh*Hx + dk*Kx;
	  yf = yi + dw*Wy + dh*Hy + dk*Ky;
	  zf = zi + dw*Wz + dh*Hz + dk*Kz;

	  scene->LookAt(xf,yf,zf,
			Hx,Hy,Hz);
	  scene->GetView(dummy,dummy,dummy,
			 rx,ry,rz);
	  scene->SetView(xf,yf,zf,
			 rx,ry,rz);
	}
      else
	{
	  xf = xi + dk*Kx;
	  yf = yi + dk*Ky;
	  zf = zi + dk*Kz;
	  
	  rz+=dw*nb_samples*180;
	  scene->SetView(xf,yf,zf,
			 rx,ry,rz);
	}
      
    }
}

/* ################# */
/* #               # */
/* # Selector view # */
/* #               # */
/* ################# */


glop::SelectorInteractiveView::SelectorInteractiveView(glop::MouseEvent* iv)
  :glop::MouseEvent()
{
  event=iv;
  selection=false;
}

void glop::SelectorInteractiveView::SetSelectionMode(bool select)
{
  selection=select;
}

void glop::SelectorInteractiveView::Click(glop::Scene* scene,
					  glop::Button b,
					  int w,int h)
{
  if(selection)
    {
      if(b==glop::buttonLeft)
	scene->Select(w,h);
    }
  else
    event->Click(scene,b,w,h);
}

void glop::SelectorInteractiveView::Motion(glop::Scene* scene,
					 glop::Button b,
					 int w,int h,
					 int dw,int dh,
					 int ddw,int ddh)
{
  if(!selection)
    event->Motion(scene,b,w,h,dw,dh,ddw,ddh);
}
      



/* ################### */
/* #                 # */
/* # Direction light # */
/* #                 # */
/* ################### */


glop::DirectionLight::DirectionLight(GLuint device_channel,
				     GLfloat x,GLfloat y,GLfloat z,
				     GLfloat r,GLfloat g,GLfloat b)
  :Light(device_channel)
{
  diffuse[0]=r;
  diffuse[1]=g;
  diffuse[2]=b;
  diffuse[3]=1;

  position[0]=x;
  position[1]=y;
  position[2]=z;
  position[3]=0;

}


/* ############### */
/* #             # */
/* # Point light # */
/* #             # */
/* ############### */


glop::PointLight::PointLight(GLuint device_channel,
			     GLfloat x,GLfloat y,GLfloat z,
			     GLfloat r,GLfloat g,GLfloat b)
  :Light(device_channel)
{
  diffuse[0]=r;
  diffuse[1]=g;
  diffuse[2]=b;
  diffuse[3]=1;

  position[0]=x;
  position[1]=y;
  position[2]=z;
  position[3]=1;

}


/* ############## */
/* #            # */
/* # Spot light # */
/* #            # */
/* ############## */


glop::SpotLight::SpotLight(GLuint device_channel,
			     GLfloat x,GLfloat y,GLfloat z,
			     GLfloat nx,GLfloat ny,GLfloat nz,
			     GLfloat r,GLfloat g,GLfloat b,
			     GLfloat cutoff,GLfloat exponent)
  :Light(device_channel)
{
  diffuse[0]=r;
  diffuse[1]=g;
  diffuse[2]=b;
  diffuse[3]=1;

  position[0]=x;
  position[1]=y;
  position[2]=z;
  position[3]=1;

  direction[0]=nx;
  direction[1]=ny;
  direction[2]=nz;
  direction[3]=1;

  spot_cutoff=cutoff;
  spot_exponent=exponent;

}


/* ################## */
/* #                # */
/* # Depth of field # */
/* #                # */
/* ################## */


glop::DepthOfField::DepthOfField(void)
  :glop::DrawableSet()
{
  SetNbTries(10);
  SetFocus(5);
  SetJitter(3);
  ShowFocusPoint(false);
}

glop::DepthOfField::~DepthOfField(void)
{
}

void glop::DepthOfField::ShowFocusPoint(bool is_shown)
{
  show_focus=is_shown;
}

void glop::DepthOfField::SetNbTries(int n)
{
  nb_tries=n;
}

void glop::DepthOfField::SetFocus(double d)
{
  focus=d;
}

void glop::DepthOfField::SetJitter(double j)
{
  jitter=j;
}

void glop::DepthOfField::DrawFocus(glop::Coord x,glop::Coord y,glop::Coord z)
{
  GLboolean is_lighting;
  
  if(show_focus)
    {
      is_lighting=glIsEnabled(GL_LIGHTING);
      glDisable(GL_LIGHTING);
      
      glPolygonMode(GL_FRONT_AND_BACK,
		    GL_FILL); 
      glColor3f(1,1,1);
      glBegin(GL_POLYGON);
      glVertex3f(x,y,z);
      glVertex3f(x+.2,y,z);
      glVertex3f(x,y+.2,z);
      glEnd();
      
      if(is_lighting==GL_TRUE)
	glEnable(GL_LIGHTING);
    }
}

void glop::DepthOfField::Draw(glop::Scene* scene)
{
  double coef;
  int n;
  Coord x_rot,y_rot,z_rot;
  Coord focus_x,focus_y,focus_z;
  Coord ux,uy,uz,x,y,z,dummy;


  // We have to draw the list many times, with a different rotations
  // of the object.

  // We compute focus point from camera position.
  scene->GetView(x,y,z,
		 dummy,dummy,dummy);
  scene->GetLocalAxes(dummy,dummy,dummy,
		      dummy,dummy,dummy,
		      ux,uy,uz);

  
  focus_x=x+focus*ux;
  focus_y=y+focus*uy;
  focus_z=z+focus*uz;


  // We will add nb_tries images in accumulation buffer,
  // and the non jittered one.
  coef=1/(1+(double)nb_tries);
  
  // This sets accumulation buffer to coef*image.
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
  DrawFocus(focus_x,focus_y,focus_z);
  DrawContents(scene);
  glAccum(GL_LOAD,coef); // Accum = read_buffer*coef


  // We rotate the scene around the focus point with random angles.
  for(n=0;n<nb_tries;n++)
    {
      glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
      DrawFocus(focus_x,focus_y,focus_z);
      
      x_rot = jitter*(2*rand()/(1.0+RAND_MAX)-1);
      y_rot = jitter*(2*rand()/(1.0+RAND_MAX)-1);
      z_rot = jitter*(2*rand()/(1.0+RAND_MAX)-1);
      
      // We move the scene
      glPushMatrix();
      glTranslatef(focus_x,focus_y,focus_z);
      glRotatef(x_rot,1,0,0);
      glRotatef(y_rot,0,1,0);
      glRotatef(z_rot,0,0,1);
      glTranslatef(-focus_x,-focus_y,-focus_z);

      // We set accumulation
      DrawContents(scene);  
      glAccum(GL_ACCUM,coef); // Accum += read_buffer*coef

      // We restore reference position.
      glPopMatrix();
    }

  // We make the accumulation buffer be the frame buffer
  glAccum(GL_RETURN,1.0);
  
}

