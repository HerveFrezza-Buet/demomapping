#ifndef glop_DRAW_FILL
#define glop_DRAW_FILL

#include <GL/gl.h>
#include "glopDraw.h"



namespace glop{

  ////////////////////////////////////////////////////////////////
  //
  // function pointer
  //
  ////////////////////////////////////////////////////////////////

  // # : not defined out of bound
  // x : empty cell
  // O : set cell

  //
  //  x....x      #....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  x....x      #....#
  //
  void DrawFill0000(const DrawInfo& draw_info);


  //
  //  x....x      #....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  O....x      O....#
  //
  void DrawFill0001(const DrawInfo& draw_info);


  //
  //  x....x      #....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  x....O      #....O
  //
  void DrawFill0010(const DrawInfo& draw_info);

  //  
  //  #....#
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  O----O
  //
  void DrawFill0011(const DrawInfo& draw_info);


  //
  //  #....O
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  #....#
  //
  void DrawFill0100(const DrawInfo& draw_info);


  //  0101 no x1x1 possible because of square map
  //  x....O
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  O....x
  //
  void DrawFill0101(const DrawInfo& draw_info);


  //  0110,  x11x doesn't exists the drawing begin at (0,0) not (-1,-1)!
  //  x....O
  //  .    .
  //  .    .
  //  .    . 
  //  .    .
  //  x....O
  //
  void DrawFill0110(const DrawInfo& draw_info);


  //
  //  x....O
  //  .   /|
  //  .  / |
  //  . /  |
  //  ./   |
  //  O----O
  //
  void DrawFill0111(const DrawInfo& draw_info);


  //
  //  O....x      O....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  x....x      #....#
  //
  void DrawFill1000(const DrawInfo& draw_info);


  //
  //  O....x      O....#
  //  |    .      |    .
  //  |    .  or  |    .
  //  |    .      |    .
  //  |    .      |    .
  //  O....x      O....#
  //
  void DrawFill1001(const DrawInfo& draw_info);


  //
  //  O....x
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  x....O
  //
  void DrawFill1010(const DrawInfo& draw_info);


  //
  //  O....x
  //  |\   .
  //  | \  .
  //  |  \ .
  //  |   \.
  //  O----O
  //
  void DrawFill1011(const DrawInfo& draw_info);


  //
  //  O----O
  //  .    . 
  //  .    .
  //  .    .
  //  .    .
  //  #....#
  //
  void DrawFill1100(const DrawInfo& draw_info);


  //
  //  O----O
  //  |   /.
  //  |  / .
  //  | /  .
  //  |/   .
  //  O....x
  //
  void DrawFill1101(const DrawInfo& draw_info);


  //
  //  O----O
  //  .\   |
  //  . \  |
  //  .  \ |
  //  .   \|
  //  x....O
  //
  void DrawFill1110(const DrawInfo& draw_info);


  //
  //  O----O
  //  |\   |
  //  | \  |
  //  |  \ |
  //  |   \|
  //  O----O
  //
  void DrawFill1111(const DrawInfo& draw_info);


  //
  // filled area function selector
  //


  class FillFunctionSelector:public FunctionSelectorSquareEval{
  public:
    FillFunctionSelector(void);

    virtual ~FillFunctionSelector(void);
  };

}
#endif
