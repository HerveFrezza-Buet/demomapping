#ifndef glop_CAMERA
#define glop_CAMERA

#include <glopCommon.h>

namespace glop {

  class Scene;

  /**
   * @short This class manages the camera, i.e the mapping of the 3D scene to the 2D screen.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Camera {
    
  private :


  protected :

    /**
     * Sets projection view matrix. Don't call glMatrixMode, neither glLoadIdentity.
     * @param width,height size of viewing window (viewport) in pixels.
     */
    virtual void SetProjection(int width,int height)=0;

    /**
     * Move <b>The scene</b> to be such has the camera is placed at
     * 0,0,0, without rotation (looking toward negative Z, thus seing
     * X,Y as a direct coordinate system, with positive X to the right
     * and positive Y up. Positive Z point to you. That means : "put the whole scene in front
     * of the camera". Don't call glMatrixMode, neither
     * glLoadIdentity.
     */
    virtual void MoveToOrigin(void)=0;

    /**
     * Gets the distance from point of view and the camera glass. 
     */
    virtual Coord Focal(void)=0;

    friend class Scene; 

  public :

    Camera(void);
    virtual ~Camera(void);

  };

}


#endif
