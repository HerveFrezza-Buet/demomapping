#ifndef glop_DRAW_DOT
#define glop_DRAW_DOT

#include <GL/gl.h>
#include "glopDraw.h"


namespace glop{
  ////////////////////////////////////////////////////////////////
  //
  // function pointer
  //
  ////////////////////////////////////////////////////////////////

  // ? : this cell doesn't play any role in pattern computation
  // x : empty cell
  // O : set cell

  //
  //  ?....?
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  x....?
  //

  void DrawDot0000(const DrawInfo& draw_info);


  //
  //  ?....?
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  O....?
  //
  void DrawDot0001(const DrawInfo& draw_info);


  //
  // filled area function selector
  //


  class DotFunctionSelector:public FunctionSelectorSquareEval{
  public:
    DotFunctionSelector(void);

    virtual ~DotFunctionSelector(void);
  };
}
#endif
