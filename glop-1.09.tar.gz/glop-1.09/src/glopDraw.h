#ifndef glop_DRAW
#define glop_DRAW

#include "glopNormal.h"

namespace glop{
  typedef unsigned int DrawMask;

  enum VertexMask{
    vertexNone = 0,
    vertexV0   = 1 << 0,
    vertexV1   = 1 << 1,
    vertexV2   = 1 << 2,
    vertexV3   = 1 << 3,
    special01  = 16,
    special02  = 17,
    special03  = 18,
    special04  = 19,
    vertexNbMask = 20
  };

  class DrawInfo{
  public:
    GLfloat* x;
    GLfloat* y; 
    GLfloat* z;

    bool IsNormalModeSet(void) const{
      return _is_normal_mode_set;
    }

    GLfloat* nx; 
    GLfloat* ny; 
    GLfloat* nz;

    bool IsHueModeSet(void) const{
      return _is_hue_mode_set;
    }

    GLfloat* r; 
    GLfloat* g; 
    GLfloat* b;
    GLfloat* a;
  
    DrawInfo(unsigned size,bool is_normal_mode_set,bool  is_hue_mode_set);
  private:

    bool _is_normal_mode_set;

    bool _is_hue_mode_set;
  };

  inline void DrawVertex(const DrawInfo& draw_info, unsigned vertex_number){
    if (draw_info.IsNormalModeSet()) 
      glNormal3f(draw_info.nx[vertex_number], 
		 draw_info.ny[vertex_number], 
		 draw_info.nz[vertex_number]);     

    if (draw_info.IsHueModeSet()) {
      glColor4f(draw_info.r[vertex_number], 
		draw_info.g[vertex_number], 
		draw_info.b[vertex_number], 
		draw_info.a[vertex_number]);
    }

    glVertex3f(draw_info.x[vertex_number], 
	       draw_info.y[vertex_number], 
	       draw_info.z[vertex_number]);
  }


  typedef void (*DrawFunction)(const DrawInfo& draw_info);


  class AbstractFunctionSelector{
  public:
    virtual ~AbstractFunctionSelector(void) {}
    virtual DrawFunction GetDraw(DrawMask mask,
				 bool left_side,
				 bool down_side,
				 bool hole_left_up,
				 bool hole_left_down,
				 bool hole_corner,
				 bool hole_down_left,
				 bool hole_down_right)=0;
    virtual NormalFunction GetNormal(NormalMask mask)=0;
    GLenum GetPolygonMode(void){
      return _polygon_mode;
    }
  protected:
    GLenum _polygon_mode;
  };

  class FunctionSelectorSquareEval:public AbstractFunctionSelector{
  public: 

    virtual ~FunctionSelectorSquareEval(void) {}
    virtual DrawFunction GetDraw(DrawMask mask,
				 bool left_side,
				 bool down_side,
				 bool hole_left_up,
				 bool hole_left_down,
				 bool hole_corner,
				 bool hole_down_left,
				 bool hole_down_right){
      return _draw[mask];
    }
    virtual NormalFunction GetNormal(NormalMask mask){
      return _normal[mask];
    };
    GLenum GetPolygonMode(void){
      return _polygon_mode;
    }
  protected:
    GLenum _polygon_mode;
    DrawFunction   _draw[vertexNbMask];
    NormalFunction _normal[vertexNbMask];
  };
}
#endif
