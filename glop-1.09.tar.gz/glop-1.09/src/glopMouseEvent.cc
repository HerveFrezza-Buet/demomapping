#include "glopMouseEvent.h"


void glop::MouseEventSet::Click(glop::Scene* scene,
				glop::Button b,
				int x,int y)
{
  std::list<MouseEvent*>::iterator iter;
  
  for(iter=mouse_events.begin();
      iter!=mouse_events.end();
      ++iter)
    (*iter)->Click(scene,b,x,y);
}

void glop::MouseEventSet::Motion(glop::Scene* scene,
				 glop::Button b,
				 int x,int y,
				 int dx,int dy,
				 int ddx,int ddy)
{
  std::list<MouseEvent*>::iterator iter;
  
  for(iter=mouse_events.begin();
      iter!=mouse_events.end();
      ++iter)
    (*iter)->Motion(scene,b,x,y,dx,dy,ddx,ddy);
}

void glop::MouseEventSet::AddMouseEvent(glop::MouseEvent* event)
{
  mouse_events.push_back(event);
}
