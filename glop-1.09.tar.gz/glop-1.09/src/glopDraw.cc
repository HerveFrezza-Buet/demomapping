#include "glopDraw.h"

glop::DrawInfo::DrawInfo(unsigned size,bool is_normal_mode_set,bool is_hue_mode_set){
  x = new GLfloat[size];
  y = new GLfloat[size];
  z = new GLfloat[size];

  _is_normal_mode_set = is_normal_mode_set;
  _is_hue_mode_set = is_hue_mode_set;

  if (_is_normal_mode_set){
    nx = new GLfloat[size];
    ny = new GLfloat[size];
    nz = new GLfloat[size];
  }

  if (_is_hue_mode_set){	       
    r = new GLfloat[size];
    g = new GLfloat[size];
    b = new GLfloat[size];
    a = new GLfloat[size]; 
  }
}
