#ifndef glop_DRAWABLE
#define glop_DRAWABLE

#include <glopCommon.h>
#include <list>
#include <map>
#include <utility> // pair
#include <GL/gl.h>


namespace glop {
  
  class Scene;
  class DrawableSet;
  class Light;

  /**
   * @short Interface for stuff that is drawn.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Drawable {

  private:
    
    bool is_init;
    friend class DrawableSet;

    static GLuint name_counter;

  public:

    Drawable(void);
    virtual ~Drawable(void);

    /**
     * Enable/Disable the ability of an object to be selected. <b>Don't use it within a drawing method<b>.
     */
    void Selectable(bool status);
    
    /**
     * This method is for system use. The system use it to encapsulate
     * your actual Draw call. You may not need it in most cases.
     * @param parent_last_name Last name of the container drawable the object is a child of.
     */
    void SystemDraw(Scene* scene, GLuint parent_last_name);

    /**
     * This method is for system use. The system use it to encapsulate
     * your actual InitDrawings call. You may not need it in most cases.
     */
    void SystemInitDrawings(Scene* scene);
    
    
  protected:
    
    /**
     * Used in selection. Each drawable has a different one.
     */ 
    GLuint name; 

    /**
     * Used in selection. Non selectable objects have the one of their parent.
     */ 
    GLuint last_name; 

    /**
     * Tells if the object is selectable.
     */
    bool is_selectable;

    /**
     * This draws your actual objects. Override it for your own
     * drawings.
     */
    virtual void Draw(Scene* scene)=0;
    
    /**
     * Perform this once your openGL stuff is set, for inits such as
     * list creation, etc... An object is initialized only once, even
     * if several calls to this method are performed (by Scene for
     * example).
     */
    virtual void InitDrawings(Scene* scene)=0;

    /**
     * For system use only.
     */
    virtual void ProcessSelection(std::map<GLuint,int>& name_rank);

    /**
     * This is called to notify the object when selection has been
     * done. Override it to allow an object to react to selection.
     * @param rank 0 means that the object is the closest to the camera, 1 that is is the second closest, etc... Negative values mean that the object is not selected.
     */
    virtual void SelectionNotify(int rank);
  };

  
  /**
   * @short A drawable composed from other ones.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class DrawableSet : public Drawable {

  protected:

    std::list< std::pair<Drawable*,void (*)(Drawable*)> > drawables;

    /**
     * This method is the default behavior of Draw, it draws each
     * drawable of the set. You can use it within an overloaded Draw
     * method. <br> <b>Warning:</b> If you want to trigger the drawing
     * of the child drawables within Draw by yourself, not using
     * DrawContents, call SystemDraw for these children rather than Draw.
     */
    void DrawContents(Scene* scene);

    virtual void Draw(Scene* scene); 
    virtual void InitDrawings(Scene* scene);

  public:
    
    DrawableSet(void) {}
    virtual ~DrawableSet(void) {}
    
    /**
     * Add a drawable in the set. All added drawables will be managed
     * together, in the order they have been added. You can add twice
     * the same drawable, it will be drawn twice but initialized once.
     * @param drawable The thing to be drawn.  @param move A function
     * (can be NULL) containing glRotate, glTranslate, glScale,... It
     * is given the drawable set itself when called. Don't glPushMatrix neither
     * glPopMatrix.
     */
    void AddDrawable(Drawable* drawable,
		     void (*move)(Drawable*)); 

    /**
     * Even if lights are drawables, they have to be added  with this function (in order to be drawn first).
     * @param light,move see glop::Drawable::AddDrawable.
     */
    void AddLight(Light* light,void(*move)(glop::Drawable*));
    
    virtual void ProcessSelection(std::map<GLuint,int>& name_rank);
  };

}

#endif
