#include "glopTexture.h"
#include <stdlib.h>
#include <iostream>
#include <fstream>


/* ########### */
/* #         # */
/* # Texture # */
/* #         # */
/* ########### */

glop::Texture::Texture(void)
{
}

glop::Texture::~Texture(void)
{
  std::map<int,TexInfo>::iterator iter;

  for(iter=textures.begin();
      iter!=textures.end();
      ++iter)
    delete [] (*iter).second.data;
}


void glop::Texture::LoadTexturePPM(std::string file_name,
				   int size,
				   int scale)
{
  std::ifstream file;
  std::string format;
  std::string line;
  char sep,first,unused;
  int width,height,dummy;
  int w,h;
  int s,t,k,i;
  

  file.open(file_name.c_str());
  
  if(!file)
    {
      std::cerr << "Cannot open texture \"" << file_name
		<< "\", aborting..." << std::endl;
      ::exit(0);
    }

  file >> format;
  file.get(sep);

  if(format!="P6")
    {
      std::cerr << "It seems that \"" << file_name
		<< "\" isn't a color PPM image, aborting..." << std::endl;
      ::exit(0);
    }

  // We skip comments.
  file.get(first);
  while(first=='#')
    {
      std::getline(file,line,'\n');
      file.get(first);
    }
  file.putback(first);

  // Get size
  file >> width >> height >> dummy;
  file.get(sep);

  // We allocate texture.
  textures[scale].data=new char[4*size*size];
  textures[scale].size=size;

  k=0;
  for(h=0,t=0;
      h<height && t<size;
      h++,t++)
    {
      for(w=0,s=0;
	  w<width && s<size;
	  w++,s++,k+=4)
	{
	  file.get(sep);
	  textures[scale].data[k+0]=sep;
	  file.get(sep);
	  textures[scale].data[k+1]=sep;
	  file.get(sep);
	  textures[scale].data[k+2]=sep;
	  textures[scale].data[k+3]=(char)(255);
	}
      
      // End of input line
      for(;w<width;w++)
	{
	  file.get(unused);
	  file.get(unused);
	  file.get(unused);
	}
      
      // End of texture line
      for(;s<size;
	  s++,k+=4)
	{
	  textures[scale].data[k+0]=0;
	  textures[scale].data[k+1]=0;
	  textures[scale].data[k+2]=0;
	  textures[scale].data[k+3]=0; // Transparent
	}    
    }
  
  // End of texture
  for(;t<size;t++)
    for(i=0;i<size;i++,k+=4)
      {
	textures[scale].data[k+0]=0;
	textures[scale].data[k+1]=0;
	textures[scale].data[k+2]=0;
	textures[scale].data[k+3]=0; // Transparent
      }

  file.close();  
}

void glop::Texture::InitTexturing(void)
{
  std::map<int,TexInfo>::iterator iter;

  // Allocate texture at openGL device side.
  glGenTextures(1,&texture_idf);

  // Now, we work with this one.
  glBindTexture(GL_TEXTURE_2D,texture_idf);

  // The work is to load texture at openGL device side.
  glPixelStorei(GL_UNPACK_ALIGNMENT,1); // One byte per R,G,B,A

  for(iter=textures.begin();
      iter!=textures.end();
      ++iter)
    glTexImage2D(GL_TEXTURE_2D,
		 (*iter).first,        // Scale
		 GL_RGBA,              // R,G,B,A format for each pixel in source data.
		 (*iter).second.size,  // Texture size.
		 (*iter).second.size,  // Texture size.
		 0,                    // No border
		 GL_RGBA,              // R,G,B,A format for each pixel in internal openGL device data
		 GL_UNSIGNED_BYTE,     // pixel components in source data are bytes.
		 (*iter).second.data); // The data, finally !
}

void glop::Texture::BeginTexturing(void)
{  
  glEnable(GL_TEXTURE_2D);  
  
  // Texture replaces object color.
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE); 

  // Start working with this texture.
  glBindTexture(GL_TEXTURE_2D,texture_idf);

  // Set some algorithm for S and T outside texture.
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT); 

  // Set stretching algorithms
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
}

void glop::Texture::EndTexturing(void)
{  
  // Stop working with textures.
  glDisable(GL_TEXTURE_2D);
}

bool glop::Texture::Exists(int scale)
{
  return textures.count(scale)!=0;
}

int glop::Texture::Size(int scale)
{
  return textures[scale].size;
}

char* glop::Texture::Image(int scale)
{
  return textures[scale].data;
}


/* #################### */
/* #                  # */
/* # Texture Modulate # */
/* #                  # */
/* #################### */

void glop::TextureModulate::BeginTexturing(void)
{  
  glEnable(GL_TEXTURE_2D);  
  
  // Texture replaces object color.
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 
  
  // Start working with this texture.
  glBindTexture(GL_TEXTURE_2D,texture_idf);
  
  // Set some algorithm for S and T outside texture.
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT); 
  
  // Set stretching algorithms
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
}


/* ############### */
/* #             # */
/* # Texture Map # */
/* #             # */
/* ############### */

glop::TextureMap::TextureMap(GLuint mapping)
  :glop::Texture()
{
  texture_mapping=mapping;
}

void glop::TextureMap::BeginTexturing(void)
{
  glEnable(GL_TEXTURE_2D);  
  
  // Texture replaces object color.
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE); 

  // Start working with this texture.
  glBindTexture(GL_TEXTURE_2D,texture_idf);

  // Set some algorithm for S and T outside texture.
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT); 

  // Set stretching algorithms
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);

  // We ask openGL device to set texture coordinates by its own.      
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);      
  glTexGeni(GL_S,GL_TEXTURE_GEN_MODE,texture_mapping);
  glTexGeni(GL_T,GL_TEXTURE_GEN_MODE,texture_mapping);

}

void glop::TextureMap::EndTexturing(void)
{  
  // We disable automatic texture coordinates generation.
  glDisable(GL_TEXTURE_GEN_S);
  glDisable(GL_TEXTURE_GEN_T);

  // Stop working with textures.
  glDisable(GL_TEXTURE_2D);    
}
