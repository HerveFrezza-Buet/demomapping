#include "glopLight.h"
#include <GL/gl.h>
#include <iostream>

/* ############### */
/* #             # */
/* # Light model # */
/* #             # */
/* ############### */

glop::LightModel::LightModel(void)
  :Drawable()
{
  ambient[0]=.1;
  ambient[1]=.1;
  ambient[2]=.1;
  ambient[3]= 1;

  shade=GL_SMOOTH;
}

glop::LightModel::~LightModel(void)
{
}

void glop::LightModel::Ambient(GLfloat r,GLfloat g,GLfloat b,GLfloat a)
{
  ambient[0]=r;
  ambient[1]=g;
  ambient[2]=b;
  ambient[3]=a;
}

void glop::LightModel::Shading(GLuint shading)
{
  shade=shading;
}

void glop::LightModel::Enable(GLuint source)
{
  light_enabled[source]=true;
}

void glop::LightModel::Disable(GLuint source)
{
  light_enabled[source]=false;
}

void glop::LightModel::InitDrawings(glop::Scene* scene)
{ 
  std::map<GLuint,bool>::iterator iter;

  // We enable lighting.
  glEnable(GL_LIGHTING);

  // Allows (or not) the interpolating of colors inside polygons.
  glShadeModel(shade);

  // Ambient light, simulating world light emission.
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ambient);

  // We enable/disable lightings.
  for(iter=light_enabled.begin();
      iter!=light_enabled.end();
      ++iter)
    if((*iter).second)
      glEnable((*iter).first);
    else
      glDisable((*iter).first);
}

void glop::LightModel::Draw(glop::Scene* scene)
{
} 



/* ######### */
/* #       # */
/* # Light # */
/* #       # */
/* ######### */

glop::Light::Light(GLuint device_channel)
{
  power=true;
  channel=device_channel;
  
  // Default color is white.
  diffuse[0]=1;
  diffuse[1]=1;
  diffuse[2]=1;
  diffuse[3]=1;

  // Default specular is white.
  specular[0]=1;
  specular[1]=1;
  specular[2]=1;
  specular[3]=1;

  // No default ambient light.
  ambient[0]=0;
  ambient[1]=0;
  ambient[2]=0;
  ambient[3]=0;

  // Default position
  position[0]=0;
  position[1]=0;
  position[2]=0;
  position[3]=0;

  // Spot
  direction[0]=0;
  direction[1]=0;
  direction[2]=1;
  direction[3]=1;
  
  spot_cutoff=180;
  spot_exponent=100;

  // TO DO : ATTENUATION
}

glop::Light::~Light(void)
{
}

void glop::Light::LightSetup(void)
{
  if(power)
    {
      glLightfv(channel, GL_DIFFUSE        ,        diffuse);
      glLightfv(channel, GL_SPECULAR       ,       specular);
      glLightfv(channel, GL_AMBIENT        ,        ambient);
      glLightfv(channel, GL_POSITION       ,       position);
      glLightfv(channel, GL_SPOT_DIRECTION ,      direction);
      glLightf (channel, GL_SPOT_CUTOFF    ,    spot_cutoff);
      glLightf (channel, GL_SPOT_EXPONENT  ,  spot_exponent);
    }
}

void glop::Light::Draw(Scene *scene)
{
  LightSetup();
}

void glop::Light::InitDrawings(Scene *scene)
{
  // Nothing to do.
}

void glop::Light::SwitchOn(void)
{
  power=true;
}

void glop::Light::SwitchOff(void)
{
  power=false;
}
    
