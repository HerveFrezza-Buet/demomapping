#ifndef glop_COMMON
#define glop_COMMON

#include <GL/gl.h>


#define glopRAD(x) ((x)*M_PI/180.0)
#define glopDEG(x) ((x)*180.0/M_PI)
#define glopANGLE(adj,op,a)                     \
if((adj)==0)				 	\
{                                               \
  if((op)>=0)				 	\
    a=M_PI_2;					\
  else						\
    a=-M_PI_2;					\
}	                                        \
else if((adj)>0)			      	\
  a=atan((op)/(adj));				\
else						\
  a=M_PI-atan((op)/-(adj));			\
a=glopDEG(a)



namespace glop {

  /**
   * Coordinates
   */
  typedef GLfloat Coord;

  /**
   * Mouse button
   */
  enum Button {
    buttonLeft,
    buttonMiddle,
    buttonRight,
    buttonNone
  };
  typedef enum Button Button;

}


#endif
