#include <math.h>
#include "glopNormal.h"


inline void NormalOnZ(GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = 0.0;
  ny = 0.0;
  nz = 1.0;
}


inline void Normalize( GLfloat& nx,
		       GLfloat& ny,
		       GLfloat& nz){
//   GLfloat numerator= sqrt(nx*nx+ny*ny+nz*nz);
//   nx/=numerator;
//   ny/=numerator;
//   nz/=numerator;
}


void glop::Nop(const GLfloat* x,
	       const GLfloat* y,
	       const GLfloat* z,
	       GLfloat& nx,
	       GLfloat& ny,
	       GLfloat& nz){
}

void glop::Normal0000(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  NormalOnZ(nx,ny,nz);
}


void glop::Normal0001(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  NormalOnZ(nx,ny,nz);
}


void glop::Normal0010(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  NormalOnZ(nx,ny,nz);
}

void glop::Normal0011(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[1]-y[0])*(z[2]-z[0])+(z[1]-z[0])*(y[2]-y[0]);
  ny = -(z[1]-z[0])*(x[2]-x[0])+(x[1]-x[0])*(z[2]-z[0]);
  nz = -(x[1]-x[0])*(y[2]-y[0])+(y[1]-y[0])*(x[2]-x[0]);
  Normalize( nx, ny, nz);
}


void glop::Normal0100(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  NormalOnZ(nx,ny,nz);
}


void glop::Normal0101(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[1]-y[0])*(z[3]-z[0])+(z[1]-z[0])*(y[3]-y[0]);
  ny = -(z[1]-z[0])*(x[3]-x[0])+(x[1]-x[0])*(z[3]-z[0]);
  nz = -(x[1]-x[0])*(y[3]-y[0])+(y[1]-y[0])*(x[3]-x[0]);
  Normalize( nx, ny, nz);
}


void glop::Normal0110(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[2]-y[0])*(z[3]-z[0])+(z[2]-z[0])*(y[3]-y[0]);
  ny = -(z[2]-z[0])*(x[3]-x[0])+(x[2]-x[0])*(z[3]-z[0]);
  nz = -(x[2]-x[0])*(y[3]-y[0])+(y[2]-y[0])*(x[3]-x[0]);
  Normalize( nx, ny, nz);
}


void glop::Normal0111(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[1]-y[0])*(z[2]-z[0])+(z[1]-z[0])*(y[2]-y[0]);
  ny = -(z[1]-z[0])*(x[2]-x[0])+(x[1]-x[0])*(z[2]-z[0]);
  nz = -(x[1]-x[0])*(y[2]-y[0])+(y[1]-y[0])*(x[2]-x[0]);

  Normalize( nx, ny, nz);
}


void glop::Normal1000(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  NormalOnZ(nx,ny,nz);
}


void glop::Normal1001(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){

  nx = -(y[4]-y[0])*(z[1]-z[0])+(z[4]-z[0])*(y[1]-y[0]);
  ny = -(z[4]-z[0])*(x[1]-x[0])+(x[4]-x[0])*(z[1]-z[0]);
  nz = -(x[4]-x[0])*(y[1]-y[0])+(y[4]-y[0])*(x[1]-x[0]);

  Normalize( nx, ny, nz);
}


void glop::Normal1010(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[2]-y[0])*(z[4]-z[0])+(z[2]-z[0])*(y[4]-y[0]);
  ny = -(z[2]-z[0])*(x[4]-x[0])+(x[2]-x[0])*(z[4]-z[0]);
  nz = -(x[2]-x[0])*(y[4]-y[0])+(y[2]-y[0])*(x[4]-x[0]);
  Normalize( nx, ny, nz);
}


void glop::Normal1011(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[1]-y[0])*(z[2]-z[0])+(z[1]-z[0])*(y[2]-y[0]);
  ny = -(z[1]-z[0])*(x[2]-x[0])+(x[1]-x[0])*(z[2]-z[0]);
  nz = -(x[1]-x[0])*(y[2]-y[0])+(y[1]-y[0])*(x[2]-x[0]);

  Normalize( nx, ny, nz);
}


void glop::Normal1100(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[3]-y[0])*(z[4]-z[0])+(z[3]-z[0])*(y[4]-y[0]);
  ny = -(z[3]-z[0])*(x[4]-x[0])+(x[3]-x[0])*(z[4]-z[0]);
  nz = -(x[3]-x[0])*(y[4]-y[0])+(y[3]-y[0])*(x[4]-x[0]);

  Normalize( nx, ny, nz);
}


void glop::Normal1101(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = +(y[1]-y[0])*(z[4]-z[0])-(z[1]-z[0])*(y[4]-y[0]);
  ny = +(z[1]-z[0])*(x[4]-x[0])-(x[1]-x[0])*(z[4]-z[0]);
  nz = +(x[1]-x[0])*(y[4]-y[0])-(y[1]-y[0])*(x[4]-x[0]);
  Normalize( nx, ny, nz);
}


void glop::Normal1110(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[2]-y[0])*(z[3]-z[0])+(z[2]-z[0])*(y[3]-y[0]);
  ny = -(z[2]-z[0])*(x[3]-x[0])+(x[2]-x[0])*(z[3]-z[0]);
  nz = -(x[2]-x[0])*(y[3]-y[0])+(y[2]-y[0])*(x[3]-x[0]);
  Normalize( nx, ny, nz);
}



void glop::Normal1111(const GLfloat* x,
		      const GLfloat* y,
		      const GLfloat* z,
		      GLfloat& nx,
		      GLfloat& ny,
		      GLfloat& nz){
  nx = -(y[1]-y[0])*(z[2]-z[0])+(z[1]-z[0])*(y[2]-y[0]);
  ny = -(z[1]-z[0])*(x[2]-x[0])+(x[1]-x[0])*(z[2]-z[0]);
  nz = -(x[1]-x[0])*(y[2]-y[0])+(y[1]-y[0])*(x[2]-x[0]);
  Normalize( nx, ny, nz);
}
