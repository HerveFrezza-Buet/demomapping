#include "glopScene.h"
#include "glopUtils.h"

#include <iostream>
#include <iomanip>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>
#include <map>
#include <cstdlib>

glop::Scene::Scene(void)
{
  camera=new DefaultCamera();
  rgb_buf = (unsigned char*)NULL;

  x=0;
  y=0;
  z=5;
  
  Wx=1;
  Wy=0;
  Wz=0;
  
  Hx=0;
  Hy=1;
  Hz=0;

  Kx=0;
  Ky=0;
  Kz=-1;

  rx=0;
  ry=0;
  rz=0;

  at_x=0;
  at_y=0;
  at_z=0;

  up_x=0;
  up_y=1;
  up_z=0;

  view_width=0;
  view_height=0;

  is_in_selection_mode=false;
  select_x=0;
  select_y=0;



  is_in_anaglyph_mode = false;

  eye_sep = 1.5;

  left_r = GL_TRUE;
  left_g = GL_FALSE;
  left_b = GL_FALSE;

  right_r = GL_FALSE;
  right_g = GL_TRUE;
  right_b = GL_TRUE;
}

glop::Scene::~Scene(void)
{
}

void glop::Scene::SetBackgroundColor(GLfloat r, GLfloat g, GLfloat b)
{
  bg_r=r;
  bg_g=g;
  bg_b=b;
}

void glop::Scene::ReadFrameBuffer(unsigned char* rgb, int width, int height)
{
  rgb_buf=rgb;
  rgb_width=width;
  rgb_height=height;
}

void glop::Scene::onImageAvailable(unsigned char* rgb, 
				   int width, int height)
{
  // Nothing to do.
}

void glop::Scene::Rotate(double angle,
			 Coord& x,Coord& y,Coord& z,
			 Coord xx,Coord yy,Coord zz)
{
  double cost,sint;
  double n;
  Coord vx,vy,vz;
  
  n=sqrt(xx*xx+yy*yy+zz*zz);
  if(n==0)
    {
      // Silly case
      xx=0;
      yy=1;
      zz=0;
    }
  else
    {
      xx/=n;
      yy/=n;
      zz/=n;
    }

  cost = cos(glopRAD(angle));
  sint = sin(glopRAD(angle));

  vx=x;
  vy=y;
  vz=z;

  // From mathematica !
  x=xx*(vx*xx+vy*yy+vz*zz) - (vx*(xx*xx-1) + xx*(vy*yy+vz*zz))*cost + (vz*yy-vy*zz)*sint;
  y=yy*(vx*xx+vy*yy+vz*zz) - (vx*xx*yy + vy*(yy*yy-1)+ vz*yy*zz)*cost + (vx*zz-vz*xx)*sint;
  z=zz*(vx*xx+vy*yy+vz*zz) - ((vx*xx+vy*yy)*zz + vz*(zz*zz-1))*cost + (vy*xx-vx*yy)*sint;
}

void glop::Scene::UpdateLocalAxes(void)
{
  // The absolute axes.
  Coord Yx,Yy,Yz,
    Zx,Zy,Zz;

  Wx=1;
  Wy=0;
  Wz=0;
  
  Hx=0;
  Hy=1;
  Hz=0;

  Kx=0;
  Ky=0;
  Kz=-1;

  Yx=0;
  Yy=1;
  Yz=0;

  Zx=0;
  Zy=0;
  Zz=1;

  // Rotation around X.

  Rotate(rx,
	 Wx,Wy,Wz,
	 1,0,0);
  Rotate(rx,
	 Hx,Hy,Hz,
	 1,0,0);
  Rotate(rx,
	 Kx,Ky,Kz,
	 1,0,0);

  Rotate(rx,
	 Yx,Yy,Yz,
	 1,0,0);
  Rotate(rx,
	 Zx,Zy,Zz,
	 1,0,0);

  // Rotation around NEW Y
  
  Rotate(ry,
	 Wx,Wy,Wz,
	 Yx,Yy,Yz);
  Rotate(ry,
	 Hx,Hy,Hz,
	 Yx,Yy,Yz);
  Rotate(ry,
	 Kx,Ky,Kz,
	 Yx,Yy,Yz);

  Rotate(ry,
	 Zx,Zy,Zz,
	 Yx,Yy,Yz);

  // Rotation around NEW Z

  Rotate(rz,
	 Wx,Wy,Wz,
	 Zx,Zy,Zz);
  Rotate(rz,
	 Hx,Hy,Hz,
	 Zx,Zy,Zz);
  Rotate(rz,
	 Kx,Ky,Kz,
	 Zx,Zy,Zz);

//   PrintView(std::cout);
}

void glop::Scene::ImageSize(int width,int height)
{
  view_width=width;
  view_height=height;

  glViewport(0,0,
	     (GLsizei)view_width,(GLsizei)view_height);
}

void glop::Scene::GetImageSize(int& width,int& height)
{
  width=view_width;
  height=view_height;
}

void glop::Scene::MakeProjection(void)
{
  // We set 3D -> 2D mapping.

  camera->SetProjection(view_width,view_height);
}

void glop::Scene::MakePickingProjection(int x,int y)
{
  // These values can also be obtained by glGetIntegerv(GL_VIEWPORT,viewport)
  GLint viewport[4]={0,0,view_width,view_height};

  // We set 3D -> 2D mapping, and then we clip around cursor, by using
  // gluPickMatrix. Multiplications work in reverse order...
  // x,y is the cursor position, (0,0) is upper left corner.
  
  // Set usual coordinates.
  y=view_height-y;

  gluPickMatrix((GLdouble)x,(GLdouble)y, // Cursor position
		5.0,5.0,                 // size (pixel) of the region around cursor.
		viewport);   
  MakeProjection();
}
  

void glop::Scene::MakeModelView(void)
{
  // We rotate the whole scene, as if the camera has moved.

  // We first perform Viewing transformations.

  // Think of these transform as moving the world. You start from last
  // command to the first.
  glRotatef(-rz,0,0,1); 
  glRotatef(-ry,0,1,0);  
  glRotatef(-rx,1,0,0);    // 3- We rotate the world from origin (the
			   //    camera position) according to camera
			   //    orientation.
  glTranslatef(-x,-y,-z);  // 2- We translate the scene to be at -x,-y,-z
			   //    position (move the camera at x,y,z)
  camera->MoveToOrigin();  // 1- We put the scene in front of the camera.
}

void glop::Scene::MakeDrawings(void)
{
  // We clear buffers
  glClearColor(bg_r,bg_g,bg_b,1); 
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

  // Then, we draw objects. We prepare the name stack. We ignore
  // selection for the whole scene.
  Selectable(false);
  glInitNames(); // Initialization/clearing of the name stack.
  glPushName(0); // We push 0 name on the stack.
  SystemDraw(this,0);
}

void glop::Scene::Select(int x,int y)
{
  select_x=x;
  select_y=y;
  is_in_selection_mode=true;
  Refresh();
}

void glop::Scene::SetAnaglyph(bool set)
{
  is_in_anaglyph_mode = set;
}

void glop::Scene::AnaglyphParam(glop::Coord eye,
				GLboolean lr,GLboolean lg,GLboolean lb,
				GLboolean rr,GLboolean rg,GLboolean rb)
{
  eye_sep = eye;

  left_r = lr;
  left_g = lg;
  left_b = lb;

  right_r = rr;
  right_g = rg;
  right_b = rb;
  
}


void glop::Scene::CbkDraw(void)
{
  GLint nb_selection_hits;
  glop::Coord
    xx,yy,zz,
    tx,ty,tz,
    dirx,diry,dirz,
    wx,wy,wz,
    hx,hy,hz;

  if(is_in_anaglyph_mode)
    {
      xx = x;
      yy = y;
      zz = z;

      wx = Wx;
      wy = Wy;
      wz = Wz;

      hx = Hx;
      hy = Hy;
      hz = Hz;

      tx = at_x;
      ty = at_y;
      tz = at_z;
      
      dirx = up_x;
      diry = up_y;
      dirz = up_z;


      wx *= .5*eye_sep;
      wy *= .5*eye_sep;
      wz *= .5*eye_sep;

      glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
      glClearColor(bg_r,bg_g,bg_b,1); 
      glClear(GL_COLOR_BUFFER_BIT);
      
      // Left

      SetView(x-wx,y-wy,z-wz,
	      0,0,0);
      LookAt(tx,ty,tz,
	     dirx,diry,dirz);

      glMatrixMode(GL_PROJECTION);
      glLoadIdentity(); 
      MakeProjection();

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      MakeModelView();
      
      
      glClear(GL_DEPTH_BUFFER_BIT);
      glColorMask(left_r,left_g,left_b,GL_FALSE);
      Draw(this);
      
      // right

      SetView(x+wx,y+wy,z+wz,
	      0,0,0);
      LookAt(tx,ty,tz,
	     dirx,diry,dirz);

      glMatrixMode(GL_PROJECTION);
      glLoadIdentity(); 
      MakeProjection();

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      MakeModelView();
      
      
      glClear(GL_DEPTH_BUFFER_BIT);
      glColorMask(right_r,right_g,right_b,GL_FALSE);
      Draw(this);

      // Restore view;
      
      SetView(xx,yy,zz,
	      0,0,0);
      LookAt(tx,ty,tz,
	     dirx,diry,dirz);

      // Restore color mask
      glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
    }
  else if(is_in_selection_mode)
    {
      // We set the buffer needed for selection results.
      glSelectBuffer(glopScene_SELECT_BUF_SIZE,select_buf);
      // We switch to select mode.
      glRenderMode(GL_SELECT);

      // We make projection view suitable for clipping around cursor.
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity(); 
      MakePickingProjection(select_x,select_y);

      // We set camera position as usually.
      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      MakeModelView();

      // And we draw, 
      MakeDrawings();

      // We go back to usual render mode, setting select_buf and the
      // number of actual hits.
      nb_selection_hits=glRenderMode(GL_RENDER);
      // From select_buf and nb_selection_hits, we are able to analyse
      // the result of the selection process.
      ProcessHits(nb_selection_hits);
      
      is_in_selection_mode=false;

      // We redraw the scene because objects may have changed after
      // selection process.
      Refresh();
    }
  else
    {
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity(); 
      MakeProjection();

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      MakeModelView();

      MakeDrawings();
    }

  if((!is_in_selection_mode)&&(rgb_buf!=NULL))
    {
      glReadBuffer(GL_BACK);
      glPixelStorei(GL_PACK_ALIGNMENT,1);
      glReadPixels(0,0,(GLsizei)rgb_width,(GLsizei)rgb_height,GL_RGB,GL_UNSIGNED_BYTE,rgb_buf);
      onImageAvailable(rgb_buf,rgb_width,rgb_height);
    }
}
void glop::Scene::ProcessHits(GLint hits)
{
  std::multimap<GLuint,GLuint> z_name;
  std::pair<GLuint,GLuint> z_name_assoc;
  std::multimap<GLuint,GLuint>::iterator iter;

  std::map<GLuint,int> name_rank;

  int i;
  unsigned int j;
  int hit;
  GLuint stack_size;
  GLuint z_min;
  GLuint name;
  int rank;

  if(hits<0)
    std::cerr << "glop::Scene::ProcessHits : Selection buffer is too small. " 
	      << "ignoring selection." << std::endl;
  else
    {
      //PrintHits(std::cout,hits);
      
      i=0;
      for(hit=0;hit<hits;hit++)
	{
	  stack_size=select_buf[i];i++;
	  z_min=select_buf[i];i++;
	  /* Z_max */ i++;
	  // We get last name, the one being on the top of the stack.
	  for(j=0;j<stack_size;j++,i++)
	    name=select_buf[i];

	  // Now, we have a name and z.
	  z_name_assoc.first=z_min;
	  z_name_assoc.second=name;
	  z_name.insert(z_name_assoc);
	}

      // The problem is that a name may appear several times in the
      // z_name map. We keep only the one having the minimal z.
      for(iter=z_name.begin(),rank=0;
	  iter!=z_name.end();
	  ++iter,rank++)
	{
	  z_min=(*iter).first;
	  name=(*iter).second;
	  
	  // Is this name already registrated ? If yes, the rank is
	  // lower, so there is nothing to do.
	  if(name_rank.find(name) == name_rank.end())
	    {
	      // name has not already been registrated.
	      name_rank[name]=rank;
	      //std::cout << "name_rank[" << name << "] = " << rank << std::endl;
	    }
	}

      // we give selection information to all drawables.
      ProcessSelection(name_rank);
    }
}

void glop::Scene::PrintHits(std::ostream& os,GLint hits)
{
  int i;
  unsigned int j;
  int hit;
  GLuint stack_size;
  GLuint z_min,z_max;
  

  os << "There have been " << hits 
     << " hits from this selection." << std::endl;

  i=0;
  for(hit=0;hit<hits;hit++)
    {
      os << "  Hit " << hit << std::endl;
      stack_size=select_buf[i];i++;
      z_min=select_buf[i];i++;
      z_max=select_buf[i];i++;
      os << "    z in [" << z_min << ", " << z_max << "]" << std::endl
	 << "    Name stack :";
      for(j=0;j<stack_size;j++)
	{
	  os << ' ' << select_buf[i]; i++;
	}
      os << '.' << std::endl;
    }
}

void glop::Scene::CbkMotionNotify(Button b,
				  int x,int y)
{

  if(b==buttonNone) // Release
    button=buttonNone; 
  else if(b!=button) // Button has changed
    button=buttonNone; 
  else
    {
      Motion(this,b,x,y,x-wo,y-ho,x-w,y-h);
      Refresh();
      w=x;
      h=y;
    }
}

void glop::Scene::CbkClickNotify(Button b,
				 int x,int y)
{
  wo=x;
  ho=y;
  w=x;
  h=y;
  button=b;

  Click(this,button,wo,ho);
  Refresh();
}

void glop::Scene::SetCamera(Camera* new_camera)
{
  camera=new_camera;
}

void glop::Scene::SetView(Coord x_pos,Coord y_pos,Coord z_pos,
			  Coord x_rot,Coord y_rot,Coord z_rot)
{
  x=x_pos; y=y_pos; z=z_pos;
  rx=x_rot; ry=y_rot; rz=z_rot;
  UpdateLocalAxes();
  //PrintView(std::cout);
}

void glop::Scene::GetView(Coord& x_pos,Coord& y_pos,Coord& z_pos,
			  Coord& x_rot,Coord& y_rot,Coord& z_rot)
{
  x_pos=x; y_pos=y; z_pos=z;
  x_rot=rx; y_rot=ry; z_rot=rz;
}

void glop::Scene::GetLocalAxes(Coord& W_x,Coord& W_y,Coord& W_z,
			       Coord& H_x,Coord& H_y,Coord& H_z,
			       Coord& K_x,Coord& K_y,Coord& K_z)
{
  W_x=Wx;
  W_y=Wy;
  W_z=Wz;

  H_x=Hx;
  H_y=Hy;
  H_z=Hz;

  K_x=Kx;
  K_y=Ky;
  K_z=Kz;
}

void glop::Scene::MoveView(Coord x_pos,Coord y_pos,Coord z_pos,
			   Coord x_rot,Coord y_rot,Coord z_rot)
{
  x+=x_pos; y+=y_pos; z+=z_pos;
  rx+=x_rot; ry+=y_rot; rz+=z_rot;
  UpdateLocalAxes();
  //PrintView(std::cout);
}

void glop::Scene::LastLookAt(Coord& x_pos,Coord& y_pos,Coord& z_pos,
			     Coord& x_dir,Coord& y_dir,Coord& z_dir)
{
  x_pos=at_x;
  y_pos=at_y;
  z_pos=at_z;

  x_dir=up_x;
  y_dir=up_y;
  z_dir=up_z;
}
    
void glop::Scene::LookAt(Coord x_pos,Coord y_pos,Coord z_pos,
			 Coord x_dir,Coord y_dir,Coord z_dir)
{
  Coord dx,dy,dz,dr;
  
  at_x=x_pos;
  at_y=y_pos;
  at_z=z_pos;

  up_x=x_dir;
  up_y=y_dir;
  up_z=z_dir;
  
  dx=x_pos-x;
  dy=y_pos-y;
  dz=z_pos-z;

  dr=sqrt(dy*dy+dz*dz);

  glopANGLE(dy,dz,rx);
  rx= rx+90;

  glopANGLE(dr,dx,ry);
  ry= -ry;

  // We transform the dir vector as the world is (-rx, -ry, -rz)
  
  Rotate(-rx,
	 x_dir,y_dir,z_dir,
	 1,0,0);

  Rotate(-ry,
	 x_dir,y_dir,z_dir,
	 0,1,0);


  // as image is plane X,Y, (x_dir,y_dir) determines z angle.
  glopANGLE(x_dir,y_dir,rz);
  rz-=90; // Put on top.

  UpdateLocalAxes();
  //PrintView(std::cout);
}

void glop::Scene::PrintView(std::ostream& os)
{
  os << "Current view : " << std::endl
     << "   At (" 
     << std::setw(20) << x << " ,"
     << std::setw(20) << y << " ,"
     << std::setw(20) << z << " )" << std::endl
     << "      ("
     << std::setw(20) << rx << "�,"
     << std::setw(20) << ry << "�,"
     << std::setw(20) << rz << "�)" << std::endl;
}

void glop::Scene::CbkInit(void)
{
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_NORMALIZE);
  InitDrawings(this);
}

void glop::Scene::CbkTime(void)
{
  Time(this);
  
  if(time_events.size()>0)
    Refresh();
}

