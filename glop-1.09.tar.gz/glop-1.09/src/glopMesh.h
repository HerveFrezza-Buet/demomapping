#ifndef glop_MESH
#define glop_MESH

#include <assert.h>
#include <glop.h>
#include <iostream>
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include <glop.h>


#include <stdlib.h>
#include <iomanip>
#include <string>

#include <glopDraw.h>
#include <glopDrawFill.h>
#include <glopDrawLine.h>
#include <glopDrawDot.h>


#define MESH_SCALE 0.1

// #define NO_VERTEX 0
// #define V0_SET 1
// #define V1_SET 2
// #define V2_SET 4
// #define V3_SET 8


namespace glop{


  class Vertex{
  public:
    GLfloat _x;
    GLfloat _y;
    GLfloat _z;

    Vertex(  GLfloat x=0.0,
	     GLfloat y=0.0,
	     GLfloat z=0.0):
      _x(x),
      _y(y),
      _z(z){
    }
  };


  class AbstractHueComputer{
  public: 
    AbstractHueComputer(unsigned vector_size, GLfloat min_value, GLfloat max_value);

    virtual ~AbstractHueComputer(void);

    // pure virtual function
    virtual void CalcVertexColors(Vertex* v, GLfloat* colors)=0;
    
    /**
     * Compute hue color from value.
     */
    // Modif HFB
    static inline void CalcHue(GLfloat  intensity, GLfloat* colors) {
      // [0.0,0.25[ -> [xxB, xGB[
      if (intensity<0.25)
	SetColor(colors, 0.0, intensity*4, 1.0);
      // [0.25,0.5[ -> [xGB, xGx[
      else if(intensity<0.5)
	SetColor(colors, 0.0, 1.0, (0.5-intensity)*4);
      // [0.5,0.75[ -> [xGx, RGx[
      else if(intensity<0.75)
	SetColor(colors, (intensity-0.5)*4, 1.0, 0.0);
      // [0.75,1.0] -> [RGx, Rxx]
      else 
	SetColor(colors, 1.0, (1.0-intensity)*4, 0.0);
    }


  protected:
    GLfloat* _colors;
    unsigned _vector_size;
    GLfloat _min_value;
    GLfloat _max_value;
    GLfloat _div_delta_min_max;

/*     inline void CalcHue(GLfloat  intensity, GLfloat* colors); Modif HFB : public static*/

    GLfloat CalcIntensity(GLfloat value){
      return value*_div_delta_min_max; // * more efficient than /
    }

    static /* modif HFB */ void SetColor(GLfloat* colors, GLfloat r,GLfloat g, GLfloat b, GLfloat a){
      *colors     = r;
      *(colors+1) = g;
      *(colors+2) = b;	
      *(colors+3) = a;
    } 
    static /* modif HFB */ void SetColor(GLfloat* colors, GLfloat r,GLfloat g, GLfloat b){
      *colors     = r;
      *(colors+1) = g;
      *(colors+2) = b;	
    } 

  };


  //
  // Red to Blue hue calculator
  //
  class HueComputer:public AbstractHueComputer{
  public:
    HueComputer(unsigned vector_size, GLfloat min_value, GLfloat max_value);

    virtual void CalcVertexColors(Vertex* v, GLfloat* colors);
  protected:
    GLfloat* CalcHuesOfMap(Vertex* v); 
  };


  /**
   * This class allows to draw anly some parts of a grid. It is
   * supposed to be inherited.
   */
  class AbstractGridComputer {
  protected:
    int width,height;
  public:
    AbstractGridComputer(int grid_width,int grid_height) 
      : width(grid_width), height(grid_height) {}

    virtual ~AbstractGridComputer(void) {}

    /**
     * Tells is line u should be displayed.
     */
    virtual bool DisplayU(int u)=0;

    /**
     * Tells is column v should be displayed.
     */
    virtual bool DisplayV(int v)=0;
  };

  /**
   * Displays the whole grid.
   */
  class FullGridComputer : public AbstractGridComputer {
  public:
    FullGridComputer(int grid_width,int grid_height) 
      : AbstractGridComputer(grid_width,grid_height) {}
    virtual ~FullGridComputer(void) {}

    /**
     * Tells is line u should be displayed.
     */
    virtual bool DisplayU(int u) {return true;}

    /**
     * Tells is column v should be displayed.
     */
    virtual bool DisplayV(int v) {return true;}
  };

  
  /**
   * Displays the grid periodically
   */
  class PeriodicGridComputer : public AbstractGridComputer {
  protected:
    int u_period,v_period;
  public:
    PeriodicGridComputer(int grid_width,int grid_height,
			 int width_period, int height_period) 
      : AbstractGridComputer(grid_width,grid_height),
	u_period(width_period),v_period(height_period) {}
    virtual ~PeriodicGridComputer(void) {}

    /**
     * Tells is line u should be displayed.
     */
    virtual bool DisplayU(int u) {return u%u_period==0;}

    /**
     * Tells is column v should be displayed.
     */
    virtual bool DisplayV(int v) {return v%v_period==0;}
  };


  

  class Mesh{
  protected:
    bool _use_list;
    DrawFunction* _function_map;
    NormalFunction* _normal_map;

    unsigned _max_i;
    unsigned _max_j;
    unsigned _size;
    GLfloat* _x_normal_map;
    GLfloat* _y_normal_map;
    GLfloat* _z_normal_map;

    bool _is_prepared;

    bool _is_material;

    bool _is_hue_mode_set;

    bool _is_normal_mode_set;

    bool _are_normal_values_kept;

    AbstractFunctionSelector* _selector;
    AbstractGridComputer* _grid_computer;

  public:
    Mesh(unsigned max_i, unsigned max_j /* modif HFB , bool* cell_state_array */);

    virtual ~Mesh(void){
      delete [] _function_map;
      delete [] _normal_map;
      delete [] _x_normal_map;
      delete [] _y_normal_map;
      delete [] _z_normal_map;
      delete _grid_computer;
      delete _selector;
    }

    /**
     * The object may delete the argument !
     */
    void SetFunctionSelector(AbstractFunctionSelector* selector){
      delete _selector;
      _selector = selector;
    }

    /**
     * The object may delete the argument !
     */
    void SetGridComputer(AbstractGridComputer* computer){
      delete _grid_computer;
      _grid_computer = computer;
    }

    unsigned GetMaxI(void){
      return _max_i;
    }

    unsigned GetMaxJ(void){
      return _max_j;
    }

    unsigned GetSize(void){
      return _size;
    }

    void SetHueMode(bool is_hue_mode_set){
      _is_hue_mode_set = is_hue_mode_set;
    }
    void SetNormalMode(bool is_normal_mode_set){
      _is_normal_mode_set = is_normal_mode_set;
    }
    void SetMaterialMode(bool is_material){
      _is_material = is_material;
    }

    void SetNormalValueKeeping(const bool are_normal_values_kept){
      _are_normal_values_kept = are_normal_values_kept;
    }

    void Prepare(bool* empty_cell_map);

    virtual void Render(Vertex* vertexes, GLfloat* colors=NULL);


  protected:
    void MapDrawingFunc(bool* empty_cell_map);

    void MapNormalFunc(bool* empty_cell_map);

    void CalcNormals(Vertex* vertexes);

    void DrawVertexes(Vertex* vertexes, GLfloat* colors=NULL);

    void DrawGrid(Vertex* vertexes);


    GLfloat GetValue(unsigned i, unsigned j, GLfloat* tab){
      assert(i<_max_i);
      return tab[j*_max_i+j];
    }


    bool GetValue(unsigned i, unsigned j, bool* tab){
      assert(i<_max_i);
      return tab[j*_max_i+j];
    }


    unsigned GetOffset(unsigned i, unsigned j){
      assert(i<_max_i);
      return j*_max_i+i;
    }


    void SetUseList(bool use_list){
      _use_list = use_list;
    }  
  
  private:
    void MapNormalFunc1x1Map(bool* empty_cell_map);
    void MapNormalFuncLeftBottomCorner(bool* empty_cell_map);
    void MapNormalFuncLeftTopCorner(bool* empty_cell_map);
    void MapNormalFuncRightBottomCorner(bool* empty_cell_map); 
    void MapNormalFuncRightTopCorner(bool* empty_cell_map);
    void MapNormalFuncFirstRow(bool* empty_cell_map);
    void MapNormalFuncLastRow(bool* empty_cell_map);
    void MapNormalFuncFirstColumn(bool* empty_cell_map);
    void MapNormalFuncLastColumn(bool* empty_cell_map);
    void MapNormalFuncInnerCell(bool* empty_cell_map);
  };
}
#endif
