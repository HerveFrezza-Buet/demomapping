#ifndef glopUTILS
#define glopUTILS

#include <glopCommon.h>
#include <glopCamera.h>
#include <glopDrawable.h>
#include <glopLight.h>
#include <glopMouseEvent.h>
#include <glopTimeEvent.h>

namespace glop {

  /**
   * @short This is the camara object used by default.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class DefaultCamera : public Camera {

  protected:

    virtual void SetProjection(int width,int height);
    virtual void MoveToOrigin(void);
    virtual Coord Focal(void);
      
  };

  /**
   * @short The camera is controlled by rx,ry,rz and r.  
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   * 
   * <dl> <dt>Left-button <dd> controls rx (left-right) and ry
   * (up_down). <dt> Middle-button <dd> controls rz (left-right) and
   * z (up_down). <dt> Right-button <dd> controls
   *  x (left-right) and y (up_down). </dl>
   */
  class DirectInteractiveView : public MouseEvent {

  private:

    // Point of view.
    Coord x,y,z,rx,ry,rz;


  protected:
      
    virtual void Click(Scene* scene,
		       Button b,
		       int x,int y);
    virtual void Motion(Scene* scene,
			Button b,
			int x,int y,
			int dx,int dy,
			int ddx,int ddy);
      
  public:
      
    DirectInteractiveView(void);
  };

  /**
   * @short The camera is on an orbit around 0,0,0, looking at it.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class OrbitInteractiveView : public MouseEvent {

  private:

    double radius;

  protected:
      
    virtual void Click(Scene* scene,
		       Button b,
		       int x,int y);
    virtual void Motion(Scene* scene,
			Button b,
			int x,int y,
			int dx,int dy,
			int ddx,int ddy);
      
  public:
      
    OrbitInteractiveView(void);
  };

  /**
   * @short The camera is like a flight simulator.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class FlightInteractiveView : public MouseEvent, public TimeEvent {
    
  private:
    
    Coord dw,dh,dk;
    int nb_samples;
    bool fly,use_accel;
    double speed;
    double accel;

  protected:
      
    /**
     * nb elementary motions are done to get an
     * approximative speed length path.
     */
    void SetNbSamples(int nb);

    /**
     * Speed is in world units per click.
     */
    void SetSpeed(double s);

    /**
     * maximal variation of speed per click.
     */
    void SetAcceleration(double a);

    virtual void Click(Scene* scene,
		       Button b,
		       int x,int y);
    virtual void Motion(Scene* scene,
			Button b,
			int x,int y,
			int dx,int dy,
			int ddx,int ddy);
    virtual void Time(Scene* scene);
      
  public:
      
    FlightInteractiveView(void);
  };


  /**
   * @short This allows either selection or interactive view.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class SelectorInteractiveView : public MouseEvent {

  private:

    MouseEvent* event;
    bool selection;

  protected:
      
    virtual void Click(Scene* scene,
		       Button b,
		       int x,int y);
    virtual void Motion(Scene* scene,
			Button b,
			int x,int y,
			int dx,int dy,
			int ddx,int ddy);
      
  public:
      
    /**
     * @param iv The mouse event used when not in selection mode. It is not deleted by the object.
     */
    SelectorInteractiveView(MouseEvent* iv);
    
    /**
     * When selection mode is set, left button click 
     */
    void SetSelectionMode(bool select);
  };

  /**
   * @short Directional light (like the sun). 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   */
  class DirectionLight : public Light {

  public:

    /**
     * Make a directional light.
     * @param device_channel GL_LIGHT0, GL_LIGHT1, ...
     * @param x,y,z A vector pointing toward the light source (that is very far from the scene).
     * @param r,g,b The light color.
     */
    DirectionLight(GLuint device_channel,
		   GLfloat x,GLfloat y,GLfloat z,
		   GLfloat r,GLfloat g,GLfloat b);
    
  };

  /**
   * @short Point light. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   */
  class PointLight : public Light {

  public:

    /**
     * Make a directional light.
     * @param device_channel GL_LIGHT0, GL_LIGHT1, ...
     * @param x,y,z Position.
     * @param r,g,b The light color.
     */
    PointLight(GLuint device_channel,
	       GLfloat x,GLfloat y,GLfloat z,
	       GLfloat r,GLfloat g,GLfloat b);
    
  };

  /**
   * @short Spot light. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   */
  class SpotLight : public Light {

  public:

    /**
     * Make a directional light.
     * @param device_channel GL_LIGHT0, GL_LIGHT1, ...
     * @param x,y,z Position.
     * @param nx,ny,nz Direction (some kind of normal vector).
     * @param r,g,b The light color.
     * @param cutoff angle (in degres) from spot axis to cutoff cone.
     * @param exponent attenuation with angle in the cone.
     */
    SpotLight(GLuint device_channel,
	      GLfloat x,GLfloat y,GLfloat z,
	      GLfloat nx,GLfloat ny,GLfloat nz,
	      GLfloat r,GLfloat g,GLfloat b,
	      GLfloat cutoff=60,GLfloat exponent=10);
    
  };


  /**
   * @short Depth of field : far and close objects are blurred. 
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   *
   */
  class DepthOfField : public DrawableSet
  {
  private:

    double focus;
    double jitter;
    int nb_tries;
    bool show_focus;

  protected:

    virtual void Draw(glop::Scene* scene);

    /**
     * This tells how to draw the focus.
     */
    void DrawFocus(Coord x,Coord y,Coord z);

  public:

    DepthOfField(void);
    virtual ~DepthOfField(void);

    /**
     * Number of images sent in accumulation buffer.
     */
    void SetNbTries(int n);
  
    /**
     * The objects are not blurred at this distance from the camera.
     */
    void SetFocus(double d);

    /** 
     * Sets j so that the jittering is the rotation of the scene with
     * an angle in [-j,+j] in all x,y,z rotations. Angle is in degre.
     */
    void SetJitter(double j);

    /**
     * Toggles the display of the focus point.
     */
    void ShowFocusPoint(bool is_shown);

  };
}

#endif
