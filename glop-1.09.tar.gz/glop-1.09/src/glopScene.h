#ifndef glop_SCENE
#define glop_SCENE

#include <glopCommon.h>
#include <glopCamera.h>
#include <glopDrawable.h>
#include <glopLight.h>
#include <glopMouseEvent.h>
#include <glopTimeEvent.h>

#include <cstdlib>
#include <iostream>

namespace glop {

  /**
   * @short This class manages the scene.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
  class Scene : 
    public MouseEventSet, 
    public DrawableSet, 
    public TimeEventSet 
  {
    
  private :

    // background
    
    GLfloat bg_r,bg_g,bg_b;
    
    // Point of view.
    Coord x,y,z,rx,ry,rz;

    // Local coordinates
    Coord Wx,Wy,Wz,
      Hx,Hy,Hz,
      Kx,Ky,Kz;

    // Anaglyph stuff;
    bool is_in_anaglyph_mode;
    GLboolean left_r,left_g,left_b;
    GLboolean right_r,right_g,right_b;
    Coord eye_sep;
    
      
    // Do we select ?
    bool is_in_selection_mode;
    int select_x,select_y;
#define glopScene_SELECT_BUF_SIZE 2048
    GLuint select_buf[glopScene_SELECT_BUF_SIZE];

    void UpdateLocalAxes(void);
    
    // Last look at value
    Coord at_x,at_y,at_z;
    Coord up_x,up_y,up_z;
    
    // Camera
    Camera* camera;
    
    
    // View port
    int view_width,view_height;
    
    // clicks and motion.
    
    Button button;
    int w,h,
      wo,ho,
      dw,dh,
      ddw,ddh;

    // Selection processing.
    void ProcessHits(GLint hits);

    unsigned char* rgb_buf;
    int rgb_width,rgb_height;


  protected:

    /**
     * See ReadFrameBuffer. This is called when image is available in
     * the buffer <b>you have provided</b>/
     */

    virtual void onImageAvailable(unsigned char* rgb, int width, int height);

  public :

    Scene(void);
    virtual ~Scene(void);

    /**
     * Computes rotation around a vector.
     * @param angle Rotation angle in degree.
     * @param x,y,z The vector to be rotated.
     * @param xx,yy,zz The vector around which the rotation is performes.
     */
    static void Rotate(double angle,
		       Coord& x,Coord& y,Coord& z,
		       Coord xx,Coord yy,Coord zz);

    /**
     * This is what has to be done in some init callback of your
     * opengl environment.
     */
    virtual void CbkInit(void);

    /**
     * This is what has to be done in some timeout callback that is
     * triggered periodically.
     */
    virtual void CbkTime(void);
    
    /**
     * This draws directly the scene. Use is in some kind of "redraw"
     * callback of your openGL environment. To redraw the scene from
     * elsewhere in the code, call Refresh. <b>Do not override this
     * method, rather use DrawObjects</b>.
     */
    virtual void CbkDraw(void); 

    /**
     * This Notifies click. Use it in some kind of "click" callback of
     * your openGL environment. <b>Do not override this method</b>
     *
     * @param b The button that is actually pressed (if previously pressed in the window). 
     * @param x,y Position of the mouse pointer in the window. (0,0) is upper-left corner
     */
    virtual void CbkClickNotify(Button b,
				int x,int y);

    /**
     * This Notifies click. Use it in some kind of "motion" callback of
     * your openGL environment. <b>Do not override this method</b>
     *
     * @param b The button that is actually pressed (may be glop::buttonNone). 
     * @param x,y Position of the mouse pointer in the window. (0,0) is upper-left corner
     */
    virtual void CbkMotionNotify(Button b,
				 int x,int y);

    /**
     * Trigger buffer-reading mode. Now, at each drawing, The frame
     * buffer will be written in the passed buffer. Override the
     * onImageAvailable method, that is called when buffer has been
     * written. <b>Provide NULL</b> to stop frame-buffer writing.
     *
     * @param rgb An allocated array of bytes to write image in. NULL stops writing.
     * @param width,height The image size, i.e. the rgb array must have a size greather than width*height*3.
     */
    void ReadFrameBuffer(unsigned char* rgb=NULL, int width=0, int height=0);
    
    /**
     * This sets the color background.
     */
    void SetBackgroundColor(GLfloat r, GLfloat g, GLfloat b);

    /** 
     * Tell the size of the image, so that the scene can change the
     * viewport features.
     * @param width,height size of viewing window (viewport) in pixels.
     */
    void ImageSize(int width,int height);

    /**
     * We get current image size.
     */
    void GetImageSize(int& width,int& height);

    /**
     * This post a redraw event, that is actually responsible for calling Draw.
     */
    virtual void Refresh(void)=0;

    /**
     * This sets camera. The object is used without copy inside the
     * scene, and it will be deleted by a further setting of the
     * camera. 
     */
    void SetCamera(Camera* new_camera);

    /**
     * Sets the point of view. Efficient ony <b>outside a drawing callback</b>
     * @param x_pos,y_pos,z_pos Position of the camera.
     * @param x_rot,y_rot,z_rot Orientation of the camera, in degrees, around X,Y and Z axes in this order. 0,0,0 means looking in negative Z direction.
     */
    void SetView(Coord x_pos,Coord y_pos,Coord z_pos,
		 Coord x_rot,Coord y_rot,Coord z_rot);
    /**
     * Gets the point of view
     * @param x_pos,y_pos,z_pos Position of the camera.
     * @param x_rot,y_rot,z_rot Orientation of the camera, in degrees, around X,Y and Z axes.
     */
    void GetView(Coord& x_pos,Coord& y_pos,Coord& z_pos,
		 Coord& x_rot,Coord& y_rot,Coord& z_rot);

    /** 
     * Gets three unit vectors, corresponding to the position in space
     * of the window axes.
     * @param W_x,W_y,W_z The abscissa vector on the camera glass (pointing to the left).
     * @param H_x,H_y,H_z The ordinate vector on the camera glass (pointing up).
     * @param K_x,K_y,K_z The normal to the camera glass, pointing toward what is looking at.
     */ 
    void GetLocalAxes(Coord& W_x,Coord& W_y,Coord& W_z,
		      Coord& H_x,Coord& H_y,Coord& H_z,
		      Coord& K_x,Coord& K_y,Coord& K_z);
    
    /**
     * Modifies the point of view by adding the arguments to current values.
     * @param x_pos,y_pos,z_pos Position of the camera.
     * @param x_rot,y_rot,z_rot Orientation of the camera, in degrees, around X,Y and Z axes.
     */
    void MoveView(Coord x_pos,Coord y_pos,Coord z_pos,
		  Coord x_rot,Coord y_rot,Coord z_rot);

    /**
     * Modifies rotation of the camera so that is points to a specific
     * location in space. Efficient ony <b>outside a drawing callback</b>
     * @param x_pos,y_pos,z_pos The pointed location.
     * @param x_dir,y_dir,z_dir This vector in the real world will point up in the image.
     */
    void LookAt(Coord x_pos,Coord y_pos,Coord z_pos,
		Coord x_dir=0,Coord y_dir=1,Coord z_dir=0);

    /**
     * Gets last LookAt command arguments. 
     * @param x_pos,y_pos,z_pos The pointed location.
     * @param x_dir,y_dir,z_dir This vector in the real world will point up in the image.
     */
    void LastLookAt(Coord& x_pos,Coord& y_pos,Coord& z_pos,
		    Coord& x_dir,Coord& y_dir,Coord& z_dir);
    
    /**
     * This is a debugging function.
     */
    void PrintView(std::ostream& os);

    /**
     * This is a debugging function.
     */
    void PrintHits(std::ostream& os,GLint hits);

    /**
     * This method makes the scene compute selection.
     * @param x,y position of the pointer in the window. (0,0) is top-left corner.
     */
    void Select(int x,int y);

    /** 
     * This method is called internally by the scene, but you may 
     * need to use it for specific drawing purpose. This multiplies
     * current projection matrix to project the scene according to
     * current camera. */  
    void MakeProjection(void); 

    /** 
     * This method is called internally by the scene, but you may need
     * to use it for specific drawing purpose. It is the same as
     * MakeProjection, but it stores the picking matrix before.
     */ 
    void MakePickingProjection(int x,int y);

    /** 
     * This method is called internally by the scene, but you may need
     * to use it for specific drawing purpose. This multiplies the
     * modelview matrix by the matrix corresponding to the camera
     * position.
     */
    void MakeModelView(void); 

    /** 
     * This method is called internally by the scene, but you may need
     * to use it for specific drawing purpose. This draws once all
     * matrix are set up.
     */ 
    void MakeDrawings(void); 

    /**
     * Sets parameters for anaglyph viewing. Left and right 
     * colors shold be exclusive. and
     * <b>camera has to be controlled by LookAt calls</b>.  
     * @param eye distance between the two eyes.  
     * @param lr,lg,lb color components seen by left glass.  
     * @param rr,rg,rb color components seen by right glass.
     */
    void AnaglyphParam(Coord eye,
		       GLboolean lr,GLboolean lg,GLboolean lb,
		       GLboolean rr,GLboolean rg,GLboolean rb);
		  
    /**
     * Toggles anaglyph rendering. This works correctly with cameras <b>if the current camera is controlled by LookAt calls.</b>
     */
    void SetAnaglyph(bool set);

  };


  /**
   * @short This class manages the scene.
   * @author <a href="mailto:Herve.Frezza-Buet@supelec.fr">Herve.Frezza-Buet@supelec.fr</a>
   */
}

#endif
