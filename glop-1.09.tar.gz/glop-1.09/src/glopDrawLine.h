#ifndef glop_DRAW_LINE
#define glop_DRAW_LINE

#include "glopDraw.h"
#include <GL/gl.h>


namespace glop{
  ////////////////////////////////////////////////////////////////
  //
  // function pointer
  //
  ////////////////////////////////////////////////////////////////

  // # : not defined out of bound
  // x : empty cell
  // O : set cell

  //
  //  x....x      #....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  x....x      #....#
  //
  void DrawLine0000(const DrawInfo& draw_info);


  //
  //  x....x      #....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  O....x      O....#
  //
  void DrawLine0001(const DrawInfo& draw_info);


  //
  //  x....x      #....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  x....O      #....O
  //
  void DrawLine0010(const DrawInfo& draw_info);

  //  
  //  #....#
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  O----O
  //
  void DrawLine0011(const DrawInfo& draw_info);


  //
  //  #....O
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  #....#
  //
  void DrawLine0100(const DrawInfo& draw_info);


  //  0101 no x1x1 possible because of square map
  //  x....O
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  O....x
  //
  void DrawLine0101(const DrawInfo& draw_info);


  //  0110,  x11x doesn't exists the drawing begin at (0,0) not (-1,-1)!
  //  x....O
  //  .    .
  //  .    .
  //  .    . 
  //  .    .
  //  x....O
  //
  void DrawLine0110(const DrawInfo& draw_info);


  //
  //  x....O
  //  .   /.
  //  .  / .
  //  . /  .
  //  ./   .
  //  O----O
  //
  void DrawLine0111(const DrawInfo& draw_info);


  //
  //  O....x      O....#
  //  .    .      .    .
  //  .    .  or  .    .
  //  .    .      .    .
  //  .    .      .    .
  //  x....x      #....#
  //
  void DrawLine1000(const DrawInfo& draw_info);


  //
  //  O....x      O....#
  //  |    .      |    .
  //  |    .  or  |    .
  //  |    .      |    .
  //  |    .      |    .
  //  O....x      O....#
  //
  void DrawLine1001(const DrawInfo& draw_info);


  //
  //  O....x
  //  .    .
  //  .    .
  //  .    .
  //  .    .
  //  x....O
  //
  void DrawLine1010(const DrawInfo& draw_info);


  //
  //  O....x
  //  |\   .
  //  | \  .
  //  |  \ .
  //  |   \.
  //  O----O
  //
  void DrawLine1011(const DrawInfo& draw_info);


  //
  //  O....O
  //  .    . 
  //  .    .
  //  .    .
  //  .    .
  //  #....#
  //
  void DrawLine1100(const DrawInfo& draw_info);


  //
  //  O....O
  //  |   /.
  //  |  / .
  //  | /  .
  //  |/   .
  //  O....x
  //
  void DrawLine1101(const DrawInfo& draw_info);


  //
  //  O....O
  //  .\   .
  //  . \  .
  //  .  \ .
  //  .   \.
  //  x....O
  //
  void DrawLine1110(const DrawInfo& draw_info);


  //
  //  O....O
  //  |    .
  //  |    .
  //  |    .
  //  |    .
  //  O----O
  //
  void DrawLine1111(const DrawInfo& draw_info);


  //  x....O
  //  .   /.
  //  .  / .
  //  . /  .
  //  ./   .
  //  O....x
  //
  void DrawLineSpecial01(const glop::DrawInfo& draw_info);

  //
  //  O....x
  //  .\   .
  //  . \  .
  //  .  \ .
  //  .   \.
  //  x....O
  //
  void DrawLineSpecial02(const DrawInfo& draw_info);

  //
  //  O....x
  //  |\   .
  //  | \  .
  //  |  \ .
  //  |   \.
  //  x....O
  //
  void DrawLineSpecial03(const DrawInfo& draw_info);

  //
  //  O....x
  //  .\   .
  //  . \  .
  //  .  \ .
  //  .   \.
  //  x----O
  //
  void DrawLineSpecial04(const DrawInfo& draw_info);

  //
  // Singleton and factory pattern for Draw function
  //
  class LineFunctionSelector:public FunctionSelectorSquareEval{
  public:
    LineFunctionSelector(void);
    virtual ~LineFunctionSelector(void);
    virtual DrawFunction GetDraw(DrawMask mask,
				 bool left_side,
				 bool down_side,
				 bool hole_left_up,
				 bool hole_left_down,
				 bool hole_corner,
				 bool hole_down_left,
				 bool hole_down_right);
  };
}
#endif
